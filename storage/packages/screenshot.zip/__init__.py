"""MCP server chụp màn hình (mss) -> image content cho model vision."""

from .server import main, mcp

__all__ = ["main", "mcp"]
__version__ = "0.1.0"
