"""MCP server chụp màn hình bằng mss, trả ảnh cho model vision "nhìn".

Chạy: python -m servers.screenshot_mcp
Cấu hình: SCREENSHOT_ENABLED (bật/tắt), SCREENSHOT_MAX_WIDTH (thu nhỏ mặc định).

Lưu ý: cần phiên desktop thật đang đăng nhập; chạy headless/SSH thuần sẽ không có
framebuffer để chụp. Ảnh chỉ trả về cho client, không gửi đi đâu.
"""

from __future__ import annotations

import os
from typing import Any

from mcp.server import MCPServer
from mcp.types import CallToolResult
from common import image_blocks
from common import ok as _ok

from .helpers import (
    ScreenshotError,
    default_max_width,
    draw_boxes,
    draw_grid,
    ensure_enabled,
    grab_png,
    list_monitors as _list_monitors,
    resize_png,
    save_png,
)

mcp = MCPServer(
    "screenshot",
    instructions=(
        "Chụp màn hình (toàn bộ / từng màn hình / một vùng) và trả ảnh dưới dạng "
        "image content để model vision đọc nội dung. Dùng list_monitors để xem các "
        "màn hình trước. Cần phiên desktop thật; tắt bằng SCREENSHOT_ENABLED=0."
    ),
)


@mcp.tool()
def list_monitors() -> dict[str, Any]:
    """Liệt kê màn hình: index (0=tất cả, 1..n=từng cái), vị trí, độ phân giải."""
    mons = _list_monitors()
    return _ok(count=len(mons), monitors=mons)


def _shot(png: bytes, w: int, h: int, max_width: int, save_path: str | None, label: str) -> CallToolResult:
    mw = max_width if max_width else default_max_width()
    png, rw, rh = resize_png(png, mw)
    dims = f"{rw or w}x{rh or h}px"
    caption = f"{label} — {dims}"
    if save_path:
        caption += f" — đã lưu {save_png(save_path, png)}"
    return image_blocks([{"caption": caption, "mime": "image/png", "data": png}])


@mcp.tool()
def capture_screen(
    monitor: int = 0, save_path: str | None = None, max_width: int = 0
) -> CallToolResult:
    """Chụp màn hình. monitor=0: toàn bộ (gộp mọi màn hình); 1,2..: một màn hình cụ thể.

    save_path: lưu ảnh ra file .png. max_width>0: thu nhỏ chiều rộng cho nhẹ.
    """
    ensure_enabled()
    png, w, h = grab_png(monitor=monitor)
    return _shot(png, w, h, max_width, save_path, f"Screenshot monitor {monitor}")


@mcp.tool()
def capture_region(
    left: int, top: int, width: int, height: int,
    save_path: str | None = None, max_width: int = 0,
) -> CallToolResult:
    """Chụp một vùng chữ nhật theo toạ độ màn hình (left, top, width, height)."""
    ensure_enabled()
    png, w, h = grab_png(region=(left, top, width, height))
    return _shot(png, w, h, max_width, save_path, f"Region {left},{top} {width}x{height}")


@mcp.tool()
def capture_with_grid(
    monitor: int = 0,
    step: int = 200,
    minor: int = 0,
    color: str = "#FF0000",
    save_path: str | None = None,
    max_width: int = 0,
) -> CallToolResult:
    """Chụp màn hình + vẽ LƯỚI TOẠ ĐỘ 2 cấp (đường đậm có số mỗi `step`, đường mảnh
    mỗi `minor`≈step/4) để đọc toạ độ vùng cần.

    Dùng ảnh lưới CHỈ để lấy toạ độ; còn hiển thị/cắt/khoanh thì dùng capture_screen /
    capture_region / highlight_regions trên ảnh SẠCH (nhãn lưới là toạ độ gốc, dùng
    trực tiếp cho các tool đó). Gợi ý step ~100–200px (đừng quá dày sẽ rối/khó đọc).
    """
    ensure_enabled()
    png, w, h = grab_png(monitor=monitor)
    png, w, h = draw_grid(png, step, color, minor=minor)
    return _shot(png, w, h, max_width, save_path, f"Lưới toạ độ step={step}px (monitor {monitor})")


@mcp.tool()
def capture_region_with_grid(
    left: int,
    top: int,
    width: int,
    height: int,
    step: int = 50,
    minor: int = 0,
    color: str = "#FF0000",
    save_path: str | None = None,
    max_width: int = 0,
) -> CallToolResult:
    """ZOOM: chụp MỘT VÙNG rồi vẽ lưới mịn — để lấy toạ độ chính xác hơn.

    Nhãn lưới là toạ độ TOÀN MÀN HÌNH (đã cộng offset left/top), nên dùng trực tiếp
    cho capture_region / highlight_regions. Luồng 2 bước: capture_with_grid (thô) →
    capture_region_with_grid quanh vùng đó (mịn).
    """
    ensure_enabled()
    png, w, h = grab_png(region=(left, top, width, height))
    png, w, h = draw_grid(png, step, color, offset=(left, top), minor=minor)
    return _shot(png, w, h, max_width, save_path,
                 f"Zoom+lưới ({left},{top} {width}x{height}), step={step}px")


@mcp.tool()
def highlight_regions(
    regions: list,
    monitor: int = 0,
    color: str = "#FF0000",
    width: int = 4,
    labels: list | None = None,
    save_path: str | None = None,
    max_width: int = 0,
) -> CallToolResult:
    """Chụp màn hình rồi VẼ khung (mặc định đỏ) quanh các vùng cần highlight.

    regions: danh sách vùng, mỗi vùng [left, top, width, height] hoặc
    {left, top, width, height} — toạ độ theo pixel của ảnh chụp.
    labels: (tuỳ chọn) nhãn cho từng vùng. save_path: lưu .png. Trả ảnh cho vision.
    """
    ensure_enabled()
    png, w, h = grab_png(monitor=monitor)
    png, w, h = draw_boxes(png, regions, color, width, labels)
    return _shot(png, w, h, max_width, save_path, f"Highlight {len(regions)} vùng (monitor {monitor})")


@mcp.tool()
def highlight_image(
    path: str,
    regions: list,
    output: str | None = None,
    color: str = "#FF0000",
    width: int = 4,
    labels: list | None = None,
    max_width: int = 0,
) -> CallToolResult:
    """Vẽ khung highlight lên một ẢNH CÓ SẴN (.png/.jpg...), trả ảnh (và lưu nếu có `output`).

    regions: [left, top, width, height] hoặc {left,top,width,height} theo pixel ảnh.
    """
    src = os.path.realpath(os.path.abspath(os.path.expanduser(path)))
    if not os.path.isfile(src):
        raise ScreenshotError(f"Không tìm thấy ảnh: {src}")
    with open(src, "rb") as fh:
        raw = fh.read()
    png, w, h = draw_boxes(raw, regions, color, width, labels)
    return _shot(png, w, h, max_width, output, f"Highlight {len(regions)} vùng trên {os.path.basename(src)}")


def main() -> None:
    """Điểm khởi động: chạy MCP server qua stdio."""
    mcp.run()


if __name__ == "__main__":
    main()
