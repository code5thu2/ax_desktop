"""Tiện ích cho screenshot_mcp: chụp bằng mss, thu nhỏ, lưu file.

Cấu hình qua biến môi trường:
    SCREENSHOT_ENABLED   "1" (mặc định) bật; "0" tắt hẳn chức năng chụp
    SCREENSHOT_MAX_WIDTH mặc định 0 (không thu nhỏ); >0 -> giới hạn chiều rộng ảnh
"""

from __future__ import annotations

import io
import os

from common import McpError

ScreenshotError = McpError  # alias cho dễ đọc


def ensure_enabled() -> None:
    if os.environ.get("SCREENSHOT_ENABLED", "1").lower() in ("0", "false", "no"):
        raise ScreenshotError(
            "Chức năng chụp màn hình đang tắt. Đặt SCREENSHOT_ENABLED=1 để bật."
        )


def default_max_width() -> int:
    try:
        return int(os.environ.get("SCREENSHOT_MAX_WIDTH", "0"))
    except ValueError:
        return 0


def _mss():
    try:
        import mss  # noqa: PLC0415
    except ImportError as exc:  # pragma: no cover
        raise ScreenshotError("Chưa cài mss. Chạy: pip install mss") from exc
    return mss


def list_monitors() -> list[dict]:
    """Danh sách màn hình. index 0 = toàn bộ (gộp), 1..n = từng màn hình."""
    mss = _mss()
    with mss.mss() as sct:
        return [
            {
                "index": i,
                "left": m["left"], "top": m["top"],
                "width": m["width"], "height": m["height"],
                "role": "all" if i == 0 else f"monitor {i}",
            }
            for i, m in enumerate(sct.monitors)
        ]


def grab_png(monitor: int | None = None, region: tuple[int, int, int, int] | None = None):
    """Chụp -> (png_bytes, width, height). region=(left,top,width,height) hoặc monitor."""
    mss = _mss()
    from mss.tools import to_png  # noqa: PLC0415

    with mss.mss() as sct:
        if region is not None:
            left, top, width, height = region
            if width <= 0 or height <= 0:
                raise ScreenshotError("width/height của vùng phải > 0.")
            box = {"left": left, "top": top, "width": width, "height": height}
        else:
            mons = sct.monitors
            mon = 0 if monitor is None else monitor
            if mon < 0 or mon >= len(mons):
                raise ScreenshotError(f"monitor {mon} không hợp lệ (0..{len(mons) - 1}).")
            box = mons[mon]
        img = sct.grab(box)
        return to_png(img.rgb, img.size), img.size[0], img.size[1]


def resize_png(png: bytes, max_width: int) -> tuple[bytes, int, int]:
    """Thu nhỏ ảnh nếu rộng hơn max_width (cần Pillow). Trả (png, w, h)."""
    if not max_width or max_width <= 0:
        return png, 0, 0
    try:
        from PIL import Image  # noqa: PLC0415
    except ImportError:  # pragma: no cover
        return png, 0, 0
    im = Image.open(io.BytesIO(png))
    if im.width <= max_width:
        return png, im.width, im.height
    h = int(im.height * max_width / im.width)
    im2 = im.resize((max_width, h))
    buf = io.BytesIO()
    im2.save(buf, format="PNG")
    return buf.getvalue(), im2.width, im2.height


def _box(box) -> tuple[int, int, int, int]:
    """Chấp nhận [l,t,w,h] hoặc {left,top,width,height}."""
    if isinstance(box, dict):
        return int(box["left"]), int(box["top"]), int(box["width"]), int(box["height"])
    return int(box[0]), int(box[1]), int(box[2]), int(box[3])


def draw_boxes(png: bytes, regions, color: str = "#FF0000", width: int = 4, labels=None):
    """Vẽ khung (mặc định đỏ) quanh các vùng lên ảnh PNG. Trả (png, w, h)."""
    import io  # noqa: PLC0415

    try:
        from PIL import Image, ImageDraw  # noqa: PLC0415
    except ImportError as exc:  # pragma: no cover
        raise ScreenshotError("Chưa cài pillow. Chạy: pip install pillow") from exc
    im = Image.open(io.BytesIO(png)).convert("RGB")
    d = ImageDraw.Draw(im)
    for i, box in enumerate(regions):
        left, top, w, h = _box(box)
        d.rectangle([left, top, left + w, top + h], outline=color, width=max(1, width))
        if labels and i < len(labels) and labels[i]:
            d.text((left + 3, max(0, top - 14)), str(labels[i]), fill=color)
    buf = io.BytesIO()
    im.save(buf, format="PNG")
    return buf.getvalue(), im.width, im.height


def draw_grid(png: bytes, step: int = 200, color: str = "#FF0000",
              offset: tuple[int, int] = (0, 0), minor: int = 0):
    """Vẽ lưới toạ độ 2 cấp lên ảnh để model đọc toạ độ. Trả (png, w, h).

    - Đường ĐẬM (width 2) mỗi `step` px, kèm SỐ toạ độ (đã cộng `offset`).
    - Đường MẢNH (width 1) mỗi `minor` px (mặc định step/4), không số.
    offset: toạ độ gốc của vùng (để nhãn hiện toạ độ TOÀN màn hình khi zoom).
    """
    import io  # noqa: PLC0415

    try:
        from PIL import Image, ImageDraw  # noqa: PLC0415
    except ImportError as exc:  # pragma: no cover
        raise ScreenshotError("Chưa cài pillow. Chạy: pip install pillow") from exc
    im = Image.open(io.BytesIO(png)).convert("RGB")
    d = ImageDraw.Draw(im)
    W, H = im.size
    ox, oy = int(offset[0]), int(offset[1])
    step = max(20, int(step))
    minor_step = int(minor) if minor and minor > 0 else max(5, step // 4)

    # Đường mảnh (minor) — không nhãn, bỏ qua chỗ trùng đường đậm.
    gx = ((ox // minor_step) + 1) * minor_step
    while gx < ox + W:
        if gx % step != 0:
            d.line([(gx - ox, 0), (gx - ox, H)], fill=color, width=1)
        gx += minor_step
    gy = ((oy // minor_step) + 1) * minor_step
    while gy < oy + H:
        if gy % step != 0:
            d.line([(0, gy - oy), (W, gy - oy)], fill=color, width=1)
        gy += minor_step

    # Đường đậm (major) + nhãn toạ độ (toàn màn hình).
    gx = ((ox // step) + 1) * step
    while gx < ox + W:
        d.line([(gx - ox, 0), (gx - ox, H)], fill=color, width=2)
        d.text((gx - ox + 2, 2), str(gx), fill=color)
        gx += step
    gy = ((oy // step) + 1) * step
    while gy < oy + H:
        d.line([(0, gy - oy), (W, gy - oy)], fill=color, width=2)
        d.text((2, gy - oy + 2), str(gy), fill=color)
        gy += step

    buf = io.BytesIO()
    im.save(buf, format="PNG")
    return buf.getvalue(), W, H


def save_png(path: str, data: bytes) -> str:
    abspath = os.path.realpath(os.path.abspath(os.path.expanduser(path)))
    if not abspath.lower().endswith(".png"):
        raise ScreenshotError("save_path phải kết thúc bằng .png")
    parent = os.path.dirname(abspath)
    if parent:
        os.makedirs(parent, exist_ok=True)
    with open(abspath, "wb") as fh:
        fh.write(data)
    return abspath
