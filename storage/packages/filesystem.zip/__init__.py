"""MCP server duyệt hệ thống tệp (file explorer, chỉ dùng thư viện chuẩn)."""

from .server import main, mcp

__all__ = ["main", "mcp"]
__version__ = "0.1.0"
