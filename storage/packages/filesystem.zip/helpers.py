"""Tiện ích dùng chung cho file explorer MCP: guard truy cập & chuẩn hoá path.

Cấu hình qua biến môi trường:
    FS_ROOTS          danh sách thư mục gốc được phép, ngăn cách bằng ';'
                      (để trống = cho phép toàn hệ thống)
    FS_ACCESS_MODE    "readonly" (mặc định) hoặc "readwrite"
    FS_MAX_READ_BYTES giới hạn số byte đọc mỗi lần (mặc định 1_000_000)
"""

from __future__ import annotations

import datetime as _dt
import os

from common import McpError, human_size, make_access

DEFAULT_MAX_READ_BYTES = 1_000_000

FSError = McpError  # alias cho dễ đọc
access_mode, is_readonly, require_write = make_access("FS_ACCESS_MODE")

__all__ = [
    "FSError", "access_mode", "is_readonly", "require_write", "human_size",
    "max_read_bytes", "roots", "resolve_path", "default_path", "iso",
]


def max_read_bytes() -> int:
    try:
        return int(os.environ.get("FS_MAX_READ_BYTES", DEFAULT_MAX_READ_BYTES))
    except ValueError:
        return DEFAULT_MAX_READ_BYTES


def roots() -> list[str]:
    """Danh sách thư mục gốc cho phép (đã chuẩn hoá tuyệt đối). Rỗng = không giới hạn."""
    raw = os.environ.get("FS_ROOTS", "").strip()
    if not raw:
        return []
    parts = [p.strip() for p in raw.replace(";", os.pathsep).split(os.pathsep) if p.strip()]
    return [os.path.realpath(os.path.abspath(os.path.expanduser(p))) for p in parts]


def resolve_path(path: str) -> str:
    """Chuẩn hoá path tuyệt đối và kiểm tra nằm trong FS_ROOTS (nếu có cấu hình).

    Chống path traversal (../) vì so khớp sau khi đã realpath.
    """
    if not path or not str(path).strip():
        raise FSError("Thiếu đường dẫn.")
    resolved = os.path.realpath(os.path.abspath(os.path.expanduser(path)))
    allowed = roots()
    norm_resolved = os.path.normcase(resolved)
    if allowed and not any(
        norm_resolved == os.path.normcase(r)
        or norm_resolved.startswith(os.path.normcase(r) + os.sep)
        for r in allowed
    ):
        raise FSError(
            f"Đường dẫn ngoài phạm vi cho phép (FS_ROOTS): {resolved}"
        )
    return resolved


def default_path() -> str:
    """Đường dẫn mặc định khi client không truyền: gốc đầu tiên hoặc thư mục home."""
    allowed = roots()
    return allowed[0] if allowed else os.path.expanduser("~")


def iso(ts: float) -> str:
    return _dt.datetime.fromtimestamp(ts).isoformat(timespec="seconds")
