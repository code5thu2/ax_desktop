"""MCP server duyệt hệ thống tệp (kiểu file explorer).

Chạy: python -m fs_mcp   (transport stdio)
Cấu hình (xem helpers.py): FS_ROOTS, FS_ACCESS_MODE=readonly|readwrite, FS_MAX_READ_BYTES.

Tool đọc luôn khả dụng; tool thay đổi (ghi/tạo/di chuyển/xoá) chỉ chạy khi
FS_ACCESS_MODE=readwrite. Mọi đường dẫn bị chặn nếu nằm ngoài FS_ROOTS (khi có).
"""

from __future__ import annotations

import difflib
import fnmatch
import os
import shutil
from typing import Any

from mcp.server import MCPServer
from mcp.types import CallToolResult
from common import IMAGE_MIME, image_blocks, sniff_size
from common import ok as _ok

from .helpers import (
    FSError,
    access_mode,
    default_path,
    human_size,
    iso,
    max_read_bytes,
    require_write,
    resolve_path,
    roots,
)

mcp = MCPServer(
    "filesystem",
    instructions=(
        "Bộ công cụ hệ thống: (1) tệp — liệt kê thư mục, xem thông tin, đọc file "
        "văn bản, tìm kiếm, xem ổ đĩa; (2) giám sát hệ thống — CPU, RAM, ổ đĩa, "
        "tiến trình, mạng (psutil). Mặc định read-only; ghi/tạo/di chuyển/xoá/kill "
        "process chỉ khi FS_ACCESS_MODE=readwrite. Đường dẫn bị giới hạn theo FS_ROOTS."
    ),
)


def _entry(name: str, full: str) -> dict[str, Any]:
    """Mô tả ngắn gọn một mục trong thư mục (an toàn với file lỗi quyền)."""
    try:
        st = os.stat(full)
        is_dir = os.path.isdir(full)
        return {
            "name": name,
            "type": "dir" if is_dir else "file",
            "size": None if is_dir else st.st_size,
            "size_human": None if is_dir else human_size(st.st_size),
            "modified": iso(st.st_mtime),
        }
    except OSError as exc:
        return {"name": name, "type": "unknown", "error": str(exc)}


# ========================================================================== #
# Tool đọc (luôn khả dụng)
# ========================================================================== #
@mcp.tool()
def list_directory(path: str | None = None, show_hidden: bool = False) -> dict[str, Any]:
    """Liệt kê nội dung một thư mục (thư mục trước, rồi tệp; sắp theo tên).

    path bỏ trống -> dùng gốc đầu tiên trong FS_ROOTS, hoặc thư mục home.
    show_hidden=True để hiện file/thư mục bắt đầu bằng dấu chấm.
    """
    target = resolve_path(path) if path else default_path()
    if not os.path.isdir(target):
        raise FSError(f"Không phải thư mục: {target}")

    dirs: list[dict[str, Any]] = []
    files: list[dict[str, Any]] = []
    with os.scandir(target) as it:
        for e in it:
            if not show_hidden and e.name.startswith("."):
                continue
            item = _entry(e.name, e.path)
            (dirs if item["type"] == "dir" else files).append(item)
    dirs.sort(key=lambda x: x["name"].lower())
    files.sort(key=lambda x: x["name"].lower())

    parent = os.path.dirname(target)
    return _ok(
        path=target,
        parent=parent if parent != target else None,
        count=len(dirs) + len(files),
        entries=dirs + files,
    )


@mcp.tool()
def file_info(path: str) -> dict[str, Any]:
    """Xem thông tin chi tiết một tệp/thư mục: kiểu, kích thước, thời gian, thuộc tính."""
    target = resolve_path(path)
    if not os.path.exists(target):
        raise FSError(f"Không tồn tại: {target}")
    st = os.stat(target)
    is_dir = os.path.isdir(target)
    return _ok(
        path=target,
        name=os.path.basename(target) or target,
        type="dir" if is_dir else "file",
        size=None if is_dir else st.st_size,
        size_human=None if is_dir else human_size(st.st_size),
        extension=None if is_dir else os.path.splitext(target)[1].lower(),
        modified=iso(st.st_mtime),
        created=iso(st.st_ctime),
        accessed=iso(st.st_atime),
        readonly=not os.access(target, os.W_OK),
    )


@mcp.tool()
def read_text_file(
    path: str, max_bytes: int | None = None, encoding: str = "utf-8"
) -> dict[str, Any]:
    """Đọc nội dung một tệp văn bản (giới hạn theo FS_MAX_READ_BYTES).

    Ký tự giải mã lỗi sẽ được thay thế thay vì báo lỗi. max_bytes ghi đè giới
    hạn mặc định (không vượt quá FS_MAX_READ_BYTES).
    """
    target = resolve_path(path)
    if not os.path.isfile(target):
        raise FSError(f"Không phải tệp: {target}")
    cap = max_read_bytes()
    limit = min(max_bytes, cap) if max_bytes else cap
    size = os.path.getsize(target)
    with open(target, "rb") as fh:
        raw = fh.read(limit)
    text = raw.decode(encoding, errors="replace")
    truncated = size > len(raw)
    out: dict[str, Any] = {
        "path": target,
        "size": size,
        "bytes_read": len(raw),
        "truncated": truncated,
        "encoding": encoding,
        "content": text,
    }
    if truncated:
        out["hint"] = (
            f"File dài {human_size(size)}, nội dung đã bị ngắt ở {len(raw)} bytes để tránh quá tải RAM/token. "
            f"Gợi ý: Dùng 'stream_grep_file' nếu muốn TÌM KIẾM từ khóa/regex trong toàn bộ file; "
            f"hoặc dùng 'read_file_stream' với offset={len(raw)} để ĐỌC TIẾP phần sau."
        )
    return _ok(**out)


@mcp.tool()
def read_file_stream(
    path: str,
    offset: int = 0,
    limit: int = 50_000,
    encoding: str = "utf-8",
) -> dict[str, Any]:
    """Đọc một phần (chunk) của file văn bản theo cơ chế streaming/phân trang O(1).

    Dùng khi bạn muốn ĐỌC TOÀN VĂN hoặc DUYỆT TỪNG PHẦN một file dài/lớn mà không làm tràn RAM.
    Trả về next_offset và has_more để tiếp tục gọi đọc các phần kế tiếp.

    Args:
        path: Đường dẫn tới file cần đọc.
        offset: Vị trí byte bắt đầu đọc (mặc định 0).
        limit: Số byte tối đa đọc trong chunk này (mặc định 50,000 bytes).
        encoding: Bảng mã file (mặc định utf-8).
    """
    target = resolve_path(path)
    if not os.path.isfile(target):
        raise FSError(f"Không phải tệp: {target}")

    total_size = os.path.getsize(target)
    if offset < 0:
        offset = 0
    if offset >= total_size:
        return _ok(
            path=target,
            offset=offset,
            bytes_read=0,
            total_size=total_size,
            progress_percent=100.0,
            has_more=False,
            next_offset=None,
            content="",
        )

    with open(target, "rb") as fh:
        fh.seek(offset)
        raw = fh.read(limit)

    bytes_read = len(raw)
    current_end = offset + bytes_read
    has_more = current_end < total_size
    next_offset = current_end if has_more else None
    progress = round((current_end / total_size) * 100, 1) if total_size > 0 else 100.0
    text = raw.decode(encoding, errors="replace")

    return _ok(
        path=target,
        offset=offset,
        bytes_read=bytes_read,
        total_size=total_size,
        progress_percent=progress,
        has_more=has_more,
        next_offset=next_offset,
        content=text,
    )


@mcp.tool()
def stream_grep_file(
    path: str,
    pattern: str,
    max_matches: int = 50,
    context_lines: int = 1,
    ignore_case: bool = True,
    encoding: str = "utf-8",
) -> dict[str, Any]:
    """Tìm kiếm từ khóa hoặc biểu thức chính quy (Regex) trong file theo luồng streaming.

    Dùng khi bạn muốn TÌM KIẾM thông tin (mã lỗi, user ID, keyword, log event) trong file
    (đặc biệt là file lớn > 1MB hoặc file log dài).
    Tool quét qua toàn bộ file từng dòng một nên tiêu tốn cực ít RAM (< 1MB) và không bị tràn bộ nhớ.

    Args:
        path: Đường dẫn file cần tìm.
        pattern: Từ khóa hoặc biểu thức Regex cần tìm.
        max_matches: Số dòng khớp tối đa cần lấy (mặc định 50).
        context_lines: Số dòng ngữ cảnh trước và sau dòng khớp cần lấy (mặc định 1).
        ignore_case: Không phân biệt hoa/thường (mặc định True).
        encoding: Bảng mã file (mặc định utf-8).
    """
    import re
    from collections import deque

    target = resolve_path(path)
    if not os.path.isfile(target):
        raise FSError(f"Không phải tệp: {target}")

    flags = re.IGNORECASE if ignore_case else 0
    try:
        regex = re.compile(pattern, flags)
    except re.error as exc:
        raise FSError(f"Biểu thức Regex không hợp lệ: {exc}") from exc

    matches: list[dict[str, Any]] = []
    before_buffer: deque[str] = deque(maxlen=context_lines)

    with open(target, "r", encoding=encoding, errors="replace") as fh:
        current_collecting: list[dict[str, Any]] = []

        for line_num, line in enumerate(fh, 1):
            line_str = line.rstrip("\r\n")

            for pending in list(current_collecting):
                pending["context_after"].append(line_str)
                if len(pending["context_after"]) >= context_lines:
                    current_collecting.remove(pending)

            if regex.search(line_str):
                item = {
                    "line_number": line_num,
                    "line": line_str,
                    "context_before": list(before_buffer),
                    "context_after": [],
                }
                matches.append(item)
                if context_lines > 0:
                    current_collecting.append(item)

                if len(matches) >= max_matches:
                    break

            before_buffer.append(line_str)

    return _ok(
        path=target,
        pattern=pattern,
        match_count=len(matches),
        max_matches=max_matches,
        truncated=len(matches) >= max_matches,
        matches=matches,
    )


@mcp.tool()
def search_files(
    path: str,
    pattern: str = "*",
    recursive: bool = True,
    max_results: int = 200,
) -> dict[str, Any]:
    """Tìm tệp/thư mục theo mẫu tên (glob, không phân biệt hoa thường).

    Ví dụ pattern="*.log", "report_*". recursive=True quét cả thư mục con.
    """
    root = resolve_path(path)
    if not os.path.isdir(root):
        raise FSError(f"Không phải thư mục: {root}")
    pat = pattern.lower()
    results: list[dict[str, Any]] = []
    truncated = False

    for dirpath, dirnames, filenames in os.walk(root, onerror=lambda err: None):
        for name in list(dirnames) + filenames:
            if fnmatch.fnmatch(name.lower(), pat):
                full = os.path.join(dirpath, name)
                results.append(
                    {
                        "path": full,
                        "name": name,
                        "type": "dir" if os.path.isdir(full) else "file",
                    }
                )
                if len(results) >= max_results:
                    truncated = True
                    break
        if truncated or not recursive:
            if not recursive:
                dirnames[:] = []
            if truncated:
                break

    return _ok(root=root, pattern=pattern, count=len(results), truncated=truncated, matches=results)


@mcp.tool()
def list_drives() -> dict[str, Any]:
    """Liệt kê các ổ đĩa (Windows) hoặc điểm gốc, kèm dung lượng tổng/còn trống."""
    drives: list[dict[str, Any]] = []
    if os.name == "nt":
        candidates = [f"{chr(c)}:\\" for c in range(ord("A"), ord("Z") + 1)]
    else:
        candidates = ["/"]
    for d in candidates:
        if not os.path.exists(d):
            continue
        info: dict[str, Any] = {"drive": d}
        try:
            usage = shutil.disk_usage(d)
            info.update(
                total=usage.total,
                used=usage.used,
                free=usage.free,
                total_human=human_size(usage.total),
                free_human=human_size(usage.free),
            )
        except OSError as exc:
            info["error"] = str(exc)
        drives.append(info)
    return _ok(count=len(drives), drives=drives)


MEDIA_MAX_BYTES = 20_000_000  # trần an toàn khi đọc ảnh (20MB)


@mcp.tool()
def read_media_file(path: str) -> CallToolResult:
    """Đọc một tệp ảnh và trả về dưới dạng image content cho model vision "nhìn".

    Hỗ trợ png/jpg/jpeg/gif/webp/bmp/tiff... (nhận diện theo đuôi tệp). Ảnh
    png/jpeg/gif/webp hiển thị trực tiếp; định dạng khác chỉ trả chú thích.
    Tệp lớn hơn 20MB bị từ chối để tránh nghẽn.
    """
    target = resolve_path(path)
    if not os.path.isfile(target):
        raise FSError(f"Không phải tệp: {target}")
    ext = os.path.splitext(target)[1].lower()
    mime = IMAGE_MIME.get(ext)
    if not mime:
        raise FSError(f"Không phải định dạng ảnh hỗ trợ: {ext or '(không có đuôi)'}")
    size = os.path.getsize(target)
    if size > MEDIA_MAX_BYTES:
        raise FSError(f"Ảnh quá lớn ({human_size(size)} > {human_size(MEDIA_MAX_BYTES)}).")
    with open(target, "rb") as fh:
        data = fh.read()
    w, h = sniff_size(data)
    dims = f"{w}x{h}px" if w and h else "kích thước không rõ"
    caption = f"{os.path.basename(target)} — {dims} — {human_size(size)}"
    return image_blocks([{"caption": caption, "mime": mime, "data": data}])


@mcp.tool()
def server_info() -> dict[str, Any]:
    """Xem cấu hình hiện tại: chế độ truy cập, thư mục gốc cho phép, giới hạn đọc."""
    return _ok(
        access_mode=access_mode(),
        roots=roots() or "(toàn hệ thống — chưa giới hạn)",
        max_read_bytes=max_read_bytes(),
        platform=os.name,
        home=os.path.expanduser("~"),
    )


# ========================================================================== #
# System monitor (psutil — nạp lười)
# ========================================================================== #
def _psutil() -> Any:
    try:
        import psutil  # noqa: PLC0415
    except ImportError as exc:  # pragma: no cover
        raise FSError("Chưa cài psutil. Chạy: pip install psutil") from exc
    return psutil


@mcp.tool()
def system_info() -> dict[str, Any]:
    """Thông tin hệ thống: OS, hostname, thời gian bật máy, số CPU, tổng RAM."""
    import platform
    import socket

    ps = _psutil()
    vm = ps.virtual_memory()
    return _ok(
        hostname=socket.gethostname(),
        os=platform.platform(),
        python=platform.python_version(),
        boot_time=iso(ps.boot_time()),
        cpu_logical=ps.cpu_count(),
        cpu_physical=ps.cpu_count(logical=False),
        ram_total=vm.total,
        ram_total_human=human_size(vm.total),
    )


@mcp.tool()
def cpu_usage(interval: float = 0.5, per_core: bool = False) -> dict[str, Any]:
    """% sử dụng CPU (đo trong `interval` giây). per_core=True để xem từng nhân."""
    ps = _psutil()
    overall = ps.cpu_percent(interval=interval)
    out: dict[str, Any] = {"cpu_percent": overall}
    if per_core:
        out["per_core"] = ps.cpu_percent(interval=interval, percpu=True)
    return _ok(**out)


@mcp.tool()
def memory_usage() -> dict[str, Any]:
    """Tình trạng RAM và swap (tổng/đã dùng/còn trống/%)."""
    ps = _psutil()
    vm = ps.virtual_memory()
    sw = ps.swap_memory()
    return _ok(
        ram={
            "total": vm.total, "used": vm.used, "available": vm.available,
            "percent": vm.percent, "total_human": human_size(vm.total),
            "used_human": human_size(vm.used),
        },
        swap={
            "total": sw.total, "used": sw.used, "percent": sw.percent,
            "total_human": human_size(sw.total),
        },
    )


@mcp.tool()
def disk_usage() -> dict[str, Any]:
    """Dung lượng từng phân vùng ổ đĩa (mount, hệ thống tệp, tổng/dùng/%)."""
    ps = _psutil()
    parts = []
    for p in ps.disk_partitions(all=False):
        try:
            u = ps.disk_usage(p.mountpoint)
        except (PermissionError, OSError):
            continue
        parts.append({
            "device": p.device, "mountpoint": p.mountpoint, "fstype": p.fstype,
            "total": u.total, "used": u.used, "free": u.free, "percent": u.percent,
            "total_human": human_size(u.total), "free_human": human_size(u.free),
        })
    return _ok(count=len(parts), partitions=parts)


@mcp.tool()
def list_processes(
    sort_by: str = "memory", limit: int = 20, name_contains: str | None = None
) -> dict[str, Any]:
    """Liệt kê tiến trình đang chạy, sắp theo 'memory' hoặc 'cpu'.

    name_contains: chỉ lấy tiến trình có tên chứa chuỗi này (không phân biệt hoa thường).
    """
    ps = _psutil()
    procs = []
    for p in ps.process_iter(["pid", "name", "username", "memory_percent", "cpu_percent"]):
        info = p.info
        if name_contains and name_contains.lower() not in (info.get("name") or "").lower():
            continue
        procs.append({
            "pid": info["pid"],
            "name": info.get("name"),
            "username": info.get("username"),
            "memory_percent": round(info.get("memory_percent") or 0, 2),
            "cpu_percent": round(info.get("cpu_percent") or 0, 2),
        })
    key = "cpu_percent" if sort_by == "cpu" else "memory_percent"
    procs.sort(key=lambda x: x[key], reverse=True)
    return _ok(sort_by=sort_by, count=len(procs), processes=procs[:limit])


@mcp.tool()
def process_info(pid: int) -> dict[str, Any]:
    """Chi tiết một tiến trình theo PID: tên, trạng thái, RAM, CPU, dòng lệnh."""
    try:
        import psutil  # noqa: PLC0415
        _AccessDenied = psutil.AccessDenied
        _NoSuchProcess = psutil.NoSuchProcess
    except ImportError:
        _AccessDenied = PermissionError
        _NoSuchProcess = Exception

    ps = _psutil()
    try:
        p = ps.Process(pid)
    except (_NoSuchProcess, Exception) as exc:
        if isinstance(exc, _NoSuchProcess):
            raise FSError(f"Không có tiến trình PID {pid}") from exc
        raise

    def _safe(fn: Any, fallback: Any = None) -> Any:
        try:
            return fn()
        except (_AccessDenied, PermissionError):
            return "<access-denied>"
        except Exception:
            return fallback

    with p.oneshot():
        mem = _safe(p.memory_info)
        rss = getattr(mem, "rss", None)
        cmd = _safe(p.cmdline, [])
        cmdline_str = " ".join(cmd) if isinstance(cmd, list) else str(cmd)
        ctime = _safe(p.create_time)

        return _ok(
            pid=pid,
            name=_safe(p.name, f"PID {pid}"),
            status=_safe(p.status, "unknown"),
            username=_safe(p.username, "<access-denied>"),
            created=iso(ctime) if ctime and isinstance(ctime, (int, float)) else None,
            cpu_percent=_safe(lambda: p.cpu_percent(interval=0.1), 0.0),
            memory_rss=rss,
            memory_rss_human=human_size(rss) if rss else None,
            num_threads=_safe(p.num_threads, 0),
            cmdline=cmdline_str,
        )


@mcp.tool()
def network_info() -> dict[str, Any]:
    """Danh sách card mạng + địa chỉ IP, và thống kê kết nối theo trạng thái."""
    import socket

    ps = _psutil()
    ifaces = []
    for name, addrs in ps.net_if_addrs().items():
        ips = [a.address for a in addrs if a.family == socket.AF_INET]
        if ips:
            ifaces.append({"interface": name, "ipv4": ips})
    states: dict[str, int] = {}
    try:
        for c in ps.net_connections():
            states[c.status] = states.get(c.status, 0) + 1
    except Exception:
        states = {"error": "cần quyền cao hơn để liệt kê kết nối"}
    return _ok(interfaces=ifaces, connections_by_state=states)


# ========================================================================== #
# Tool thay đổi (chỉ khi FS_ACCESS_MODE=readwrite)
# ========================================================================== #
@mcp.tool()
def kill_process(pid: int) -> dict[str, Any]:
    """Kết thúc một tiến trình theo PID (terminate). Cần readwrite."""
    require_write()
    ps = _psutil()
    try:
        p = ps.Process(pid)
        name = p.name()
        p.terminate()
        return _ok(pid=pid, name=name, terminated=True)
    except ps.NoSuchProcess as exc:
        raise FSError(f"Không có tiến trình PID {pid}") from exc
    except ps.AccessDenied as exc:
        raise FSError(f"Không đủ quyền kết thúc PID {pid}") from exc


@mcp.tool()
def edit_file(
    path: str,
    old_text: str,
    new_text: str,
    replace_all: bool = False,
    dry_run: bool = False,
) -> dict[str, Any]:
    """Sửa một tệp văn bản bằng cách thay `old_text` thành `new_text`.

    Khớp chính xác (kể cả xuống dòng/thụt lề). Nếu `old_text` xuất hiện nhiều lần
    mà replace_all=False -> báo lỗi để tránh sửa nhầm; đặt replace_all=True để thay
    tất cả. Trả về diff kiểu git. dry_run=True chỉ xem trước (không cần readwrite),
    ghi thật cần FS_ACCESS_MODE=readwrite.
    """
    if not old_text:
        raise FSError("old_text rỗng.")
    target = resolve_path(path)
    if not os.path.isfile(target):
        raise FSError(f"Không phải tệp: {target}")
    with open(target, "r", encoding="utf-8", errors="replace", newline="") as fh:
        original = fh.read()

    count = original.count(old_text)
    if count == 0:
        raise FSError("Không tìm thấy old_text trong tệp.")
    if count > 1 and not replace_all:
        raise FSError(
            f"old_text xuất hiện {count} lần; thêm ngữ cảnh cho duy nhất "
            f"hoặc đặt replace_all=True."
        )

    updated = original.replace(old_text, new_text) if replace_all else original.replace(
        old_text, new_text, 1
    )
    replaced = count if replace_all else 1

    diff = "".join(
        difflib.unified_diff(
            original.splitlines(keepends=True),
            updated.splitlines(keepends=True),
            fromfile=f"a/{os.path.basename(target)}",
            tofile=f"b/{os.path.basename(target)}",
        )
    )

    if dry_run:
        return _ok(path=target, dry_run=True, replacements=replaced, diff=diff)

    require_write()
    with open(target, "w", encoding="utf-8", newline="") as fh:
        fh.write(updated)
    return _ok(
        path=target,
        dry_run=False,
        replacements=replaced,
        bytes_written=len(updated.encode("utf-8")),
        diff=diff,
    )


@mcp.tool()
def write_text_file(path: str, content: str, overwrite: bool = True) -> dict[str, Any]:
    """Ghi nội dung văn bản vào tệp (tạo mới hoặc ghi đè). Cần readwrite."""
    require_write()
    target = resolve_path(path)
    if os.path.exists(target) and not overwrite:
        raise FSError(f"Tệp đã tồn tại (overwrite=False): {target}")
    if os.path.isdir(target):
        raise FSError(f"Đường dẫn là thư mục: {target}")
    parent = os.path.dirname(target)
    if parent and not os.path.isdir(parent):
        raise FSError(f"Thư mục cha không tồn tại: {parent}")
    with open(target, "w", encoding="utf-8") as fh:
        fh.write(content)
    return _ok(path=target, bytes_written=len(content.encode("utf-8")))


@mcp.tool()
def create_directory(path: str) -> dict[str, Any]:
    """Tạo thư mục (kể cả các cấp cha còn thiếu). Cần readwrite."""
    require_write()
    target = resolve_path(path)
    os.makedirs(target, exist_ok=True)
    return _ok(path=target, created=True)


@mcp.tool()
def move_path(src: str, dst: str) -> dict[str, Any]:
    """Di chuyển hoặc đổi tên tệp/thư mục. Cần readwrite."""
    require_write()
    s = resolve_path(src)
    d = resolve_path(dst)
    if not os.path.exists(s):
        raise FSError(f"Nguồn không tồn tại: {s}")
    if os.path.exists(d):
        raise FSError(f"Đích đã tồn tại: {d}")
    shutil.move(s, d)
    return _ok(src=s, dst=d)


@mcp.tool()
def delete_path(path: str, recursive: bool = False) -> dict[str, Any]:
    """Xoá tệp, hoặc thư mục (recursive=True để xoá cả nội dung bên trong). Cần readwrite."""
    require_write()
    target = resolve_path(path)
    allowed_roots = [os.path.normcase(r) for r in roots()]
    if os.path.normcase(target) in allowed_roots:
        raise FSError(f"Không thể xoá thư mục gốc được cấu hình trong FS_ROOTS: {target}")
    if not os.path.exists(target):
        raise FSError(f"Không tồn tại: {target}")
    if os.path.isdir(target):
        if recursive:
            shutil.rmtree(target)
        else:
            os.rmdir(target)  # chỉ xoá được thư mục rỗng
        return _ok(path=target, deleted=True, type="dir")
    os.remove(target)
    return _ok(path=target, deleted=True, type="file")


def main() -> None:
    """Điểm khởi động: chạy MCP server qua stdio."""
    mcp.run()


if __name__ == "__main__":
    main()
