"""GitLab Model Context Protocol (MCP) Server.

Built for Python 3.10+ (tested on Python 3.14).
Native, lightweight, zero-docker GitLab integration.
Supports repository search, code reading/writing, issues, merge requests,
and CI/CD pipeline/job trace inspection.
"""

from __future__ import annotations

import os
from typing import Any

from mcp.server import MCPServer

try:
    from common import McpError, make_access, ok
except ImportError:
    def ok(**kw: Any) -> dict[str, Any]:
        return {"ok": True, **kw}

    class McpError(Exception):
        pass

    def make_access(env_var: str):
        def access_mode():
            return os.environ.get(env_var, "readwrite")

        def is_readonly():
            return access_mode().lower() == "readonly"

        def require_write():
            if is_readonly():
                raise McpError(f"Operation denied: {env_var}=readonly")

        return access_mode, is_readonly, require_write

try:
    from .helpers import GitLabClient
except ImportError:
    from gitlab_mcp.helpers import GitLabClient

access_mode, is_readonly, require_write = make_access("GITLAB_ACCESS_MODE")

mcp = MCPServer(
    "gitlab",
    instructions=(
        "GitLab API integration server. Supports project exploration, file retrieval/update, "
        "issue management, merge request automation, and CI/CD pipeline/log inspection."
    ),
)


def _client() -> GitLabClient:
    return GitLabClient()


@mcp.tool()
def server_info() -> dict[str, Any]:
    """Retrieve GitLab MCP server status, authentication, and configured instance URL."""
    client = _client()
    try:
        user = client.get_current_user()
        authenticated = True
        username = user.get("username")
        name = user.get("name")
    except Exception as exc:
        authenticated = False
        username = None
        name = None

    return ok(
        access_mode=access_mode(),
        is_readonly=is_readonly(),
        api_url=client.api_url,
        authenticated=authenticated,
        username=username,
        display_name=name,
    )


@mcp.tool()
def gitlab_search_repositories(
    query: str = "",
    membership: bool = False,
    page: int = 1,
    per_page: int = 20,
) -> dict[str, Any]:
    """Search GitLab repositories/projects.
    
    Args:
        query: Search term (e.g. project name)
        membership: Limit to projects the user is a member of (default: False)
        page: Page number for pagination (default: 1)
        per_page: Number of results per page (default: 20, max: 100)
    """
    client = _client()
    projects = client.search_projects(
        query=query,
        page=page,
        per_page=per_page,
        membership=membership,
    )
    items = []
    for p in projects:
        items.append({
            "id": p.get("id"),
            "name": p.get("name"),
            "path_with_namespace": p.get("path_with_namespace"),
            "description": p.get("description"),
            "visibility": p.get("visibility"),
            "default_branch": p.get("default_branch"),
            "web_url": p.get("web_url"),
            "ssh_url": p.get("ssh_url_to_repo"),
            "http_url": p.get("http_url_to_repo"),
            "last_activity_at": p.get("last_activity_at"),
        })
    return ok(projects=items, count=len(items), page=page)


@mcp.tool()
def gitlab_get_project(project_id: str) -> dict[str, Any]:
    """Get detailed information about a GitLab project.
    
    Args:
        project_id: Project ID (e.g. '84560507') or URL-encoded path (e.g. 'khoaivoban/hanzigo')
    """
    client = _client()
    p = client.get_project(project_id)
    return ok(
        id=p.get("id"),
        name=p.get("name"),
        path_with_namespace=p.get("path_with_namespace"),
        description=p.get("description"),
        visibility=p.get("visibility"),
        default_branch=p.get("default_branch"),
        web_url=p.get("web_url"),
        star_count=p.get("star_count", 0),
        forks_count=p.get("forks_count", 0),
        open_issues_count=p.get("open_issues_count", 0),
        created_at=p.get("created_at"),
        last_activity_at=p.get("last_activity_at"),
    )


@mcp.tool()
def gitlab_list_branches(project_id: str, search: str = "") -> dict[str, Any]:
    """List branches of a repository.
    
    Args:
        project_id: Project ID or path
        search: Optional search filter for branch name
    """
    client = _client()
    branches = client.list_branches(project_id, search=search)
    items = [
        {
            "name": b.get("name"),
            "default": b.get("default", False),
            "protected": b.get("protected", False),
            "merged": b.get("merged", False),
        }
        for b in branches
    ]
    return ok(branches=items, count=len(items))


@mcp.tool()
def gitlab_get_file_contents(
    project_id: str,
    file_path: str,
    ref: str = "main",
) -> dict[str, Any]:
    """Get raw contents of a file from a repository.
    
    Args:
        project_id: Project ID or path
        file_path: Relative path to file (e.g. 'README.md', 'src/App.vue')
        ref: Branch name, tag, or commit hash (default: 'main')
    """
    client = _client()
    content = client.get_file_contents(project_id, file_path, ref=ref)
    return ok(
        project_id=project_id,
        file_path=file_path,
        ref=ref,
        content=content,
        size_bytes=len(content.encode("utf-8")),
    )


@mcp.tool()
def gitlab_create_or_update_file(
    project_id: str,
    file_path: str,
    content: str,
    commit_message: str,
    branch: str = "main",
) -> dict[str, Any]:
    """Create or update a file in the repository (requires readwrite mode).
    
    Args:
        project_id: Project ID or path
        file_path: Relative path of the file
        content: String content of the file
        commit_message: Git commit message
        branch: Target branch (default: 'main')
    """
    require_write()
    client = _client()
    res = client.create_or_update_file(
        project_id=project_id,
        file_path=file_path,
        content=content,
        commit_message=commit_message,
        branch=branch,
    )
    return ok(
        file_path=res.get("file_path", file_path),
        branch=res.get("branch", branch),
        commit_message=commit_message,
    )


@mcp.tool()
def gitlab_list_issues(
    project_id: str,
    state: str = "opened",
    page: int = 1,
    per_page: int = 20,
) -> dict[str, Any]:
    """List issues in a GitLab project.
    
    Args:
        project_id: Project ID or path
        state: Issue state ('opened', 'closed', 'all', default: 'opened')
        page: Page number
        per_page: Issues per page
    """
    client = _client()
    issues = client.list_issues(project_id, state=state, page=page, per_page=per_page)
    items = [
        {
            "id": i.get("id"),
            "iid": i.get("iid"),
            "title": i.get("title"),
            "state": i.get("state"),
            "author": (i.get("author") or {}).get("username"),
            "labels": i.get("labels", []),
            "created_at": i.get("created_at"),
            "web_url": i.get("web_url"),
        }
        for i in issues
    ]
    return ok(issues=items, count=len(items))


@mcp.tool()
def gitlab_create_issue(
    project_id: str,
    title: str,
    description: str = "",
    labels: list[str] | None = None,
) -> dict[str, Any]:
    """Create a new issue in a project (requires readwrite mode).
    
    Args:
        project_id: Project ID or path
        title: Issue title
        description: Markdown description
        labels: Optional list of labels (e.g. ['bug', 'frontend'])
    """
    require_write()
    client = _client()
    issue = client.create_issue(project_id, title=title, description=description, labels=labels)
    return ok(
        id=issue.get("id"),
        iid=issue.get("iid"),
        title=issue.get("title"),
        web_url=issue.get("web_url"),
    )


@mcp.tool()
def gitlab_list_merge_requests(
    project_id: str,
    state: str = "opened",
    page: int = 1,
    per_page: int = 20,
) -> dict[str, Any]:
    """List merge requests in a project.
    
    Args:
        project_id: Project ID or path
        state: State ('opened', 'closed', 'merged', 'all')
        page: Page number
        per_page: Results per page
    """
    client = _client()
    mrs = client.list_merge_requests(project_id, state=state, page=page, per_page=per_page)
    items = [
        {
            "id": m.get("id"),
            "iid": m.get("iid"),
            "title": m.get("title"),
            "source_branch": m.get("source_branch"),
            "target_branch": m.get("target_branch"),
            "state": m.get("state"),
            "author": (m.get("author") or {}).get("username"),
            "web_url": m.get("web_url"),
        }
        for m in mrs
    ]
    return ok(merge_requests=items, count=len(items))


@mcp.tool()
def gitlab_create_merge_request(
    project_id: str,
    source_branch: str,
    target_branch: str,
    title: str,
    description: str = "",
) -> dict[str, Any]:
    """Create a new merge request (requires readwrite mode).
    
    Args:
        project_id: Project ID or path
        source_branch: Source feature branch
        target_branch: Target branch to merge into (e.g. 'main')
        title: Title of MR
        description: Detailed description of changes
    """
    require_write()
    client = _client()
    mr = client.create_merge_request(
        project_id=project_id,
        source_branch=source_branch,
        target_branch=target_branch,
        title=title,
        description=description,
    )
    return ok(
        id=mr.get("id"),
        iid=mr.get("iid"),
        title=mr.get("title"),
        web_url=mr.get("web_url"),
        state=mr.get("state"),
    )


@mcp.tool()
def gitlab_list_pipelines(
    project_id: str,
    status: str = "",
    ref: str = "",
    page: int = 1,
    per_page: int = 20,
) -> dict[str, Any]:
    """List CI/CD pipelines of a project.
    
    Args:
        project_id: Project ID or path
        status: Filter by status ('running', 'success', 'failed', 'canceled')
        ref: Filter by branch or tag
        page: Page number
        per_page: Pipelines per page
    """
    client = _client()
    pipelines = client.list_pipelines(project_id, status=status, ref=ref, page=page, per_page=per_page)
    items = [
        {
            "id": p.get("id"),
            "iid": p.get("iid"),
            "status": p.get("status"),
            "ref": p.get("ref"),
            "sha": p.get("sha"),
            "web_url": p.get("web_url"),
            "created_at": p.get("created_at"),
            "updated_at": p.get("updated_at"),
        }
        for p in pipelines
    ]
    return ok(pipelines=items, count=len(items))


@mcp.tool()
def gitlab_get_pipeline_jobs(project_id: str, pipeline_id: int) -> dict[str, Any]:
    """List all jobs in a specific pipeline.
    
    Args:
        project_id: Project ID or path
        pipeline_id: ID of the pipeline
    """
    client = _client()
    jobs = client.get_pipeline_jobs(project_id, pipeline_id=pipeline_id)
    items = [
        {
            "id": j.get("id"),
            "name": j.get("name"),
            "stage": j.get("stage"),
            "status": j.get("status"),
            "duration": j.get("duration"),
            "failure_reason": j.get("failure_reason"),
            "web_url": j.get("web_url"),
        }
        for j in jobs
    ]
    return ok(pipeline_id=pipeline_id, jobs=items, count=len(items))


@mcp.tool()
def gitlab_get_job_log(project_id: str, job_id: int, tail_lines: int = 100) -> dict[str, Any]:
    """Retrieve terminal trace/log of a CI/CD job to debug failures.
    
    Args:
        project_id: Project ID or path
        job_id: ID of the job
        tail_lines: Number of ending lines to return (default: 100, max: 1000)
    """
    client = _client()
    raw_trace = client.get_job_trace(project_id, job_id=job_id)
    lines = raw_trace.splitlines()
    total_lines = len(lines)
    selected = lines[-min(tail_lines, 1000):] if tail_lines > 0 else lines
    return ok(
        project_id=project_id,
        job_id=job_id,
        total_lines=total_lines,
        returned_lines=len(selected),
        log="\n".join(selected),
    )


def main() -> None:
    """Run GitLab MCP server via stdio."""
    mcp.run()


if __name__ == "__main__":
    main()
