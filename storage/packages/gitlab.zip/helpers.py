"""GitLab REST API v4 Client — Zero external dependencies.

Compatible with Python 3.10+ (tested on Python 3.14).
Uses Python standard library: urllib.request, json, urllib.parse.
"""

from __future__ import annotations

import base64
import json
import os
from pathlib import Path
import sys
from typing import Any
import urllib.error
import urllib.parse
import urllib.request

try:
    from common import McpError
except ImportError:
    class McpError(Exception):
        pass


def _load_config_fallback() -> tuple[str, str]:
    """Fallback to mcp.config.json if environment variables are not set."""
    candidates = [
        Path.cwd() / "mcp.config.json",
        Path(__file__).resolve().parent.parent.parent / "mcp.config.json",
        Path(sys.executable).parent.parent / "mcp.config.json",
        Path("D:/AI_MCP/mcp.config.json"),
    ]
    for c in candidates:
        if c.is_file():
            try:
                with open(c, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    gitlab_cfg = data.get("servers", {}).get("gitlab", {}).get("env", {})
                    token = gitlab_cfg.get("GITLAB_TOKEN", "")
                    url = gitlab_cfg.get("GITLAB_URL", "")
                    if token or url:
                        return url, token
            except Exception:
                pass
    return "", ""


class GitLabClient:
    """Lightweight, resilient GitLab REST API v4 Client."""

    def __init__(
        self,
        base_url: str | None = None,
        token: str | None = None,
        timeout: float = 20.0,
    ) -> None:
        fallback_url, fallback_token = "", ""
        if not token and not os.environ.get("GITLAB_TOKEN"):
            fallback_url, fallback_token = _load_config_fallback()

        raw_url = base_url or os.environ.get("GITLAB_URL") or fallback_url or "https://gitlab.com"
        clean_url = raw_url.rstrip("/")
        if not clean_url.endswith("/api/v4"):
            clean_url = f"{clean_url}/api/v4"
        self.api_url = clean_url
        self.token = (token or os.environ.get("GITLAB_TOKEN") or fallback_token).strip()
        self.timeout = timeout

    def _headers(self) -> dict[str, str]:
        headers = {
            "User-Agent": "AI-MCP-GitLab-Client/1.0",
            "Accept": "application/json",
        }
        if self.token:
            headers["Authorization"] = f"Bearer {self.token}"
        return headers

    def _encode_id(self, project_id: str | int) -> str:
        """Encode project path or ID for GitLab API."""
        return urllib.parse.quote(str(project_id), safe="")

    def request(
        self,
        endpoint: str,
        method: str = "GET",
        params: dict[str, Any] | None = None,
        data: dict[str, Any] | None = None,
        raw_text: bool = False,
    ) -> Any:
        """Execute HTTP request against GitLab REST API."""
        clean_endpoint = endpoint.lstrip("/")
        url = f"{self.api_url}/{clean_endpoint}"

        if params:
            filtered_params = {k: v for k, v in params.items() if v is not None}
            if filtered_params:
                url = f"{url}?{urllib.parse.urlencode(filtered_params)}"

        body_bytes = None
        headers = self._headers()
        if data is not None:
            body_bytes = json.dumps(data).encode("utf-8")
            headers["Content-Type"] = "application/json; charset=utf-8"

        req = urllib.request.Request(
            url=url,
            data=body_bytes,
            headers=headers,
            method=method.upper(),
        )

        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                raw = resp.read()
                if raw_text:
                    return raw.decode("utf-8", errors="replace")
                if not raw:
                    return {}
                return json.loads(raw.decode("utf-8"))
        except urllib.error.HTTPError as exc:
            err_body = exc.read().decode("utf-8", errors="replace")
            try:
                err_json = json.loads(err_body)
                msg = err_json.get("message") or err_json.get("error") or err_body
            except Exception:
                msg = err_body or str(exc)
            raise McpError(f"GitLab API Error [{exc.code}]: {msg}") from exc
        except urllib.error.URLError as exc:
            raise McpError(f"Network error connecting to GitLab ({self.api_url}): {exc.reason}") from exc

    # ==========================
    # User & Project Operations
    # ==========================
    def get_current_user(self) -> dict[str, Any]:
        """Get authenticated user profile."""
        return self.request("user")

    def search_projects(
        self,
        query: str = "",
        page: int = 1,
        per_page: int = 20,
        membership: bool = False,
        starred: bool = False,
    ) -> list[dict[str, Any]]:
        """Search GitLab projects."""
        params: dict[str, Any] = {
            "page": page,
            "per_page": min(per_page, 100),
            "order_by": "last_activity_at",
            "sort": "desc",
        }
        if query:
            params["search"] = query
        if membership:
            params["membership"] = "true"
        if starred:
            params["starred"] = "true"
        return self.request("projects", params=params)

    def get_project(self, project_id: str | int) -> dict[str, Any]:
        """Get project details."""
        pid = self._encode_id(project_id)
        return self.request(f"projects/{pid}")

    def list_branches(self, project_id: str | int, search: str = "") -> list[dict[str, Any]]:
        """List repository branches."""
        pid = self._encode_id(project_id)
        params = {"search": search} if search else None
        return self.request(f"projects/{pid}/repository/branches", params=params)

    # ==========================
    # File Operations
    # ==========================
    def get_file_contents(
        self,
        project_id: str | int,
        file_path: str,
        ref: str = "main",
    ) -> str:
        """Get raw contents of a file in the repository."""
        pid = self._encode_id(project_id)
        fpath = urllib.parse.quote(file_path.strip("/"), safe="")
        return self.request(
            f"projects/{pid}/repository/files/{fpath}/raw",
            params={"ref": ref},
            raw_text=True,
        )

    def create_or_update_file(
        self,
        project_id: str | int,
        file_path: str,
        content: str,
        commit_message: str,
        branch: str = "main",
    ) -> dict[str, Any]:
        """Create or update a file in the repository."""
        pid = self._encode_id(project_id)
        fpath = urllib.parse.quote(file_path.strip("/"), safe="")
        payload = {
            "branch": branch,
            "content": content,
            "commit_message": commit_message,
        }

        # Check if file exists to decide between POST (create) and PUT (update)
        try:
            self.request(f"projects/{pid}/repository/files/{fpath}", params={"ref": branch})
            method = "PUT"
        except McpError:
            method = "POST"

        return self.request(
            f"projects/{pid}/repository/files/{fpath}",
            method=method,
            data=payload,
        )

    # ==========================
    # Issues & Merge Requests
    # ==========================
    def list_issues(
        self,
        project_id: str | int,
        state: str = "opened",
        page: int = 1,
        per_page: int = 20,
    ) -> list[dict[str, Any]]:
        """List project issues."""
        pid = self._encode_id(project_id)
        params = {"state": state, "page": page, "per_page": per_page}
        return self.request(f"projects/{pid}/issues", params=params)

    def create_issue(
        self,
        project_id: str | int,
        title: str,
        description: str = "",
        labels: list[str] | None = None,
        assignee_ids: list[int] | None = None,
    ) -> dict[str, Any]:
        """Create a new issue."""
        pid = self._encode_id(project_id)
        payload: dict[str, Any] = {"title": title, "description": description}
        if labels:
            payload["labels"] = ",".join(labels)
        if assignee_ids:
            payload["assignee_ids"] = assignee_ids
        return self.request(f"projects/{pid}/issues", method="POST", data=payload)

    def list_merge_requests(
        self,
        project_id: str | int,
        state: str = "opened",
        page: int = 1,
        per_page: int = 20,
    ) -> list[dict[str, Any]]:
        """List merge requests."""
        pid = self._encode_id(project_id)
        params = {"state": state, "page": page, "per_page": per_page}
        return self.request(f"projects/{pid}/merge_requests", params=params)

    def create_merge_request(
        self,
        project_id: str | int,
        source_branch: str,
        target_branch: str,
        title: str,
        description: str = "",
        remove_source_branch: bool = True,
    ) -> dict[str, Any]:
        """Create a new merge request."""
        pid = self._encode_id(project_id)
        payload = {
            "source_branch": source_branch,
            "target_branch": target_branch,
            "title": title,
            "description": description,
            "remove_source_branch": remove_source_branch,
        }
        return self.request(f"projects/{pid}/merge_requests", method="POST", data=payload)

    # ==========================
    # CI/CD Pipelines & Jobs
    # ==========================
    def list_pipelines(
        self,
        project_id: str | int,
        status: str = "",
        ref: str = "",
        page: int = 1,
        per_page: int = 20,
    ) -> list[dict[str, Any]]:
        """List CI/CD pipelines."""
        pid = self._encode_id(project_id)
        params: dict[str, Any] = {"page": page, "per_page": per_page}
        if status:
            params["status"] = status
        if ref:
            params["ref"] = ref
        return self.request(f"projects/{pid}/pipelines", params=params)

    def get_pipeline_jobs(self, project_id: str | int, pipeline_id: int) -> list[dict[str, Any]]:
        """Get jobs in a specific pipeline."""
        pid = self._encode_id(project_id)
        return self.request(f"projects/{pid}/pipelines/{pipeline_id}/jobs")

    def get_job_trace(self, project_id: str | int, job_id: int) -> str:
        """Get raw terminal trace/log of a CI/CD job."""
        pid = self._encode_id(project_id)
        return self.request(f"projects/{pid}/jobs/{job_id}/trace", raw_text=True)
