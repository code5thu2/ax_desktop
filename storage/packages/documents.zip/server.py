"""MCP server đọc tài liệu: trích text từ .docx/.pdf/.pptx/.txt/.md.

Chạy: python -m docs_mcp   (transport stdio)
Cấu hình: DOCS_MAX_CHARS (giới hạn ký tự mỗi lần đọc, mặc định 200000).

Bổ sung cho excel_mcp (lo .xlsx): docs_mcp lo các định dạng văn bản còn lại.
Thư viện nạp lười theo từng định dạng nên server khởi động nhanh và chỉ báo lỗi
khi thực sự đọc định dạng cần lib chưa cài.
"""

from __future__ import annotations

import os
from typing import Any

from mcp.server import MCPServer
from mcp.types import CallToolResult
from common import image_blocks, templates
from common import ok as _ok

from .helpers import (
    APPEND_EXTS,
    TABLE_PRESETS,
    VISION_OK_MIME,
    DocError,
    access_mode,
    attach_file_to_docx_helper,
    convert_doc_to_docx as _convert_doc_to_docx,
    ensure_docx_or_new,
    ensure_docx_path,
    ext_of,
    extract_docx_placeholders,
    extract_table_matrix,
    iter_document_images,
    pdf_font,
    prepare_docx_context,
    replace_runs_text,
    require_write,
    resolve_doc_path,
    resolve_write_path,
    set_cell_background,
    set_cell_borders,
    set_cell_margins,
)
from .helpers import max_chars as default_max_chars

mcp = MCPServer(
    "documents",
    instructions=(
        "Đọc và trích văn bản từ tài liệu .docx/.pdf/.pptx/.txt/.md để AI phân "
        "tích; đồng thời tạo/ghi tài liệu .docx/.txt/.md khi DOCS_ACCESS_MODE="
        "readwrite. Dùng document_info xem cấu trúc, read_document lấy nội dung. "
        "File .xlsx dùng excel_mcp."
    ),
)


def _cap(text: str, limit: int) -> tuple[str, bool]:
    if len(text) > limit:
        return text[:limit], True
    return text, False


def _parse_pages(page_range: str | None, total: int) -> list[int]:
    """Chuyển '1-3,5' -> [0,1,2,4] (0-based). None -> tất cả trang."""
    if not page_range:
        return list(range(total))
    pages: list[int] = []
    for part in page_range.replace(" ", "").split(","):
        if not part:
            continue
        if "-" in part:
            a, b = part.split("-", 1)
            start, end = int(a), int(b)
            pages.extend(range(start, end + 1))
        else:
            pages.append(int(part))
    # về 0-based, lọc hợp lệ, bỏ trùng, giữ thứ tự
    seen: set[int] = set()
    out: list[int] = []
    for p in pages:
        idx = p - 1
        if 0 <= idx < total and idx not in seen:
            seen.add(idx)
            out.append(idx)
    return out


# --------------------------------------------------------------------------- #
# Trích text theo từng định dạng (import lười)
# --------------------------------------------------------------------------- #
def _read_docx(path: str) -> tuple[str, dict[str, Any]]:
    working_path, temp_clean = ensure_docx_path(path)
    try:
        try:
            import docx  # noqa: PLC0415  (python-docx)
        except ImportError as exc:  # pragma: no cover
            raise DocError("Chưa cài python-docx. Chạy: pip install python-docx") from exc
        doc = docx.Document(working_path)
        parts = [p.text for p in doc.paragraphs if p.text.strip()]
        for tbl in doc.tables:
            for row in tbl.rows:
                cells = [c.text.strip() for c in row.cells]
                if any(cells):
                    parts.append(" | ".join(cells))
        meta = {"paragraphs": len(doc.paragraphs), "tables": len(doc.tables)}
        return "\n".join(parts), meta
    finally:
        if temp_clean and os.path.exists(temp_clean):
            try:
                os.remove(temp_clean)
            except OSError:
                pass


def _open_pdf(path: str):
    """Mở PDF nguồn (phải là .pdf tồn tại) -> (src_path, PdfReader)."""
    src = resolve_doc_path(path)
    if ext_of(src) != ".pdf":
        raise DocError(f"Không phải PDF: {src}")
    try:
        from pypdf import PdfReader  # noqa: PLC0415
    except ImportError as exc:  # pragma: no cover
        raise DocError("Chưa cài pypdf. Chạy: pip install pypdf") from exc

    reader = PdfReader(src)
    if reader.is_encrypted:
        try:
            if not reader.decrypt(""):
                raise DocError(f"File PDF yêu cầu mật khẩu giải mã: {src}")
        except DocError:
            raise
        except Exception as exc:
            raise DocError(f"Không thể giải mã PDF '{src}': {exc}") from exc
    return src, reader


def _read_pdf(path: str, page_range: str | None) -> tuple[str, dict[str, Any]]:
    _src, reader = _open_pdf(path)
    total = len(reader.pages)
    idxs = _parse_pages(page_range, total)
    parts = []
    for i in idxs:
        parts.append(reader.pages[i].extract_text() or "")
    meta = {"pages": total, "pages_read": len(idxs)}
    return "\n".join(parts), meta


def _read_pptx(path: str) -> tuple[str, dict[str, Any]]:
    try:
        from pptx import Presentation  # noqa: PLC0415  (python-pptx)
    except ImportError as exc:  # pragma: no cover
        raise DocError("Chưa cài python-pptx. Chạy: pip install python-pptx") from exc
    prs = Presentation(path)
    parts = []
    for n, slide in enumerate(prs.slides, 1):
        texts = [sh.text for sh in slide.shapes if sh.has_text_frame and sh.text.strip()]
        if texts:
            parts.append(f"--- Slide {n} ---")
            parts.extend(texts)
    meta = {"slides": len(prs.slides)}
    return "\n".join(parts), meta


def _read_plain(path: str, max_chars: int | None = None) -> tuple[str, dict[str, Any]]:
    with open(path, "rb") as fh:
        to_read = (max_chars * 4) if max_chars and max_chars > 0 else -1
        raw = fh.read(to_read)
    return raw.decode("utf-8", errors="replace"), {}


def _extract(
    path: str, page_range: str | None, max_chars: int | None = None
) -> tuple[str, dict[str, Any]]:
    ext = ext_of(path)
    if ext in (".docx", ".doc"):
        return _read_docx(path)
    if ext == ".pdf":
        return _read_pdf(path, page_range)
    if ext == ".pptx":
        return _read_pptx(path)
    return _read_plain(path, max_chars=max_chars)  # .txt / .md


# ========================================================================== #
# Tool
# ========================================================================== #
@mcp.tool()
def document_info(path: str) -> dict[str, Any]:
    """Xem thông tin tài liệu: loại, kích thước, số trang/đoạn/slide, metadata."""
    target = resolve_doc_path(path)
    ext = ext_of(target)
    info: dict[str, Any] = {
        "path": target,
        "type": ext.lstrip("."),
        "size": os.path.getsize(target),
    }
    if ext in (".docx", ".doc"):
        working_path, temp_clean = ensure_docx_path(target)
        try:
            try:
                import docx  # noqa: PLC0415
            except ImportError as exc:  # pragma: no cover
                raise DocError("Chưa cài python-docx. Chạy: pip install python-docx") from exc
            doc = docx.Document(working_path)
            cp = doc.core_properties
            info.update(
                paragraphs=len(doc.paragraphs),
                tables=len(doc.tables),
                title=cp.title or None,
                author=cp.author or None,
                created=cp.created.isoformat() if cp.created else None,
            )
        finally:
            if temp_clean and os.path.exists(temp_clean):
                try:
                    os.remove(temp_clean)
                except OSError:
                    pass
    elif ext == ".pdf":
        _src, reader = _open_pdf(target)
        md = reader.metadata or {}
        info.update(
            pages=len(reader.pages),
            title=getattr(md, "title", None),
            author=getattr(md, "author", None),
        )
    elif ext == ".pptx":
        try:
            from pptx import Presentation  # noqa: PLC0415
        except ImportError as exc:  # pragma: no cover
            raise DocError("Chưa cài python-pptx. Chạy: pip install python-pptx") from exc
        info["slides"] = len(Presentation(target).slides)
    return _ok(**info)


@mcp.tool()
def read_document(
    path: str, max_chars: int | None = None, page_range: str | None = None
) -> dict[str, Any]:
    """Trích toàn bộ văn bản của tài liệu (giới hạn theo DOCS_MAX_CHARS).

    page_range chỉ áp dụng cho PDF, ví dụ "1-5" hoặc "1,3,7" (đánh số từ 1).
    max_chars ghi đè giới hạn mặc định (không vượt quá DOCS_MAX_CHARS).
    """
    target = resolve_doc_path(path)
    hard_cap = default_max_chars()
    limit = min(max_chars, hard_cap) if max_chars else hard_cap
    text, meta = _extract(target, page_range, max_chars=limit)
    text, truncated = _cap(text, limit)
    return _ok(
        path=target,
        type=ext_of(target).lstrip("."),
        char_count=len(text),
        truncated=truncated,
        content=text,
        **meta,
    )


@mcp.tool()
def server_info() -> dict[str, Any]:
    """Xem chế độ truy cập, định dạng đọc/ghi được hỗ trợ."""
    return _ok(
        access_mode=access_mode(),
        read_formats=[".docx", ".pdf", ".pptx", ".txt", ".md"],
        write_formats=[".docx", ".txt", ".md", ".pdf"],
        pdf_tools=["merge_pdf", "split_pdf", "rotate_pdf"],
    )


# ========================================================================== #
# Ảnh nhúng (cho AI vision đọc/hiểu nội dung ảnh)
# ========================================================================== #
@mcp.tool()
def list_document_images(path: str) -> dict[str, Any]:
    """Liệt kê ảnh nhúng trong tài liệu (docx/pptx/pdf) — chỉ metadata.

    Trả về tên file, định dạng, kích thước, vị trí (trang với PDF) — để biết có
    ảnh nào trước khi gọi read_document_images.
    """
    resolve_doc_path(path)
    items = [
        {
            "index": i,
            "location": im["location"],
            "filename": im["filename"],
            "mime": im["mime"],
            "bytes": im["bytes"],
            "width": im["width"],
            "height": im["height"],
            "vision_supported": im["mime"] in VISION_OK_MIME,
        }
        for i, im in enumerate(iter_document_images(path))
    ]
    return _ok(count=len(items), images=items)


@mcp.tool()
def read_document_images(
    path: str, index: int | None = None, max_images: int = 20
) -> CallToolResult:
    """Trả ảnh nhúng dưới dạng image content để AI/model vision xem nội dung.

    index=None -> mọi ảnh (giới hạn max_images); index=N -> chỉ ảnh thứ N theo
    thứ tự của list_document_images. Ảnh định dạng vector (emf/wmf) chỉ báo metadata.
    """
    resolve_doc_path(path)
    selected = [
        (i, im)
        for i, im in enumerate(iter_document_images(path))
        if index is None or i == index
    ]
    if not selected:
        raise DocError(
            "Không tìm thấy ảnh phù hợp. Dùng list_document_images để xem ảnh có sẵn."
        )

    items = []
    for i, im in selected:
        loc = im["location"] or "tài liệu"
        dims = (
            f"{im['width']}x{im['height']}px"
            if im["width"] and im["height"]
            else f"{im['bytes']} bytes"
        )
        items.append(
            {
                "caption": f"[#{i}] {im['filename']} — {loc} — {dims} ({im['mime']})",
                "mime": im["mime"],
                "data": im["data"],
            }
        )
    return image_blocks(items, max_images=max_images)


# ========================================================================== #
# Tool ghi (chỉ khi DOCS_ACCESS_MODE=readwrite)
# ========================================================================== #
@mcp.tool()
def write_document(path: str, content: str, overwrite: bool = False) -> dict[str, Any]:
    """Tạo/ghi tài liệu từ văn bản. Hỗ trợ .docx/.txt/.md/.pdf. Cần readwrite.

    .docx: mỗi dòng -> một đoạn. .txt/.md: ghi thẳng. .pdf: dựng bằng fpdf2
    (dùng font unicode để in được tiếng Việt/Hàn). overwrite=False -> báo lỗi nếu đã có.
    """
    require_write()
    target = resolve_write_path(path)
    existed = os.path.exists(target)
    if existed and not overwrite:
        raise DocError(f"Tệp đã tồn tại (overwrite=False): {target}")
    _save_text(target, content, append=False)
    return _ok(path=target, bytes=len(content.encode("utf-8")), overwritten=existed)


@mcp.tool()
def append_document(path: str, content: str) -> dict[str, Any]:
    """Nối thêm văn bản vào cuối tài liệu .docx/.txt/.md đã có. Cần readwrite.

    (PDF không hỗ trợ nối thêm — dùng write_document để tạo mới.)
    """
    require_write()
    target = resolve_write_path(path, exts=APPEND_EXTS)
    if not os.path.isfile(target):
        raise DocError(f"Tệp chưa tồn tại: {target}. Dùng write_document để tạo mới.")
    _save_text(target, content, append=True)
    return _ok(path=target, appended_chars=len(content))


def _save_text(target: str, content: str, append: bool) -> None:
    ext = ext_of(target)
    if ext in (".txt", ".md"):
        with open(target, "a" if append else "w", encoding="utf-8") as fh:
            fh.write(content)
        return
    if ext == ".pdf":
        _save_pdf(target, content)
        return
    # .docx
    try:
        import docx  # noqa: PLC0415
    except ImportError as exc:  # pragma: no cover
        raise DocError("Chưa cài python-docx. Chạy: pip install python-docx") from exc
    doc = docx.Document(target) if (append and os.path.isfile(target)) else docx.Document()
    for line in content.split("\n"):
        doc.add_paragraph(line)
    doc.save(target)


def _save_pdf(target: str, content: str) -> None:
    try:
        from fpdf import FPDF  # noqa: PLC0415  (fpdf2)
    except ImportError as exc:  # pragma: no cover
        raise DocError("Chưa cài fpdf2. Chạy: pip install fpdf2") from exc
    import logging  # noqa: PLC0415

    logging.getLogger("fontTools").setLevel(logging.ERROR)  # tắt log subset font ồn ào
    pdf = FPDF()
    pdf.set_auto_page_break(True, margin=15)
    pdf.add_page()
    font = pdf_font(content)
    if font:
        pdf.add_font("uni", "", font)      # font unicode -> in được tiếng Việt/Hàn
        pdf.set_font("uni", size=12)
    else:
        pdf.set_font("Helvetica", size=12)  # chỉ Latin-1
    width = pdf.epw  # bề rộng in hữu dụng (trừ lề)
    for line in content.split("\n"):
        pdf.multi_cell(width, 8, line if line.strip() else " ")
    pdf.output(target)


# ========================================================================== #
# Thao tác PDF (pypdf) — cần readwrite
# ========================================================================== #


def _write_pdf(writer, output: str, overwrite: bool) -> str:
    out = resolve_write_path(output, exts={".pdf"})
    if os.path.exists(out) and not overwrite:
        raise DocError(f"Tệp đã tồn tại (overwrite=False): {out}")
    with open(out, "wb") as fh:
        writer.write(fh)
    return out


@mcp.tool()
def merge_pdf(paths: list[str], output: str, overwrite: bool = False) -> dict[str, Any]:
    """Gộp nhiều PDF thành một (theo thứ tự `paths`). Cần readwrite."""
    require_write()
    from pypdf import PdfWriter  # noqa: PLC0415

    writer = PdfWriter()
    total = 0
    for p in paths:
        _src, reader = _open_pdf(p)
        for page in reader.pages:
            writer.add_page(page)
            total += 1
    out = _write_pdf(writer, output, overwrite)
    return _ok(output=out, sources=len(paths), pages=total)


@mcp.tool()
def split_pdf(
    path: str, output: str, page_range: str | None = None, overwrite: bool = False
) -> dict[str, Any]:
    """Trích các trang của PDF ra một PDF mới. page_range vd "1-5" hoặc "1,3,7".

    Bỏ trống page_range -> lấy tất cả. Cần readwrite.
    """
    require_write()
    from pypdf import PdfWriter  # noqa: PLC0415

    _src, reader = _open_pdf(path)
    idxs = _parse_pages(page_range, len(reader.pages))
    writer = PdfWriter()
    for i in idxs:
        writer.add_page(reader.pages[i])
    out = _write_pdf(writer, output, overwrite)
    return _ok(output=out, pages=len(idxs), of_total=len(reader.pages))


@mcp.tool()
def rotate_pdf(
    path: str,
    output: str,
    degrees: int = 90,
    page_range: str | None = None,
    overwrite: bool = False,
) -> dict[str, Any]:
    """Xoay trang PDF (bội số 90 độ). page_range=None -> xoay mọi trang. Cần readwrite."""
    require_write()
    if degrees % 90 != 0:
        raise DocError("degrees phải là bội số của 90.")
    from pypdf import PdfWriter  # noqa: PLC0415

    _src, reader = _open_pdf(path)
    targets = set(_parse_pages(page_range, len(reader.pages)))
    writer = PdfWriter()
    for i, page in enumerate(reader.pages):
        if i in targets:
            page.rotate(degrees)
        writer.add_page(page)
    out = _write_pdf(writer, output, overwrite)
    return _ok(output=out, rotated=len(targets), degrees=degrees)


# ========================================================================== #
# Điền template .docx / .doc (docxtpl — Jinja & Bracket) — cần readwrite
# ========================================================================== #
def _render_docx(src: str, output: str, context: dict[str, Any], overwrite: bool) -> dict[str, Any]:
    out = resolve_write_path(output, exts={".docx"})
    if os.path.exists(out) and not overwrite:
        raise DocError(f"Tệp đã tồn tại (overwrite=False): {out}")
    working_src, temp_to_clean = ensure_docx_path(src)
    try:
        try:
            from docxtpl import DocxTemplate  # noqa: PLC0415
        except ImportError as exc:  # pragma: no cover
            raise DocError("Chưa cài docxtpl. Chạy: pip install docxtpl") from exc

        doc = DocxTemplate(working_src)
        jinja_ctx, bracket_rep = prepare_docx_context(doc, context)

        # Render Jinja tags
        if jinja_ctx:
            doc.render(jinja_ctx)
        doc.save(out)

        # Xử lý các placeholder dạng bracket [Tên], <Tên>, {Tên} (nếu có)
        if bracket_rep:
            import docx  # noqa: PLC0415
            rendered_doc = docx.Document(out)
            for p in rendered_doc.paragraphs:
                for k, v in bracket_rep.items():
                    replace_runs_text(p, k, v)
            for tbl in rendered_doc.tables:
                for row in tbl.rows:
                    for cell in row.cells:
                        for p in cell.paragraphs:
                            for k, v in bracket_rep.items():
                                replace_runs_text(p, k, v)
            for sec in rendered_doc.sections:
                for p in sec.header.paragraphs:
                    for k, v in bracket_rep.items():
                        replace_runs_text(p, k, v)
                for p in sec.footer.paragraphs:
                    for k, v in bracket_rep.items():
                        replace_runs_text(p, k, v)
            rendered_doc.save(out)
    finally:
        if temp_to_clean and os.path.exists(temp_to_clean):
            try:
                os.remove(temp_to_clean)
            except OSError:
                pass

    return _ok(template=src, output=out, keys=sorted(context.keys()))


@mcp.tool()
def fill_docx_template(
    template: str, output: str, context: dict[str, Any], overwrite: bool = False
) -> dict[str, Any]:
    """Điền template Word .docx hoặc .doc bằng docxtpl (Jinja) & bracket tags, GIỮ NGUYÊN style.

    Hỗ trợ:
    - Cú pháp Jinja: `{{ ten }}`, `{% for r in rows %}...{% endfor %}`.
    - Nhúng ảnh/chữ ký tự động: context chứa `{"signature": {"image_path": "...", "width_mm": 40}}`
      hoặc đường dẫn ảnh .png/.jpg.
    - Điền placeholder dạng ngoặc: `[Họ và tên]`, `<TEN_KHACH>`, `{GIA}`.
    - Template đầu vào là `.docx` hoặc `.doc` (tự động chuyển đổi nếu là .doc).
    Cần readwrite.
    """
    require_write()
    src = resolve_doc_path(template)
    if ext_of(src) not in (".docx", ".doc"):
        raise DocError(f"Template phải là .docx hoặc .doc: {src}")
    return _render_docx(src, output, context, overwrite)


@mcp.tool()
def get_docx_template_placeholders(path: str) -> dict[str, Any]:
    """Khảo sát và trích xuất toàn bộ placeholder trong template Word (.doc, .docx).

    Phát hiện:
    - Biến Jinja: `{{ ten }}`, `{% for item in items %}`
    - Biến dạng ngoặc: `[Họ và tên]`, `<TEN_KHACH_HANG>`, `{SO_TIEN}`
    Tìm trong toàn bộ văn bản (đoạn văn, bảng biểu, ô cell, header/footer).
    Giúp AI biết chính xác các biến cần điền mà không cần mở file.
    """
    working_path, temp_clean = ensure_docx_path(path)
    try:
        import docx  # noqa: PLC0415
        doc = docx.Document(working_path)
        info = extract_docx_placeholders(doc)
        info["path"] = path
        return _ok(**info)
    finally:
        if temp_clean and os.path.exists(temp_clean):
            try:
                os.remove(temp_clean)
            except OSError:
                pass


@mcp.tool()
def replace_document_text(
    path: str,
    output: str,
    replacements: dict[str, str],
    overwrite: bool = False,
) -> dict[str, Any]:
    """Thay thế văn bản/placeholder trong Word (.doc, .docx) với độ chính xác tuyệt đối (Không sai một ly).

    Giải quyết triệt để lỗi phân mảnh Run (Split-Run XML):
    Ngay cả khi placeholder (vd `[Họ và tên]`) bị tách qua nhiều run XML khác nhau,
    công cụ vẫn thay thế chuẩn xác và GIỮ NGUYÊN 100% định dạng (font chữ, cỡ chữ,
    in đậm bold, in nghiêng italic, màu chữ, gạch chân).
    Hỗ trợ thay thế nhiều dòng ('\\n' chuyển thành line break).
    Áp dụng cho đoạn văn (paragraphs), bảng biểu (tables/cells), và header/footer.
    Cần readwrite.
    """
    require_write()
    working_path, temp_clean = ensure_docx_path(path)
    out = resolve_write_path(output, exts={".docx"})
    if os.path.exists(out) and not overwrite:
        raise DocError(f"Tệp đã tồn tại (overwrite=False): {out}")

    try:
        import docx  # noqa: PLC0415
        doc = docx.Document(working_path)
        total_replaced = 0

        # Paragraphs
        for p in doc.paragraphs:
            for k, v in replacements.items():
                total_replaced += replace_runs_text(p, k, str(v))

        # Tables
        for tbl in doc.tables:
            for row in tbl.rows:
                for cell in row.cells:
                    for p in cell.paragraphs:
                        for k, v in replacements.items():
                            total_replaced += replace_runs_text(p, k, str(v))

        # Sections (Header / Footer)
        for sec in doc.sections:
            for p in sec.header.paragraphs:
                for k, v in replacements.items():
                    total_replaced += replace_runs_text(p, k, str(v))
            for p in sec.footer.paragraphs:
                for k, v in replacements.items():
                    total_replaced += replace_runs_text(p, k, str(v))

        doc.save(out)
        return _ok(
            source=path,
            output=out,
            replacements_made=total_replaced,
            keys=sorted(replacements.keys()),
        )
    finally:
        if temp_clean and os.path.exists(temp_clean):
            try:
                os.remove(temp_clean)
            except OSError:
                pass


@mcp.tool()
def fill_docx_table(
    path: str,
    output: str,
    table_index: int = 0,
    rows_data: list[dict[str, Any]] | None = None,
    template_row_index: int = 1,
    overwrite: bool = False,
) -> dict[str, Any]:
    """Nhân bản hàng mẫu (template row) trong bảng Word để điền danh sách dữ liệu động.

    Giữ nguyên 100% định dạng hàng ("Không sai một ly"):
    - Màu nền ô (cell shading/background fill)
    - Đường viền ô (borders)
    - Căn lề ô và đoạn văn (alignment)
    - Font chữ, cỡ chữ, bold, italic, màu sắc của từng ô
    - Vị trí hàng tổng cộng / footer bên dưới không bị lệch.

    table_index: Thứ tự bảng trong file (0-based, mặc định 0).
    rows_data: Danh sách các dict dữ liệu, ví dụ:
               [{"{{stt}}": "1", "{{ten}}": "Sản phẩm A", "{{gia}}": "100.000"}, ...]
               hoặc dùng placeholder dạng `[STT]`, `[TEN]`.
    template_row_index: Vị trí hàng mẫu trong bảng (thường là hàng 1 sau hàng tiêu đề 0).
    Cần readwrite.
    """
    require_write()
    if rows_data is None:
        rows_data = []

    working_path, temp_clean = ensure_docx_path(path)
    out = resolve_write_path(output, exts={".docx"})
    if os.path.exists(out) and not overwrite:
        raise DocError(f"Tệp đã tồn tại (overwrite=False): {out}")

    try:
        import copy  # noqa: PLC0415
        import docx  # noqa: PLC0415
        from docx.table import _Row  # noqa: PLC0415

        doc = docx.Document(working_path)
        if not doc.tables or table_index >= len(doc.tables):
            raise DocError(f"Không tìm thấy bảng chỉ số {table_index} (tổng số bảng: {len(doc.tables)}).")

        tbl = doc.tables[table_index]
        if template_row_index >= len(tbl.rows):
            raise DocError(
                f"template_row_index={template_row_index} vượt quá số hàng của bảng ({len(tbl.rows)} hàng)."
            )

        tpl_tr = tbl.rows[template_row_index]._tr
        last_tr = tpl_tr

        for row_dict in rows_data:
            new_tr = copy.deepcopy(tpl_tr)
            last_tr.addnext(new_tr)
            last_tr = new_tr
            new_row = _Row(new_tr, tbl)
            for cell in new_row.cells:
                for p in cell.paragraphs:
                    for k, v in row_dict.items():
                        replace_runs_text(p, str(k), str(v))

        # Xoá hàng mẫu ban đầu sau khi đã nhân bản
        tbl._tbl.remove(tpl_tr)
        doc.save(out)

        return _ok(
            source=path,
            output=out,
            table_index=table_index,
            rows_generated=len(rows_data),
            total_rows_now=len(tbl.rows),
        )
    finally:
        if temp_clean and os.path.exists(temp_clean):
            try:
                os.remove(temp_clean)
            except OSError:
                pass


@mcp.tool()
def list_docx_tables(path: str) -> dict[str, Any]:
    """Khảo sát và liệt kê toàn bộ bảng trong tài liệu Word (.docx hoặc .doc).

    Trả về: danh sách bảng, chỉ số (0-based), số hàng, số cột, tiêu đề cột và preview dữ liệu.
    """
    working_path, temp_clean = ensure_docx_path(path)
    try:
        import docx  # noqa: PLC0415

        doc = docx.Document(working_path)
        tables_info = []
        for idx, tbl in enumerate(doc.tables):
            headers, matrix = extract_table_matrix(tbl, propagate_merged_values=False)
            tables_info.append(
                {
                    "table_index": idx,
                    "rows_count": len(tbl.rows),
                    "columns_count": len(tbl.columns),
                    "headers": headers,
                    "preview": matrix[:3] if len(matrix) > 1 else matrix,
                }
            )
        return _ok(path=path, total_tables=len(doc.tables), tables=tables_info)
    finally:
        if temp_clean and os.path.exists(temp_clean):
            try:
                os.remove(temp_clean)
            except OSError:
                pass


@mcp.tool()
def read_docx_table(
    path: str,
    table_index: int = 0,
    as_records: bool = True,
    propagate_merged_values: bool = False,
) -> dict[str, Any]:
    """Trích xuất dữ liệu có cấu trúc từ một bảng cụ thể trong Word (.docx, .doc).

    Tự động xử lý ô gộp (Merged Cells): Khử triệt để lỗi in lặp text do ô gộp của OpenXML.
    - as_records=True -> trả về danh sách dict theo tiêu đề cột: [{"Cột A": "giá trị 1"}, ...].
    - as_records=False -> trả về ma trận lưới 2 chiều (matrix).
    - propagate_merged_values=False -> các ô gộp phụ nhận giá trị None; True -> nhân bản giá trị ô gốc.
    """
    working_path, temp_clean = ensure_docx_path(path)
    try:
        import docx  # noqa: PLC0415

        doc = docx.Document(working_path)
        if not doc.tables or table_index >= len(doc.tables):
            raise DocError(f"Không tìm thấy bảng chỉ số {table_index} (tổng số bảng: {len(doc.tables)}).")

        tbl = doc.tables[table_index]
        headers, matrix = extract_table_matrix(tbl, propagate_merged_values=propagate_merged_values)

        result_payload = {
            "path": path,
            "table_index": table_index,
            "rows_count": len(tbl.rows),
            "columns_count": len(tbl.columns),
            "headers": headers,
        }
        if as_records and len(matrix) > 1:
            records = []
            for row in matrix[1:]:
                rec = {}
                for h, val in zip(headers, row):
                    rec[h] = val
                records.append(rec)
            result_payload["records"] = records
        else:
            result_payload["matrix"] = matrix

        return _ok(**result_payload)
    finally:
        if temp_clean and os.path.exists(temp_clean):
            try:
                os.remove(temp_clean)
            except OSError:
                pass


@mcp.tool()
def insert_docx_table(
    output: str,
    headers: list[str],
    data: list[list[Any]],
    path: str | None = None,
    title: str | None = None,
    style: str = "Table Grid",
    col_widths: list[float] | None = None,
    header_bg: str = "#1F497D",
    header_color: str = "#FFFFFF",
    preset: str | None = None,
    zebra_striping: bool = False,
    alignment: str = "center",
    overwrite: bool = False,
) -> dict[str, Any]:
    """Tạo mới hoặc chèn thêm một bảng có định dạng chuyên nghiệp vào tài liệu Word (.docx, .doc).

    Hỗ trợ preset màu văn phòng chuẩn:
    - 'corporate_blue': Xanh dương doanh nghiệp đậm
    - 'classic_navy': Xanh navy cổ điển
    - 'modern_gray': Xám hiện đại
    - 'emerald_green': Xanh ngọc lục bảo
    - 'crimson_red': Đỏ đô sang trọng

    Định dạng chuẩn 'Không sai một ly':
    - Lặp tiêu đề trang (w:tblHeader) khi bảng kéo dài qua nhiều trang.
    - Chống gãy dòng (w:cantSplit) trên từng hàng.
    - Căn lề bảng, đệm trong ô (padding), độ rộng cột tùy chỉnh theo cm.
    Cần readwrite.
    """
    require_write()
    out = resolve_write_path(output, exts={".docx"})
    if os.path.exists(out) and not overwrite:
        raise DocError(f"Tệp đã tồn tại (overwrite=False): {out}")

    doc, temp_clean = ensure_docx_or_new(path)
    try:
        from docx.enum.table import WD_ALIGN_VERTICAL, WD_TABLE_ALIGNMENT  # noqa: PLC0415
        from docx.enum.text import WD_ALIGN_PARAGRAPH  # noqa: PLC0415
        from docx.oxml import OxmlElement  # noqa: PLC0415
        from docx.shared import Cm, Pt, RGBColor  # noqa: PLC0415

        cfg_bg = header_bg.lstrip("#")
        cfg_col = header_color.lstrip("#")
        cfg_zebra = None
        if preset and preset in TABLE_PRESETS:
            p_data = TABLE_PRESETS[preset]
            cfg_bg = p_data["header_bg"]
            cfg_col = p_data["header_color"]
            cfg_zebra = p_data["zebra_bg"]

        if title:
            p_title = doc.add_paragraph()
            p_title.paragraph_format.space_before = Pt(12)
            p_title.paragraph_format.space_after = Pt(4)
            r_title = p_title.add_run(str(title))
            r_title.bold = True
            r_title.font.size = Pt(13)

        num_cols = len(headers) if headers else (max(len(r) for r in data) if data else 1)
        num_rows = (1 if headers else 0) + len(data)
        tbl = doc.add_table(rows=num_rows, cols=num_cols)
        try:
            tbl.style = style
        except Exception:
            tbl.style = "Table Grid"

        align_map = {
            "center": WD_TABLE_ALIGNMENT.CENTER,
            "left": WD_TABLE_ALIGNMENT.LEFT,
            "right": WD_TABLE_ALIGNMENT.RIGHT,
        }
        tbl.alignment = align_map.get(alignment.lower(), WD_TABLE_ALIGNMENT.CENTER)

        row_offset = 0
        if headers:
            hdr_row = tbl.rows[0]
            trPr = hdr_row._tr.get_or_add_trPr()
            trPr.append(OxmlElement("w:tblHeader"))
            trPr.append(OxmlElement("w:cantSplit"))

            for c_idx, h_text in enumerate(headers):
                if c_idx < len(hdr_row.cells):
                    cell = hdr_row.cells[c_idx]
                    set_cell_background(cell, cfg_bg)
                    set_cell_margins(cell, top=140, bottom=140, left=180, right=180)
                    cell.vertical_alignment = WD_ALIGN_VERTICAL.CENTER
                    p = cell.paragraphs[0]
                    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
                    r = p.add_run(str(h_text))
                    r.bold = True
                    r.font.size = Pt(10.5)
                    try:
                        r.font.color.rgb = RGBColor.from_string(cfg_col)
                    except Exception:
                        pass
            row_offset = 1

        for r_idx, row_values in enumerate(data):
            curr_row = tbl.rows[row_offset + r_idx]
            trPr = curr_row._tr.get_or_add_trPr()
            trPr.append(OxmlElement("w:cantSplit"))

            is_zebra = zebra_striping and (r_idx % 2 == 1) and cfg_zebra
            for c_idx, val in enumerate(row_values):
                if c_idx < len(curr_row.cells):
                    cell = curr_row.cells[c_idx]
                    if is_zebra:
                        set_cell_background(cell, cfg_zebra)
                    set_cell_margins(cell, top=100, bottom=100, left=150, right=150)
                    cell.vertical_alignment = WD_ALIGN_VERTICAL.CENTER
                    p = cell.paragraphs[0]
                    p.add_run(str(val) if val is not None else "")

        if col_widths:
            for c_idx, w_cm in enumerate(col_widths):
                if c_idx < len(tbl.columns):
                    for cell in tbl.columns[c_idx].cells:
                        cell.width = Cm(w_cm)

        doc.save(out)
        return _ok(
            source=path,
            output=out,
            table_index=len(doc.tables) - 1,
            rows_count=num_rows,
            columns_count=num_cols,
        )
    finally:
        if temp_clean and os.path.exists(temp_clean):
            try:
                os.remove(temp_clean)
            except OSError:
                pass


@mcp.tool()
def set_docx_cell(
    path: str,
    output: str,
    table_index: int = 0,
    row: int = 0,
    col: int = 0,
    value: Any = None,
    bold: bool | None = None,
    italic: bool | None = None,
    font_size: float | None = None,
    font_color: str | None = None,
    bg_color: str | None = None,
    align: str | None = None,
    overwrite: bool = False,
) -> dict[str, Any]:
    """Cập nhật giá trị và định dạng cho một ô cụ thể trong bảng Word (.docx, .doc).

    table_index: Thứ tự bảng trong tài liệu (0-based).
    row, col: Tọa độ hàng và cột của ô cần sửa (0-based).
    value: Giá trị mới (None để giữ nguyên text hiện tại và chỉ đổi định dạng).
    bold, italic: In đậm / in nghiêng.
    font_size: Cỡ chữ (Pt), ví dụ 11.0.
    font_color: Mã màu chữ hex, ví dụ '#FF0000'.
    bg_color: Mã màu nền ô hex, ví dụ '#FFFF00'.
    align: Căn lề ('left', 'center', 'right', 'justify').
    Cần readwrite.
    """
    require_write()
    working_path, temp_clean = ensure_docx_path(path)
    out = resolve_write_path(output, exts={".docx"})
    if os.path.exists(out) and not overwrite:
        raise DocError(f"Tệp đã tồn tại (overwrite=False): {out}")

    try:
        import docx  # noqa: PLC0415
        from docx.enum.text import WD_ALIGN_PARAGRAPH  # noqa: PLC0415
        from docx.shared import Pt, RGBColor  # noqa: PLC0415

        doc = docx.Document(working_path)
        if not doc.tables or table_index >= len(doc.tables):
            raise DocError(f"Không tìm thấy bảng chỉ số {table_index} (tổng số bảng: {len(doc.tables)}).")
        tbl = doc.tables[table_index]
        if row >= len(tbl.rows) or col >= len(tbl.columns):
            raise DocError(
                f"Tọa độ ({row}, {col}) vượt quá kích thước bảng ({len(tbl.rows)}x{len(tbl.columns)})."
            )

        cell = tbl.cell(row, col)

        if bg_color:
            set_cell_background(cell, bg_color)

        if value is not None:
            for extra_p in list(cell.paragraphs[1:]):
                extra_p._p.getparent().remove(extra_p._p)
            p0 = cell.paragraphs[0]
            for child in list(p0._p):
                if child.tag.endswith("r"):
                    p0._p.remove(child)

            lines = str(value).split("\n")
            for i, line in enumerate(lines):
                p = p0 if i == 0 else cell.add_paragraph()
                r = p.add_run(line)
                if bold is not None:
                    r.bold = bold
                if italic is not None:
                    r.italic = italic
                if font_size is not None:
                    r.font.size = Pt(font_size)
                if font_color:
                    try:
                        r.font.color.rgb = RGBColor.from_string(font_color.lstrip("#"))
                    except Exception:
                        pass
        else:
            for p in cell.paragraphs:
                for r in p.runs:
                    if bold is not None:
                        r.bold = bold
                    if italic is not None:
                        r.italic = italic
                    if font_size is not None:
                        r.font.size = Pt(font_size)
                    if font_color:
                        try:
                            r.font.color.rgb = RGBColor.from_string(font_color.lstrip("#"))
                        except Exception:
                            pass

        if align:
            align_map = {
                "center": WD_ALIGN_PARAGRAPH.CENTER,
                "left": WD_ALIGN_PARAGRAPH.LEFT,
                "right": WD_ALIGN_PARAGRAPH.RIGHT,
                "justify": WD_ALIGN_PARAGRAPH.JUSTIFY,
            }
            p_align = align_map.get(align.lower())
            if p_align is not None:
                for p in cell.paragraphs:
                    p.alignment = p_align

        doc.save(out)
        return _ok(
            source=path,
            output=out,
            table_index=table_index,
            row=row,
            col=col,
            updated_value=value,
        )
    finally:
        if temp_clean and os.path.exists(temp_clean):
            try:
                os.remove(temp_clean)
            except OSError:
                pass


@mcp.tool()
def edit_docx_table_rows(
    path: str,
    output: str,
    table_index: int = 0,
    action: str = "append",
    rows_data: list[list[Any]] | None = None,
    row_index: int | None = None,
    copy_style: bool = True,
    overwrite: bool = False,
) -> dict[str, Any]:
    """Thao tác thêm, chèn hoặc xóa hàng trong bảng Word (.docx, .doc).

    action:
    - 'append': Thêm các hàng mới vào cuối bảng.
    - 'insert': Chèn hàng mới tại vị trí row_index.
    - 'delete': Xóa hàng tại vị trí row_index.
    copy_style: Tự động kế thừa định dạng (màu nền, viền kẻ, padding, font) từ hàng liền kề.
    Cần readwrite.
    """
    require_write()
    working_path, temp_clean = ensure_docx_path(path)
    out = resolve_write_path(output, exts={".docx"})
    if os.path.exists(out) and not overwrite:
        raise DocError(f"Tệp đã tồn tại (overwrite=False): {out}")

    try:
        import copy  # noqa: PLC0415
        import docx  # noqa: PLC0415
        from docx.table import _Row  # noqa: PLC0415

        doc = docx.Document(working_path)
        if not doc.tables or table_index >= len(doc.tables):
            raise DocError(f"Không tìm thấy bảng chỉ số {table_index} (tổng số bảng: {len(doc.tables)}).")
        tbl = doc.tables[table_index]

        if action == "delete":
            if row_index is None or row_index < 0 or row_index >= len(tbl.rows):
                raise DocError(f"row_index={row_index} không hợp lệ (tổng số hàng: {len(tbl.rows)}).")
            tr_to_delete = tbl.rows[row_index]._tr
            tbl._tbl.remove(tr_to_delete)
        elif action in ("append", "insert"):
            if not rows_data:
                raise DocError("rows_data không được để trống khi thêm hoặc chèn hàng.")

            if action == "insert":
                if row_index is None or row_index < 0 or row_index > len(tbl.rows):
                    raise DocError(f"row_index={row_index} không hợp lệ để chèn.")
                target_tr = tbl.rows[row_index]._tr if row_index < len(tbl.rows) else tbl.rows[-1]._tr
            else:
                target_tr = tbl.rows[-1]._tr

            last_tr = target_tr
            template_tr = tbl.rows[-1]._tr if len(tbl.rows) > 0 else None

            for row_vals in rows_data:
                if copy_style and template_tr is not None:
                    new_tr = copy.deepcopy(template_tr)
                    if action == "insert" and row_index < len(tbl.rows):
                        target_tr.addprevious(new_tr)
                    else:
                        last_tr.addnext(new_tr)
                        last_tr = new_tr
                    new_row = _Row(new_tr, tbl)
                    for c_idx, cell in enumerate(new_row.cells):
                        val = row_vals[c_idx] if c_idx < len(row_vals) else ""
                        cell.text = str(val) if val is not None else ""
                else:
                    new_row = tbl.add_row()
                    for c_idx, cell in enumerate(new_row.cells):
                        val = row_vals[c_idx] if c_idx < len(row_vals) else ""
                        cell.text = str(val) if val is not None else ""

        doc.save(out)
        return _ok(
            source=path,
            output=out,
            table_index=table_index,
            action=action,
            total_rows_now=len(tbl.rows),
        )
    finally:
        if temp_clean and os.path.exists(temp_clean):
            try:
                os.remove(temp_clean)
            except OSError:
                pass


@mcp.tool()
def convert_doc_to_docx(
    path: str,
    output: str | None = None,
    overwrite: bool = False,
) -> dict[str, Any]:
    """Chuyển đổi file Word legacy .doc (97-2003) sang định dạng .docx hiện đại.

    Yêu cầu Microsoft Word trên máy tính (sử dụng Word COM automation). Cần readwrite.
    """
    require_write()
    out = _convert_doc_to_docx(path, docx_path=output, overwrite=overwrite)
    return _ok(source=path, output=out)


@mcp.tool()
def attach_file_to_docx(
    docx_path: str,
    file_path: str,
    display_name: str | None = None,
    caption: str | None = None,
    create_if_missing: bool = True,
) -> dict[str, Any]:
    """Đính kèm/nhúng một tập tin bất kỳ (zip, pdf, txt, png...) vào tài liệu Word (.docx).

    Tập tin được nhúng dưới dạng OLE Object kèm biểu tượng (icon) trong Word, cho phép
    người xem click đúp chuột trực tiếp vào biểu tượng để mở hoặc trích xuất tệp.
    Yêu cầu DOCS_ACCESS_MODE=readwrite.

    Args:
        docx_path: Đường dẫn tới tài liệu Word đích (.docx).
        file_path: Đường dẫn tới tập tin cần đính kèm/nhúng vào tài liệu Word.
        display_name: Tên hiển thị dưới biểu tượng đính kèm (mặc định là tên file).
        caption: Đoạn văn bản chú thích/mô tả đặt phía trước biểu tượng đính kèm.
        create_if_missing: Nếu True và docx_path chưa tồn tại, tự động tạo mới tài liệu Word.
    """
    require_write()
    res = attach_file_to_docx_helper(
        docx_path=docx_path,
        file_path=file_path,
        display_name=display_name,
        caption=caption,
        create_if_missing=create_if_missing,
    )
    return _ok(**res)


# ========================================================================== #
# Kho template docx (lưu theo tên, gọi lại sau) — cần readwrite
# ========================================================================== #
@mcp.tool()
def save_template(name: str, path: str, note: str = "", overwrite: bool = False) -> dict[str, Any]:
    """Lưu một template .docx vào kho theo `name` (dùng lại sau bằng fill_from_template)."""
    require_write()
    src = resolve_doc_path(path)
    return _ok(**templates.save_template("docs", name, src, {".docx"}, note, overwrite))


@mcp.tool()
def list_templates() -> dict[str, Any]:
    """Liệt kê các template docx đã lưu trong kho."""
    items = templates.list_templates("docs")
    return _ok(count=len(items), templates=items)


@mcp.tool()
def fill_from_template(
    name: str, output: str, context: dict[str, Any], overwrite: bool = False
) -> dict[str, Any]:
    """Điền template docx đã lưu (gọi theo TÊN) bằng docxtpl. Cần readwrite."""
    require_write()
    src = templates.template_path("docs", name)
    res = _render_docx(src, output, context, overwrite)
    res["from_template"] = name
    return res


@mcp.tool()
def delete_template(name: str) -> dict[str, Any]:
    """Xoá một template docx khỏi kho. Cần readwrite."""
    require_write()
    return _ok(**templates.delete_template("docs", name))


# ========================================================================== #
# Đọc ĐẦY ĐỦ định dạng .docx (đoạn + run + bảng)
# ========================================================================== #
def _docx_style(src: str, max_blocks: int) -> dict[str, Any]:
    try:
        import docx  # noqa: PLC0415
        from docx.oxml.ns import qn  # noqa: PLC0415
        from docx.table import Table  # noqa: PLC0415
        from docx.text.paragraph import Paragraph  # noqa: PLC0415
    except ImportError as exc:  # pragma: no cover
        raise DocError("Chưa cài python-docx. Chạy: pip install python-docx") from exc
    doc = docx.Document(src)

    def _pt(v):
        return round(v.pt, 2) if v is not None and hasattr(v, "pt") else None

    def _enum(v):
        return None if v is None else (getattr(v, "name", None) or str(v))

    def _uline(u):
        return u if (u is None or isinstance(u, bool)) else _enum(u)

    def _run_color(r):
        col = r.font.color
        if col is None:
            return None
        try:
            rgb = col.rgb
        except Exception:  # noqa: BLE001
            rgb = None
        if rgb is not None:
            return str(rgb)
        tc = getattr(col, "theme_color", None)
        return _enum(tc) if tc else None

    def _run(r):
        f = r.font
        return {
            "text": r.text, "font": f.name, "size": _pt(f.size),
            "bold": f.bold, "italic": f.italic, "underline": _uline(f.underline),
            "strike": f.strike, "color": _run_color(r), "highlight": _enum(f.highlight_color),
        }

    def _para(p):
        pf = p.paragraph_format
        ls = pf.line_spacing
        return {
            "type": "paragraph",
            "style": p.style.name if p.style else None,
            "alignment": _enum(p.alignment),
            "indent": {"left": _pt(pf.left_indent), "right": _pt(pf.right_indent),
                       "first_line": _pt(pf.first_line_indent)},
            "spacing": {"before": _pt(pf.space_before), "after": _pt(pf.space_after),
                        "line": (_pt(ls) if hasattr(ls, "pt") else ls)},
            "text": p.text,
            "runs": [_run(r) for r in p.runs],
        }

    def _shd(tc):
        pr = tc.tcPr
        shd = pr.find(qn("w:shd")) if pr is not None else None
        if shd is None:
            return None
        fill = shd.get(qn("w:fill"))
        return fill if fill and fill != "auto" else None

    def _borders(tc):
        pr = tc.tcPr
        bd = pr.find(qn("w:tcBorders")) if pr is not None else None
        if bd is None:
            return None
        out = {}
        for edge in ("top", "left", "bottom", "right"):
            e = bd.find(qn("w:" + edge))
            if e is not None:
                out[edge] = {"val": e.get(qn("w:val")), "color": e.get(qn("w:color")),
                             "sz": e.get(qn("w:sz"))}
        return out or None

    def _merge(tc):
        pr = tc.tcPr
        if pr is None:
            return None
        info = {}
        gs = pr.find(qn("w:gridSpan"))
        if gs is not None:
            info["grid_span"] = int(gs.get(qn("w:val")))
        vm = pr.find(qn("w:vMerge"))
        if vm is not None:
            info["v_merge"] = vm.get(qn("w:val")) or "continue"
        return info or None

    def _cell(c):
        return {"text": c.text, "bg_color": _shd(c._tc), "borders": _borders(c._tc),
                "merge": _merge(c._tc), "width": _pt(c.width)}

    def _table(t):
        rows = []
        for row in t.rows:
            seen, cells = set(), []
            for c in row.cells:
                if id(c._tc) in seen:
                    continue
                seen.add(id(c._tc))
                cells.append(_cell(c))
            rows.append(cells)
        return {"type": "table", "rows_count": len(t.rows), "rows": rows}

    blocks, truncated = [], False
    for child in doc.element.body.iterchildren():
        if len(blocks) >= max_blocks:
            truncated = True
            break
        if child.tag == qn("w:p"):
            blocks.append(_para(Paragraph(child, doc)))
        elif child.tag == qn("w:tbl"):
            blocks.append(_table(Table(child, doc)))
    return {"path": src, "count": len(blocks), "truncated": truncated, "blocks": blocks}


@mcp.tool()
def read_docx_style(path: str, max_blocks: int = 300) -> dict[str, Any]:
    """Đọc ĐẦY ĐỦ định dạng .docx / .doc theo thứ tự block (đoạn văn / bảng).

    Đoạn: style, canh lề, thụt lề, giãn dòng + các run (text, font, size, bold/italic/
    underline/strike, màu chữ, highlight). Bảng: text từng ô + **màu nền (shading)**,
    **border**, **merge** (gridSpan/vMerge), độ rộng ô. max_blocks giới hạn số block.
    """
    src = resolve_doc_path(path)
    if ext_of(src) not in (".docx", ".doc"):
        raise DocError(f"Chỉ đọc style cho Word (.docx, .doc): {src}")
    working_src, temp_clean = ensure_docx_path(src)
    try:
        res = _docx_style(working_src, max_blocks)
        res["path"] = src
        return _ok(**res)
    finally:
        if temp_clean and os.path.exists(temp_clean):
            try:
                os.remove(temp_clean)
            except OSError:
                pass


def main() -> None:
    """Điểm khởi động: chạy MCP server qua stdio."""
    mcp.run()


if __name__ == "__main__":
    main()
