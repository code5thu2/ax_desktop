"""MCP server đọc tài liệu (.docx/.pdf/.pptx/.txt/.md) -> text cho AI."""

from .server import main, mcp

__all__ = ["main", "mcp"]
__version__ = "0.1.0"
