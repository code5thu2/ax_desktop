"""Tiện ích dùng chung cho docs_mcp: chuẩn hoá path, giới hạn đọc, guard ghi.

Cấu hình qua biến môi trường:
    DOCS_MAX_CHARS     số ký tự tối đa trả về mỗi lần đọc (mặc định 200000)
    DOCS_ACCESS_MODE   "readonly" (mặc định) hoặc "readwrite" (cho phép ghi)
    DOCS_PDF_FONT      đường dẫn .ttf để tạo PDF unicode (mặc định dò font Windows)
"""

from __future__ import annotations

import os
import zipfile
from typing import Any, Iterator

from common import IMAGE_MIME, VISION_OK_MIME, McpError, make_access, sniff_size

DEFAULT_MAX_CHARS = 200_000

# Định dạng tài liệu hỗ trợ trích text (đọc).
DOC_EXTS = {".doc", ".docx", ".pdf", ".pptx", ".txt", ".md"}
# Định dạng tạo/ghi được từ văn bản (write_document).
WRITE_EXTS = {".doc", ".docx", ".txt", ".md", ".pdf"}
# Định dạng nối thêm được (append_document) — pdf không nối thêm được.
APPEND_EXTS = {".doc", ".docx", ".txt", ".md"}

DocError = McpError  # alias cho dễ đọc
access_mode, is_readonly, require_write = make_access("DOCS_ACCESS_MODE")


def max_chars() -> int:
    try:
        return int(os.environ.get("DOCS_MAX_CHARS", DEFAULT_MAX_CHARS))
    except ValueError:
        return DEFAULT_MAX_CHARS


def resolve_write_path(path: str, exts: set[str] | None = None) -> str:
    """Chuẩn hoá path để GHI: đúng định dạng ghi được, thư mục cha tồn tại.

    Không yêu cầu file đã tồn tại (khác resolve_doc_path dùng cho đọc).
    exts: tập phần mở rộng cho phép; mặc định WRITE_EXTS.
    """
    allowed = exts if exts is not None else WRITE_EXTS
    if not path or not str(path).strip():
        raise DocError("Thiếu đường dẫn.")
    abspath = os.path.realpath(os.path.abspath(os.path.expanduser(path)))
    ext = os.path.splitext(abspath)[1].lower()
    if ext not in allowed:
        raise DocError(
            f"Chỉ ghi được {sorted(allowed)} — không hỗ trợ tạo/ghi '{ext}'."
        )
    parent = os.path.dirname(abspath)
    if parent:
        os.makedirs(parent, exist_ok=True)
    return abspath


def pdf_font(text: str | None = None) -> str | None:
    """Đường dẫn .ttf để tạo PDF unicode: ưu tiên DOCS_PDF_FONT, rồi font Windows.

    Tự động phát hiện ký tự tiếng Hàn (Hangul) để ưu tiên font Malgun Gothic (malgun.ttf),
    tránh lỗi missing glyphs trong arial.ttf.
    """
    win = os.environ.get("WINDIR", r"C:\Windows")
    has_korean = False
    if text:
        import re
        has_korean = bool(re.search(r"[\uac00-\ud7a3\u1100-\u11ff\u3130-\u318f]", text))

    if has_korean:
        candidates = (
            os.environ.get("DOCS_PDF_FONT", ""),
            os.path.join(win, "Fonts", "malgun.ttf"),   # Malgun Gothic (Hàn Quốc)
            os.path.join(win, "Fonts", "malgunbd.ttf"),
            os.path.join(win, "Fonts", "arial.ttf"),
            os.path.join(win, "Fonts", "segoeui.ttf"),
        )
    else:
        candidates = (
            os.environ.get("DOCS_PDF_FONT", ""),
            os.path.join(win, "Fonts", "arial.ttf"),    # Latin + Việt
            os.path.join(win, "Fonts", "malgun.ttf"),   # Hàn
            os.path.join(win, "Fonts", "segoeui.ttf"),
        )
    for cand in candidates:
        if cand and os.path.isfile(cand):
            return cand
    return None


def resolve_doc_path(path: str) -> str:
    """Chuẩn hoá path tuyệt đối, kiểm tra tồn tại & đúng định dạng tài liệu."""
    if not path or not str(path).strip():
        raise DocError("Thiếu đường dẫn.")
    abspath = os.path.realpath(os.path.abspath(os.path.expanduser(path)))
    if not os.path.isfile(abspath):
        raise DocError(f"Không tìm thấy tệp: {abspath}")
    ext = os.path.splitext(abspath)[1].lower()
    if ext not in DOC_EXTS:
        raise DocError(
            f"Định dạng không hỗ trợ: '{ext}'. Chấp nhận: {sorted(DOC_EXTS)}"
        )
    return abspath


def ext_of(path: str) -> str:
    return os.path.splitext(path)[1].lower()


# --------------------------------------------------------------------------- #
# Ảnh nhúng trong tài liệu (docx/pptx: đọc từ zip; pdf: qua pypdf)
# IMAGE_MIME / VISION_OK_MIME / sniff_size lấy từ common.
# --------------------------------------------------------------------------- #
def iter_document_images(path: str) -> Iterator[dict[str, Any]]:
    """Duyệt ảnh nhúng trong tài liệu.

    docx/pptx: đọc thẳng thư mục media trong zip (không cần Pillow).
    pdf: dùng pypdf (page.images). txt/md: không có ảnh.
    Mỗi phần tử: {location, filename, mime, bytes, width, height, data}.
    """
    ext = ext_of(path)
    if ext in (".docx", ".pptx"):
        media_dir = "word/media/" if ext == ".docx" else "ppt/media/"
        with zipfile.ZipFile(path) as z:
            for name in sorted(n for n in z.namelist() if n.startswith(media_dir)):
                e = os.path.splitext(name)[1].lower()
                if e not in IMAGE_MIME:
                    continue  # bỏ audio/video/... trong media
                data = z.read(name)
                w, h = sniff_size(data)
                yield {
                    "location": None,
                    "filename": os.path.basename(name),
                    "mime": IMAGE_MIME[e],
                    "bytes": len(data),
                    "width": w,
                    "height": h,
                    "data": data,
                }
    elif ext == ".pdf":
        try:
            from pypdf import PdfReader  # noqa: PLC0415
        except ImportError as exc:  # pragma: no cover
            raise DocError("Chưa cài pypdf. Chạy: pip install pypdf") from exc
        reader = PdfReader(path)
        for pi, page in enumerate(reader.pages, 1):
            try:
                images = list(page.images)
            except Exception:  # noqa: BLE001
                images = []
            for im in images:
                data = im.data
                fname = im.name or f"page{pi}.png"
                e = os.path.splitext(fname)[1].lower()
                w, h = sniff_size(data)
                yield {
                    "location": f"trang {pi}",
                    "filename": fname,
                    "mime": IMAGE_MIME.get(e, "image/png"),
                    "bytes": len(data),
                    "width": w,
                    "height": h,
                    "data": data,
                }


# --------------------------------------------------------------------------- #
# Hỗ trợ Word Template nâng cao (.doc, .docx) — Không sai một ly
# --------------------------------------------------------------------------- #
def replace_runs_text(p, target: str, replacement: str) -> int:
    """Thay thế chuỗi `target` bằng `replacement` trong đoạn văn `p`.

    Giải quyết triệt để lỗi phân mảnh Run (Split-Run) của Word OpenXML:
    Nếu target bị chia cắt qua nhiều run (ví dụ: '[Họ', ' và ', 'tên]'),
    thuật toán xác định chính xác các run liên quan, giữ nguyên style (font,
    size, bold, italic, color) của run gốc đầu tiên, chèn <w:br/> khi có dấu '\\n',
    và xoá text của các run trung gian.

    Hỗ trợ Unicode NFC: Chuẩn hoá NFD (thường sinh ra từ macOS / gõ Hangul)
    về dạng NFC chuẩn Windows/Word trước khi tìm kiếm và thay thế.
    """
    if not target:
        return 0
    import unicodedata

    target = unicodedata.normalize("NFC", str(target))
    for r in p.runs:
        if r.text:
            r.text = unicodedata.normalize("NFC", r.text)

    count = 0
    while target in p.text:
        runs = p.runs
        if not runs:
            break
        offsets = []
        curr = 0
        for r in runs:
            offsets.append((curr, curr + len(r.text)))
            curr += len(r.text)

        pos = p.text.find(target)
        if pos == -1:
            break
        end_pos = pos + len(target)

        start_run = -1
        end_run = -1
        for i, (s, e) in enumerate(offsets):
            if s <= pos < e:
                start_run = i
            if s < end_pos <= e:
                end_run = i
                break

        if start_run == -1 or end_run == -1:
            break

        s_off, _ = offsets[start_run]
        e_off, _ = offsets[end_run]
        prefix = runs[start_run].text[: (pos - s_off)]
        suffix = runs[end_run].text[(end_pos - e_off) :]

        from docx.oxml import OxmlElement
        from docx.oxml.ns import qn

        # Xoá các text node hiện tại của start_run nhưng giữ nguyên run formatting (rPr)
        for child in list(runs[start_run]._r):
            if child.tag.endswith("t") or child.tag.endswith("br"):
                runs[start_run]._r.remove(child)

        full_text = prefix + str(replacement) + (suffix if start_run == end_run else "")
        lines = full_text.split("\n")
        t0 = OxmlElement("w:t")
        t0.text = lines[0]
        t0.set(qn("xml:space"), "preserve")
        runs[start_run]._r.append(t0)

        for line in lines[1:]:
            runs[start_run]._r.append(OxmlElement("w:br"))
            t = OxmlElement("w:t")
            t.text = line
            t.set(qn("xml:space"), "preserve")
            runs[start_run]._r.append(t)

        if start_run < end_run:
            for mid in range(start_run + 1, end_run):
                runs[mid].text = ""
            runs[end_run].text = suffix

        count += 1
    return count


def extract_docx_placeholders(doc) -> dict[str, Any]:
    """Quét toàn bộ đoạn văn, bảng biểu, header/footer của tài liệu docx
    để trích xuất các biến template: Jinja {{ var }}, {% for ... %},
    và các placeholder dạng ngoặc vuông [Tên], <Tên>, {Tên}.
    Hỗ trợ biến Unicode đa ngôn ngữ (tiếng Việt, tiếng Hàn).
    """
    import re

    jinja_vars: set[str] = set()
    bracket_vars: set[str] = set()

    re_jinja_var = re.compile(r"\{\{\s*([\w\.]+)\s*\}\}", re.UNICODE)
    re_jinja_tag = re.compile(r"\{%\s*(?:for|if)\s+([\w]+)", re.UNICODE)
    re_square = re.compile(r"\[[^\]\r\n]+\]")
    re_angle = re.compile(r"<[^>\r\n]+>")
    re_curly = re.compile(r"\{[^{}\r\n]+\}")

    def _scan_text(text: str):
        if not text:
            return
        for m in re_jinja_var.finditer(text):
            jinja_vars.add(m.group(1))
        for m in re_jinja_tag.finditer(text):
            jinja_vars.add(m.group(1))

        # Loại bỏ các tag Jinja trước khi quét ngoặc để tránh bắt nhầm bên trong {{ ... }}
        clean = re_jinja_var.sub(" ", text)
        clean = re_jinja_tag.sub(" ", clean)

        for s in re_square.findall(clean):
            tok = s.strip()
            if tok:
                bracket_vars.add(tok)
        for a in re_angle.findall(clean):
            tok = a.strip()
            if tok:
                bracket_vars.add(tok)
        for c in re_curly.findall(clean):
            tok = c.strip()
            if tok:
                bracket_vars.add(tok)

    # 1. Paragraphs body
    for p in doc.paragraphs:
        _scan_text(p.text)

    # 2. Tables
    for tbl in doc.tables:
        for row in tbl.rows:
            for cell in row.cells:
                for p in cell.paragraphs:
                    _scan_text(p.text)

    # 3. Sections (Header / Footer)
    has_hf = False
    for section in doc.sections:
        for p in section.header.paragraphs:
            has_hf = True
            _scan_text(p.text)
        for p in section.footer.paragraphs:
            has_hf = True
            _scan_text(p.text)

    return {
        "jinja_variables": sorted(jinja_vars),
        "bracket_placeholders": sorted(bracket_vars),
        "total_placeholders": len(jinja_vars) + len(bracket_vars),
        "tables_count": len(doc.tables),
        "paragraphs_count": len(doc.paragraphs),
        "has_headers_footers": has_hf,
    }


def prepare_docx_context(doc: Any, context: dict[str, Any]) -> tuple[dict[str, Any], dict[str, str]]:
    """Phân tách context cho DocxTemplate:
    - jinja_context: các biến tên hợp lệ cho Jinja, tự động bọc InlineImage khi phát hiện ảnh
      (hỗ trợ từ khoá con dấu/chữ ký tiếng Việt, Anh, Hàn)
    - bracket_replacements: các biến dạng ngoặc [Tên], <Tên>, {Tên} để thay thế sau khi render
    """
    import re
    from docx.shared import Mm

    jinja_ctx: dict[str, Any] = {}
    bracket_rep: dict[str, str] = {}

    def is_valid_ident(s: str) -> bool:
        if not s:
            return False
        return s.isidentifier() or all(part.isidentifier() for part in s.split("."))

    img_keywords = (
        "image", "img", "logo", "signature", "chu_ky", "con_dau", "anh",
        "서명", "사인", "직인", "도장", "인감", "로고", "이미지", "사진",
    )

    for k, v in context.items():
        key_str = str(k).strip()
        # Kiểm tra nếu là ảnh
        if isinstance(v, dict) and ("image_path" in v or "image" in v):
            try:
                from docxtpl import InlineImage
                img_path = v.get("image_path") or v.get("image")
                w_mm = v.get("width_mm")
                h_mm = v.get("height_mm")
                width = Mm(w_mm) if w_mm else None
                height = Mm(h_mm) if h_mm else None
                v = InlineImage(doc, img_path, width=width, height=height)
            except Exception:
                pass
        elif isinstance(v, str) and os.path.isfile(v):
            ext = os.path.splitext(v)[1].lower()
            if ext in (".png", ".jpg", ".jpeg", ".bmp", ".gif"):
                lower_k = key_str.lower()
                if any(w in lower_k for w in img_keywords):
                    try:
                        from docxtpl import InlineImage
                        v = InlineImage(doc, v, width=Mm(40))
                    except Exception:
                        pass

        if is_valid_ident(key_str):
            jinja_ctx[key_str] = v
        else:
            bracket_rep[key_str] = str(v)
            stripped_key = re.sub(r"^[\[\<\{]+|[\]\>\}]+$", "", key_str).strip()
            if is_valid_ident(stripped_key):
                jinja_ctx[stripped_key] = v

    return jinja_ctx, bracket_rep


def convert_doc_to_docx(doc_path: str, docx_path: str | None = None, overwrite: bool = False) -> str:
    """Chuyển đổi tài liệu Word legacy .doc (97-2003) sang .docx bằng Microsoft Word COM automation."""
    src = resolve_doc_path(doc_path)
    if ext_of(src) == ".docx":
        return src
    if ext_of(src) != ".doc":
        raise DocError(f"Chỉ hỗ trợ chuyển đổi .doc sang .docx: {src}")

    out = docx_path or (os.path.splitext(src)[0] + ".docx")
    out = resolve_write_path(out, exts={".docx"})
    if os.path.exists(out) and not overwrite:
        raise DocError(f"Tệp đã tồn tại (overwrite=False): {out}")

    try:
        import win32com.client
        import pythoncom
    except ImportError as exc:
        raise DocError("Cần thư viện pywin32 để chuyển đổi .doc sang .docx.") from exc

    pythoncom.CoInitialize()
    try:
        word = win32com.client.Dispatch("Word.Application")
        word.Visible = False
        try:
            doc = word.Documents.Open(os.path.abspath(src))
            doc.SaveAs2(os.path.abspath(out), FileFormat=16)  # 16 = wdFormatXMLDocument
            doc.Close()
        finally:
            word.Quit()
    except Exception as exc:
        raise DocError(f"Không thể chuyển đổi '{src}' sang .docx: {exc}") from exc
    finally:
        pythoncom.CoUninitialize()

    return out


def ensure_docx_path(path: str) -> tuple[str, str | None]:
    """Kiểm tra đường dẫn tài liệu. Nếu là .doc, tự động chuyển đổi sang .docx tạm.

    Trả về: (working_docx_path, temp_file_to_clean_or_None)
    """
    src = resolve_doc_path(path)
    ext = ext_of(src)
    if ext == ".docx":
        return src, None
    if ext == ".doc":
        import tempfile
        fd, temp_docx = tempfile.mkstemp(suffix=".docx")
        os.close(fd)
        convert_doc_to_docx(src, temp_docx, overwrite=True)
        return temp_docx, temp_docx
    raise DocError(f"Chỉ hỗ trợ tài liệu Word (.doc, .docx): {src}")


# --------------------------------------------------------------------------- #
# Hỗ trợ Xử Lý Bảng Biểu Word Nâng Cao (.doc, .docx) — Không sai một ly
# --------------------------------------------------------------------------- #
TABLE_PRESETS = {
    "corporate_blue": {
        "header_bg": "1F497D",
        "header_color": "FFFFFF",
        "zebra_bg": "F2F5F9",
        "border_color": "D9D9D9",
    },
    "classic_navy": {
        "header_bg": "002060",
        "header_color": "FFFFFF",
        "zebra_bg": "EDF2F8",
        "border_color": "BFBFBF",
    },
    "modern_gray": {
        "header_bg": "595959",
        "header_color": "FFFFFF",
        "zebra_bg": "F2F2F2",
        "border_color": "D9D9D9",
    },
    "emerald_green": {
        "header_bg": "1E4D2B",
        "header_color": "FFFFFF",
        "zebra_bg": "F0F7F2",
        "border_color": "D0E1D4",
    },
    "crimson_red": {
        "header_bg": "78281F",
        "header_color": "FFFFFF",
        "zebra_bg": "FDF2E9",
        "border_color": "E5B4B4",
    },
}


def set_cell_background(cell, hex_color: str) -> None:
    """Đặt màu nền (shading) cho ô bảng Word."""
    from docx.oxml import OxmlElement
    from docx.oxml.ns import qn

    tcPr = cell._tc.get_or_add_tcPr()
    for child in list(tcPr):
        if child.tag.endswith("shd"):
            tcPr.remove(child)
    shd = OxmlElement("w:shd")
    shd.set(qn("w:val"), "clear")
    shd.set(qn("w:color"), "auto")
    shd.set(qn("w:fill"), hex_color.lstrip("#"))
    tcPr.append(shd)


def set_cell_margins(
    cell,
    top: int = 120,
    bottom: int = 120,
    left: int = 150,
    right: int = 150,
) -> None:
    """Đặt lề trong (padding) cho ô bảng Word tính theo dxa (20 dxa = 1 pt)."""
    from docx.oxml import OxmlElement
    from docx.oxml.ns import qn

    tcPr = cell._tc.get_or_add_tcPr()
    for child in list(tcPr):
        if child.tag.endswith("tcMar"):
            tcPr.remove(child)
    tcMar = OxmlElement("w:tcMar")
    for m_name, val in [("top", top), ("bottom", bottom), ("left", left), ("right", right)]:
        node = OxmlElement(f"w:{m_name}")
        node.set(qn("w:w"), str(val))
        node.set(qn("w:type"), "dxa")
        tcMar.append(node)
    tcPr.append(tcMar)


def set_cell_borders(
    cell,
    color: str = "D9D9D9",
    sz: str = "4",
    val: str = "single",
) -> None:
    """Kẻ viền cho ô bảng Word."""
    from docx.oxml import OxmlElement
    from docx.oxml.ns import qn

    tcPr = cell._tc.get_or_add_tcPr()
    for child in list(tcPr):
        if child.tag.endswith("tcBorders"):
            tcPr.remove(child)
    tcBorders = OxmlElement("w:tcBorders")
    hex_col = color.lstrip("#")
    for edge in ("top", "left", "bottom", "right"):
        b_el = OxmlElement(f"w:{edge}")
        b_el.set(qn("w:val"), val)
        b_el.set(qn("w:sz"), sz)
        b_el.set(qn("w:space"), "0")
        b_el.set(qn("w:color"), hex_col)
        tcBorders.append(b_el)
    tcPr.append(tcBorders)


def extract_table_matrix(tbl, propagate_merged_values: bool = False) -> tuple[list[str], list[list[Any]]]:
    """Trích xuất dữ liệu ma trận từ bảng Word, giải quyết triệt để lỗi lặp text do Ô Gộp (Merged Cells).

    Returns:
        (headers, matrix)
    """
    seen_elements: set[Any] = set()
    matrix: list[list[Any]] = []

    for r_idx, row in enumerate(tbl.rows):
        row_vals: list[Any] = []
        for cell in row.cells:
            if cell._tc not in seen_elements:
                seen_elements.add(cell._tc)
                row_vals.append(cell.text.strip())
            else:
                # Ô gộp tiếp nối: trả về text nếu propagate_merged_values=True, ngược lại trả về None
                row_vals.append(cell.text.strip() if propagate_merged_values else None)
        matrix.append(row_vals)

    headers = [str(val or f"Col_{i+1}") for i, val in enumerate(matrix[0])] if matrix else []
    return headers, matrix


def ensure_docx_or_new(path: str | None) -> tuple[Any, str | None]:
    """Mở docx hiện có (nếu là .doc -> chuyển đổi tạm), hoặc tạo docx mới nếu path không tồn tại hoặc None."""
    import docx

    if not path or not str(path).strip():
        return docx.Document(), None
    abspath = os.path.realpath(os.path.abspath(os.path.expanduser(path)))
    if not os.path.exists(abspath):
        return docx.Document(), None
    working_path, temp_clean = ensure_docx_path(abspath)
    return docx.Document(working_path), temp_clean


def attach_file_to_docx_helper(
    docx_path: str,
    file_path: str,
    display_name: str | None = None,
    caption: str | None = None,
    create_if_missing: bool = True,
) -> dict[str, Any]:
    """Đính kèm/nhúng một tập tin bất kỳ (zip, pdf, txt, png...) vào tài liệu Word (.docx)."""
    import logging
    import docx

    logger = logging.getLogger("docs_mcp.attach_file")

    abs_file = os.path.realpath(os.path.abspath(os.path.expanduser(file_path)))
    if not os.path.isfile(abs_file):
        raise DocError(f"Tập tin cần đính kèm không tồn tại: {file_path}")

    file_name = os.path.basename(abs_file)
    disp_name = display_name or file_name
    file_size = os.path.getsize(abs_file)

    abs_docx = os.path.realpath(os.path.abspath(os.path.expanduser(docx_path)))
    if ext_of(abs_docx) != ".docx":
        raise DocError(f"Tài liệu đích phải có phần mở rộng .docx: {docx_path}")

    parent_dir = os.path.dirname(abs_docx)
    if parent_dir and not os.path.exists(parent_dir):
        os.makedirs(parent_dir, exist_ok=True)

    if not os.path.exists(abs_docx):
        if not create_if_missing:
            raise DocError(f"Tài liệu docx chưa tồn tại (create_if_missing=False): {docx_path}")
        d = docx.Document()
        d.save(abs_docx)

    # Thử phương pháp Word COM (chuẩn native OLE Package trên Windows)
    com_success = False
    try:
        import pythoncom
        import win32com.client

        pythoncom.CoInitialize()
        try:
            word = win32com.client.Dispatch("Word.Application")
            word.Visible = False
            try:
                wdoc = word.Documents.Open(abs_docx)
                rng = wdoc.Content
                rng.Collapse(0)  # 0 = wdCollapseEnd

                if caption:
                    rng.InsertParagraphAfter()
                    rng.Collapse(0)
                    p_cap = wdoc.Paragraphs.Last.Range
                    p_cap.Text = caption
                    p_cap.Font.Bold = True
                    p_cap.InsertParagraphAfter()
                    rng = wdoc.Content
                    rng.Collapse(0)

                wdoc.InlineShapes.AddOLEObject(
                    ClassType="Package",
                    FileName=abs_file,
                    LinkToFile=False,
                    DisplayAsIcon=True,
                    IconLabel=disp_name,
                    Range=rng,
                )

                wdoc.Save()
                wdoc.Close()
                com_success = True
            finally:
                word.Quit()
        finally:
            pythoncom.CoUninitialize()
    except Exception as exc:
        logger.warning(f"Word COM không khả dụng ({exc}), chuyển sang fallback python-docx.")
        com_success = False

    # Fallback: nếu không có Word COM, chèn paragraph thông tin đính kèm
    if not com_success:
        doc = docx.Document(abs_docx)
        if caption:
            p_cap = doc.add_paragraph()
            r_cap = p_cap.add_run(caption)
            r_cap.bold = True

        p_info = doc.add_paragraph()
        p_info.add_run(f"📎 [Tệp đính kèm]: {disp_name} ({file_size:,} bytes)\nĐường dẫn: {abs_file}")
        doc.save(abs_docx)

    return {
        "ok": True,
        "docx_path": abs_docx,
        "attached_file": abs_file,
        "file_name": file_name,
        "display_name": disp_name,
        "file_size": file_size,
        "method": "word_com" if com_success else "docx_fallback",
        "message": f"Đã đính kèm thành công tệp '{file_name}' vào tài liệu '{os.path.basename(abs_docx)}'.",
    }


