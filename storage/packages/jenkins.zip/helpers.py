"""Jenkins REST API client, URL helpers, and Multi-Instance Configuration Manager.

Compatible with Python 3.10+ (tested on Python 3.14).
Zero external dependencies: uses standard library urllib, json, os, and pathlib.
"""

from __future__ import annotations

import base64
import json
import os
from pathlib import Path
import re
from typing import Any
import urllib.error
import urllib.parse
import urllib.request


def normalize_job_url(base_url: str, job_name: str) -> str:
    """Normalize a Jenkins job path into the standard /job/... URL format.

    Supports:
      - Simple jobs: "my-job" -> "{base_url}/job/my-job"
      - Nested folders / multibranch: "folder/repo/main" -> "{base_url}/job/folder/job/repo/job/main"
      - Pre-formatted jobs: "job/my-job" -> "{base_url}/job/my-job"
    """
    clean_base = base_url.rstrip("/")
    clean_job = job_name.strip().strip("/")

    # If the user already provided path segments with 'job/', normalize slashes
    parts = [p for p in clean_job.split("/") if p]
    if parts and parts[0] == "job":
        return f"{clean_base}/{'/'.join(parts)}"

    # Convert 'folder/sub/job' -> 'job/folder/job/sub/job/job'
    path_segments = []
    for part in parts:
        path_segments.extend(["job", part])

    return f"{clean_base}/{'/'.join(path_segments)}"


class JenkinsClient:
    """Lightweight, resilient Jenkins REST API client."""

    def __init__(
        self,
        base_url: str,
        user: str = "",
        token: str = "",
        timeout: float = 15.0,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self.user = user.strip()
        self.token = token.strip()
        self.timeout = timeout
        self._crumb_cache: dict[str, str] | None = None

    def _get_auth_header(self) -> dict[str, str]:
        if not self.user or not self.token:
            return {}
        credentials = f"{self.user}:{self.token}".encode("utf-8")
        encoded = base64.b64encode(credentials).decode("ascii")
        return {"Authorization": f"Basic {encoded}"}

    def _get_crumb(self) -> dict[str, str]:
        """Fetch CSRF Crumb if required by Jenkins."""
        if self._crumb_cache is not None:
            return self._crumb_cache

        crumb_url = f"{self.base_url}/crumbIssuer/api/json"
        headers = self._get_auth_header()
        req = urllib.request.Request(crumb_url, headers=headers, method="GET")

        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                if resp.status == 200:
                    payload = json.loads(resp.read().decode("utf-8"))
                    field = payload.get("crumbRequestField", "Jenkins-Crumb")
                    value = payload.get("crumb", "")
                    self._crumb_cache = {field: value}
                    return self._crumb_cache
        except Exception:
            pass

        self._crumb_cache = {}
        return self._crumb_cache

    def request(
        self,
        method: str,
        url: str,
        params: dict[str, Any] | None = None,
        data: bytes | None = None,
        extra_headers: dict[str, str] | None = None,
    ) -> tuple[int, dict[str, str], bytes]:
        """Execute HTTP request with authentication and crumb handling."""
        headers = {
            "User-Agent": "Jenkins-MCP-Server/1.0",
            **self._get_auth_header(),
        }

        if method.upper() == "POST":
            crumb = self._get_crumb()
            headers.update(crumb)

        if extra_headers:
            headers.update(extra_headers)

        full_url = url
        if params:
            query = urllib.parse.urlencode(params)
            sep = "&" if "?" in full_url else "?"
            full_url = f"{full_url}{sep}{query}"

        req = urllib.request.Request(full_url, data=data, headers=headers, method=method.upper())

        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as response:
                status = response.status
                resp_headers = dict(response.headers)
                body = response.read()
                return status, resp_headers, body
        except urllib.error.HTTPError as err:
            err_headers = dict(err.headers) if err.headers else {}
            body = err.read() if err.fp else b""
            return err.code, err_headers, body
        except (urllib.error.URLError, TimeoutError, OSError) as err:
            reason = getattr(err, "reason", str(err))
            error_msg = f"Network error: {reason}".encode("utf-8")
            return 0, {}, error_msg

    def get_server_info(self) -> dict[str, Any]:
        """Fetch server info and detected Jenkins version."""
        url = f"{self.base_url}/api/json"
        status, headers, body = self.request("GET", url)
        if status != 200:
            err_detail = body.decode("utf-8", errors="replace") if body else f"HTTP {status}"
            return {
                "ok": False,
                "error": f"Failed to connect to Jenkins at {self.base_url} ({err_detail})",
                "body": err_detail,
            }

        version = headers.get("X-Jenkins", "Unknown")
        data = json.loads(body.decode("utf-8", errors="replace"))
        return {
            "ok": True,
            "jenkins_version": version,
            "mode": data.get("mode", "NORMAL"),
            "server_url": self.base_url,
            "node_name": data.get("nodeName", "controller"),
        }

    def trigger_job(
        self,
        job_name: str,
        params: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Trigger a build for a job. Returns the queue item ID and location."""
        job_url = normalize_job_url(self.base_url, job_name)
        if params:
            endpoint = f"{job_url}/buildWithParameters"
            form_data = urllib.parse.urlencode(params).encode("utf-8")
            extra_headers = {"Content-Type": "application/x-www-form-urlencoded"}
        else:
            endpoint = f"{job_url}/build"
            form_data = None
            extra_headers = {}

        status, headers, body = self.request("POST", endpoint, data=form_data, extra_headers=extra_headers)

        if status in (200, 201):
            location = headers.get("Location", "")
            queue_item_id = None
            match = re.search(r"/queue/item/(\d+)/?", location)
            if match:
                queue_item_id = int(match.group(1))

            return {
                "ok": True,
                "job_name": job_name,
                "status": "TRIGGERED",
                "queue_location": location,
                "queue_item_id": queue_item_id,
            }

        return {
            "ok": False,
            "error": f"Failed to trigger job '{job_name}' (HTTP {status})",
            "body": body.decode("utf-8", errors="replace"),
        }

    def get_build_status(
        self,
        job_name: str,
        build_number: int | None = None,
    ) -> dict[str, Any]:
        """Fetch the status of a specific build or the last build."""
        job_url = normalize_job_url(self.base_url, job_name)
        build_id = str(build_number) if build_number is not None else "lastBuild"
        endpoint = f"{job_url}/{build_id}/api/json"

        params = {
            "tree": "number,building,result,duration,timestamp,estimatedDuration,url",
        }
        status, _, body = self.request("GET", endpoint, params=params)

        if status == 404:
            return {
                "ok": False,
                "error": f"Build '{build_id}' for job '{job_name}' not found.",
            }
        if status != 200:
            return {
                "ok": False,
                "error": f"Failed to get build status for '{job_name}' (HTTP {status})",
                "body": body.decode("utf-8", errors="replace"),
            }

        data = json.loads(body.decode("utf-8", errors="replace"))
        return {
            "ok": True,
            "job_name": job_name,
            "build_number": data.get("number"),
            "building": data.get("building", False),
            "result": data.get("result"),
            "duration": data.get("duration", 0),
            "timestamp": data.get("timestamp", 0),
            "url": data.get("url"),
        }

    def get_pipeline_stages(
        self,
        job_name: str,
        build_number: int | None = None,
    ) -> list[dict[str, Any]]:
        """Fetch stage execution breakdown via /wfapi/describe for Pipeline jobs."""
        job_url = normalize_job_url(self.base_url, job_name)
        build_id = str(build_number) if build_number is not None else "lastBuild"
        endpoint = f"{job_url}/{build_id}/wfapi/describe"

        status, _, body = self.request("GET", endpoint)
        if status != 200:
            return []

        try:
            data = json.loads(body.decode("utf-8", errors="replace"))
            stages = data.get("stages", [])
            return [
                {
                    "id": stage.get("id"),
                    "name": stage.get("name"),
                    "status": stage.get("status"),
                    "durationMillis": stage.get("durationMillis"),
                    "error": stage.get("error"),
                }
                for stage in stages
            ]
        except Exception:
            return []

    def get_console_output(
        self,
        job_name: str,
        build_number: int | None = None,
        tail_lines: int = 200,
    ) -> str:
        """Fetch console output text."""
        job_url = normalize_job_url(self.base_url, job_name)
        build_id = str(build_number) if build_number is not None else "lastBuild"
        endpoint = f"{job_url}/{build_id}/consoleText"

        status, _, body = self.request("GET", endpoint)
        if status != 200:
            return f"[Error fetching console log: HTTP {status}]\n{body.decode('utf-8', errors='replace')}"

        text = body.decode("utf-8", errors="replace")
        if tail_lines <= 0:
            return text

        lines = text.splitlines()
        if len(lines) <= tail_lines:
            return text

        return "\n".join(lines[-tail_lines:])

    def get_pipeline_graph(
        self,
        job_name: str,
        build_number: int | None = None,
    ) -> dict[str, Any]:
        """Inspect Upstream causes and Downstream projects."""
        job_url = normalize_job_url(self.base_url, job_name)
        build_id = str(build_number) if build_number is not None else "lastBuild"

        build_endpoint = f"{job_url}/{build_id}/api/json"
        build_params = {"tree": "number,actions[causes[*]]"}
        status_b, _, body_b = self.request("GET", build_endpoint, params=build_params)

        upstream_causes = []
        actual_build_number = build_number
        if status_b == 200:
            b_data = json.loads(body_b.decode("utf-8", errors="replace"))
            actual_build_number = b_data.get("number", build_number)
            actions = b_data.get("actions", [])
            for action in actions:
                if action and "causes" in action:
                    for cause in action["causes"]:
                        if "upstreamProject" in cause:
                            upstream_causes.append(
                                {
                                    "upstreamProject": cause.get("upstreamProject"),
                                    "upstreamBuild": cause.get("upstreamBuild"),
                                    "upstreamUrl": cause.get("upstreamUrl"),
                                    "shortDescription": cause.get("shortDescription"),
                                }
                            )

        job_endpoint = f"{job_url}/api/json"
        job_params = {"tree": "name,upstreamProjects[name],downstreamProjects[name]"}
        status_j, _, body_j = self.request("GET", job_endpoint, params=job_params)

        upstream_projects = []
        downstream_projects = []
        if status_j == 200:
            j_data = json.loads(body_j.decode("utf-8", errors="replace"))
            upstream_projects = [p.get("name") for p in j_data.get("upstreamProjects", []) if p.get("name")]
            downstream_projects = [p.get("name") for p in j_data.get("downstreamProjects", []) if p.get("name")]

        return {
            "ok": True,
            "job_name": job_name,
            "build_number": actual_build_number,
            "upstream_causes": upstream_causes,
            "upstream_projects": upstream_projects,
            "downstream_projects": downstream_projects,
        }

    def restart_job(
        self,
        job_name: str,
        build_number: int | None = None,
    ) -> dict[str, Any]:
        """Re-trigger the specified build reusing its original parameters."""
        job_url = normalize_job_url(self.base_url, job_name)
        build_id = str(build_number) if build_number is not None else "lastBuild"

        endpoint = f"{job_url}/{build_id}/api/json"
        params = {"tree": "actions[parameters[name,value]]"}
        status, _, body = self.request("GET", endpoint, params=params)

        previous_params: dict[str, Any] = {}
        if status == 200:
            data = json.loads(body.decode("utf-8", errors="replace"))
            for action in data.get("actions", []):
                if action and "parameters" in action:
                    for p in action["parameters"]:
                        if "name" in p and "value" in p:
                            previous_params[p["name"]] = p["value"]

        return self.trigger_job(job_name, params=previous_params if previous_params else None)


class JenkinsConfigManager:
    """Manages multi-instance Jenkins configurations and project-to-instance bindings."""

    DEFAULT_CONFIG_PATH = Path.home() / ".gemini" / "jenkins_config.json"

    def __init__(self, config_file: str | Path | None = None) -> None:
        if config_file:
            self.config_path = Path(config_file)
        elif "JENKINS_CONFIG_PATH" in os.environ:
            self.config_path = Path(os.environ["JENKINS_CONFIG_PATH"])
        else:
            self.config_path = self.DEFAULT_CONFIG_PATH

    def _ensure_dir(self) -> None:
        if not self.config_path.parent.exists():
            self.config_path.parent.mkdir(parents=True, exist_ok=True)

    def load_config(self) -> dict[str, Any]:
        """Load configuration dictionary from disk."""
        config: dict[str, Any] = {"instances": {}, "projects": {}}
        if self.config_path.exists():
            try:
                with open(self.config_path, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    if isinstance(data, dict):
                        config["instances"] = data.get("instances", {})
                        config["projects"] = data.get("projects", {})
            except Exception:
                pass

        return config

    def save_config(self, config: dict[str, Any]) -> None:
        """Save configuration dictionary atomically to disk."""
        self._ensure_dir()
        temp_path = self.config_path.with_suffix(".tmp")
        with open(temp_path, "w", encoding="utf-8") as f:
            json.dump(config, f, indent=2, ensure_ascii=False)
        temp_path.replace(self.config_path)

    def configure_instance(self, alias: str, url: str, user: str = "", token: str = "") -> dict[str, Any]:
        """Register or update a Jenkins instance."""
        alias = alias.strip().lower()
        if not alias:
            raise ValueError("Instance alias cannot be empty")
        if not url:
            raise ValueError("Instance URL cannot be empty")

        config = self.load_config()
        config["instances"][alias] = {
            "url": url.strip().rstrip("/"),
            "user": user.strip(),
            "token": token.strip(),
        }
        self.save_config(config)
        return {"ok": True, "alias": alias, "url": url}

    def list_instances(self) -> list[dict[str, Any]]:
        """List all registered instances."""
        config = self.load_config()
        instances = []
        for alias, info in config.get("instances", {}).items():
            instances.append(
                {
                    "alias": alias,
                    "url": info.get("url", ""),
                    "user": info.get("user", ""),
                    "has_token": bool(info.get("token")),
                }
            )

        # Fallback to env vars if no file instances configured
        if not instances:
            env_url = os.environ.get("JENKINS_URL", "").strip()
            if env_url:
                instances.append(
                    {
                        "alias": "default",
                        "url": env_url,
                        "user": os.environ.get("JENKINS_USER", "").strip(),
                        "has_token": bool(os.environ.get("JENKINS_API_TOKEN", "").strip()),
                    }
                )

        return instances

    def get_instance(self, alias: str | None = None) -> dict[str, Any] | None:
        """Retrieve instance credentials by alias (or return the first available)."""
        config = self.load_config()
        instances = config.get("instances", {})
        if instances:
            if alias:
                norm_alias = alias.strip().lower()
                if norm_alias in instances:
                    res = dict(instances[norm_alias])
                    res["alias"] = norm_alias
                    return res
                return None

            # Return default or first instance
            if "default" in instances:
                res = dict(instances["default"])
                res["alias"] = "default"
                return res

            first_key = next(iter(instances))
            res = dict(instances[first_key])
            res["alias"] = first_key
            return res

        # Fallback to env vars
        env_url = os.environ.get("JENKINS_URL", "").strip()
        if env_url:
            return {
                "alias": "default",
                "url": env_url,
                "user": os.environ.get("JENKINS_USER", "").strip(),
                "token": os.environ.get("JENKINS_API_TOKEN", "").strip(),
            }

        return None

    def map_project(
        self,
        project_identifier: str,
        instance_alias: str,
        job_name: str | None = None,
    ) -> dict[str, Any]:
        """Map a project (git remote URL or directory path) to a Jenkins instance and job."""
        key = project_identifier.strip().replace("\\", "/").lower()
        instance_alias = instance_alias.strip().lower()

        config = self.load_config()
        if instance_alias not in config.get("instances", {}):
            raise ValueError(f"Instance '{instance_alias}' is not registered.")

        config["projects"][key] = {
            "instance": instance_alias,
            "job_name": job_name.strip() if job_name else "",
        }
        self.save_config(config)
        return {
            "ok": True,
            "project": key,
            "instance": instance_alias,
            "job_name": job_name,
        }

    def get_project_mapping(self, project_identifier: str) -> dict[str, Any] | None:
        """Find the mapped Jenkins instance and job for a project."""
        key = project_identifier.strip().replace("\\", "/").lower()
        config = self.load_config()
        projects = config.get("projects", {})

        # 1. Exact match
        if key in projects:
            return dict(projects[key])

        # 2. Match by repo name / substring (e.g. 'superpowers_aipro')
        for stored_key, mapping in projects.items():
            if key.endswith(stored_key) or stored_key.endswith(key):
                return dict(mapping)
            # Match folder name
            if Path(stored_key).name == Path(key).name:
                return dict(mapping)

        return None

    def get_client(
        self,
        instance_alias: str | None = None,
        project_identifier: str | None = None,
        timeout: float = 15.0,
    ) -> tuple[JenkinsClient, str]:
        """Resolve the appropriate JenkinsClient and active alias."""
        # 1. Check project mapping if instance_alias not specified
        if not instance_alias and project_identifier:
            mapping = self.get_project_mapping(project_identifier)
            if mapping and "instance" in mapping:
                instance_alias = mapping["instance"]

        # 2. Get instance config
        inst = self.get_instance(instance_alias)
        if not inst:
            # Fallback to localhost if nothing configured
            base_url = os.environ.get("JENKINS_URL", "http://localhost:8080")
            user = os.environ.get("JENKINS_USER", "")
            token = os.environ.get("JENKINS_API_TOKEN", "")
            return JenkinsClient(base_url=base_url, user=user, token=token, timeout=timeout), "default"

        return (
            JenkinsClient(
                base_url=inst["url"],
                user=inst.get("user", ""),
                token=inst.get("token", ""),
                timeout=timeout,
            ),
            inst.get("alias", "default"),
        )
