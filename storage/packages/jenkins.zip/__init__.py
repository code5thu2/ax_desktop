"""Jenkins MCP Server exports."""

try:
    from .server import main, mcp
except ImportError:
    from server import main, mcp

__all__ = ["main", "mcp"]
__version__ = "0.1.0"
