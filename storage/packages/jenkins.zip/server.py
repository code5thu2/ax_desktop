"""Jenkins Model Context Protocol (MCP) Server.

Built for Python 3.14. Native, secure, and auditable Jenkins integration.
Supports multi-instance configurations (e.g. 2+ Jenkins versions/servers)
and automated Git project-to-instance mappings.
"""

from __future__ import annotations

import os
from typing import Any

from mcp.server import MCPServer

try:
    from common import McpError, make_access, ok
except ImportError:
    # Standalone fallback when imported outside D:/AI_MCP
    def ok(**kw: Any) -> dict[str, Any]:
        return {"ok": True, **kw}

    class McpError(Exception):
        pass

    def make_access(env_var: str):
        def access_mode():
            return os.environ.get(env_var, "readwrite")

        def is_readonly():
            return access_mode().lower() == "readonly"

        def require_write():
            if is_readonly():
                raise McpError(f"Operation denied: {env_var}=readonly")

        return access_mode, is_readonly, require_write

try:
    from .helpers import JenkinsClient, JenkinsConfigManager
except ImportError:
    from jenkins_mcp.helpers import JenkinsClient, JenkinsConfigManager

# Guard readonly/readwrite via environment variable
access_mode, is_readonly, require_write = make_access("JENKINS_ACCESS_MODE")

mcp = MCPServer(
    "jenkins",
    instructions=(
        "Jenkins CI/CD integration server. Supports multiple Jenkins instances/versions, "
        "project-to-instance bindings, triggering builds, polling status, inspecting console logs, "
        "stage breakdown for pipelines, and Upstream/Downstream tracing."
    ),
)

config_mgr = JenkinsConfigManager()


def get_client(
    instance_alias: str | None = None,
    project_identifier: str | None = None,
) -> tuple[JenkinsClient, str]:
    """Retrieve JenkinsClient and active alias for an instance or project."""
    return config_mgr.get_client(
        instance_alias=instance_alias,
        project_identifier=project_identifier,
    )


@mcp.tool()
def server_info(
    instance: str | None = None,
    project: str | None = None,
) -> dict[str, Any]:
    """Retrieve Jenkins MCP server status, all registered instances, and active instance details.

    Pass instance (alias) or project (path/repo) to inspect a specific target.
    """
    client, active_alias = get_client(instance_alias=instance, project_identifier=project)
    info = client.get_server_info()
    all_instances = config_mgr.list_instances()

    return ok(
        access_mode=access_mode(),
        is_readonly=is_readonly(),
        active_instance=active_alias,
        jenkins_url=client.base_url,
        jenkins_version=info.get("jenkins_version", "Unknown"),
        connection_ok=info.get("ok", False),
        registered_instances=all_instances,
        server_details=info,
    )


@mcp.tool()
def jenkins_list_instances() -> dict[str, Any]:
    """List all configured Jenkins server instances (e.g. Jenkins 1, Jenkins 2) and their URLs."""
    instances = config_mgr.list_instances()
    return ok(instances=instances, count=len(instances))


@mcp.tool()
def jenkins_configure_instance(
    alias: str,
    url: str,
    user: str = "",
    token: str = "",
) -> dict[str, Any]:
    """Register or update a Jenkins instance with an alias/name, URL, username, and API token.

    Example: alias='jenkins-dev', url='http://jenkins-dev:8080', user='admin', token='...'
    Persists configuration so you don't need to re-enter it.
    Requires write access (JENKINS_ACCESS_MODE=readwrite).
    """
    require_write()
    res = config_mgr.configure_instance(alias=alias, url=url, user=user, token=token)
    return ok(**res)


@mcp.tool()
def jenkins_map_project(
    project_identifier: str,
    instance_alias: str,
    default_job: str | None = None,
) -> dict[str, Any]:
    """Bind a project (git repository path or git remote URL) to a Jenkins instance and default job.

    Example: project_identifier='D:/superpowers_aipro', instance_alias='jenkins-1', default_job='superpowers-ci'
    Persists the mapping so all future builds for this project use the right Jenkins automatically.
    Requires write access (JENKINS_ACCESS_MODE=readwrite).
    """
    require_write()
    res = config_mgr.map_project(
        project_identifier=project_identifier,
        instance_alias=instance_alias,
        job_name=default_job,
    )
    return ok(**res)


@mcp.tool()
def jenkins_get_project_config(project_identifier: str) -> dict[str, Any]:
    """Retrieve the mapped Jenkins instance and default job for a project."""
    mapping = config_mgr.get_project_mapping(project_identifier)
    return ok(
        project=project_identifier,
        mapped=bool(mapping),
        config=mapping,
    )


@mcp.tool()
def jenkins_trigger_job(
    job_name: str,
    params: dict[str, Any] | None = None,
    instance: str | None = None,
    project: str | None = None,
) -> dict[str, Any]:
    """Trigger a Jenkins build for a Freestyle project or Pipeline.

    Supports multibranch/folder paths (e.g. 'folder/job-name' or 'repo/main').
    Parameters can be passed as a dictionary of key-value pairs.
    Optionally specify target instance alias or project path.
    Requires write access (JENKINS_ACCESS_MODE=readwrite).
    """
    require_write()
    client, active_alias = get_client(instance_alias=instance, project_identifier=project)
    res = client.trigger_job(job_name=job_name, params=params)
    if not res.get("ok"):
        raise McpError(res.get("error", "Trigger failed"))
    return ok(active_instance=active_alias, **res)


@mcp.tool()
def jenkins_get_build_status(
    job_name: str,
    build_number: int | None = None,
    instance: str | None = None,
    project: str | None = None,
) -> dict[str, Any]:
    """Get build status (BUILDING, SUCCESS, FAILURE, UNSTABLE, ABORTED).

    If build_number is omitted, queries the latest build (lastBuild).
    """
    client, active_alias = get_client(instance_alias=instance, project_identifier=project)
    res = client.get_build_status(job_name=job_name, build_number=build_number)
    if not res.get("ok"):
        raise McpError(res.get("error", "Failed to retrieve build status"))
    return ok(active_instance=active_alias, **res)


@mcp.tool()
def jenkins_get_pipeline_stages(
    job_name: str,
    build_number: int | None = None,
    instance: str | None = None,
    project: str | None = None,
) -> dict[str, Any]:
    """Retrieve stage-by-stage execution breakdown for a Pipeline job via /wfapi/describe.

    Identifies which exact stage failed (e.g. Checkout, Compile, Test, Docker Build).
    Gracefully returns an empty list for Freestyle projects.
    """
    client, active_alias = get_client(instance_alias=instance, project_identifier=project)
    stages = client.get_pipeline_stages(job_name=job_name, build_number=build_number)
    return ok(
        active_instance=active_alias,
        job_name=job_name,
        build_number=build_number,
        is_pipeline=len(stages) > 0,
        stages=stages,
    )


@mcp.tool()
def jenkins_get_console_output(
    job_name: str,
    build_number: int | None = None,
    tail_lines: int = 200,
    instance: str | None = None,
    project: str | None = None,
) -> dict[str, Any]:
    """Fetch text console output from a build.

    tail_lines specifies how many trailing lines to retrieve (default: 200).
    Set tail_lines=0 to retrieve the entire console log.
    """
    client, active_alias = get_client(instance_alias=instance, project_identifier=project)
    output = client.get_console_output(
        job_name=job_name,
        build_number=build_number,
        tail_lines=tail_lines,
    )
    return ok(
        active_instance=active_alias,
        job_name=job_name,
        build_number=build_number,
        tail_lines=tail_lines,
        console_output=output,
    )


@mcp.tool()
def jenkins_get_pipeline_graph(
    job_name: str,
    build_number: int | None = None,
    instance: str | None = None,
    project: str | None = None,
) -> dict[str, Any]:
    """Inspect Upstream causes (parent pipeline/build that triggered this) and Downstream projects."""
    client, active_alias = get_client(instance_alias=instance, project_identifier=project)
    graph = client.get_pipeline_graph(job_name=job_name, build_number=build_number)
    return ok(active_instance=active_alias, **graph)


@mcp.tool()
def jenkins_restart_job(
    job_name: str,
    build_number: int | None = None,
    instance: str | None = None,
    project: str | None = None,
) -> dict[str, Any]:
    """Restart/re-trigger a build reusing identical parameters from the previous run.

    Requires write access (JENKINS_ACCESS_MODE=readwrite).
    """
    require_write()
    client, active_alias = get_client(instance_alias=instance, project_identifier=project)
    res = client.restart_job(job_name=job_name, build_number=build_number)
    if not res.get("ok"):
        raise McpError(res.get("error", "Failed to restart job"))
    return ok(active_instance=active_alias, **res)


def main() -> None:
    """Launch Jenkins MCP server communicating over stdio."""
    mcp.run()


if __name__ == "__main__":
    main()
