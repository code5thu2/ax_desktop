"""Main execution entrypoint for python -m servers.jenkins_mcp or python -m jenkins_mcp."""

try:
    from .server import main
except ImportError:
    from server import main

if __name__ == "__main__":
    main()
