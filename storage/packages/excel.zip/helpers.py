"""Tiện ích dùng chung cho các tool Excel (openpyxl + pandas)."""

from __future__ import annotations

import os
import posixpath
import zipfile
import xml.etree.ElementTree as ET
from typing import Any, Iterator

import openpyxl
from openpyxl.utils import get_column_letter
from openpyxl.utils.cell import column_index_from_string, coordinate_from_string
from openpyxl.worksheet.worksheet import Worksheet

from common import IMAGE_MIME, VISION_OK_MIME, McpError, jsonify, make_access
from common import sniff_size as _sniff_size

ExcelError = McpError  # alias cho dễ đọc
access_mode, is_readonly, require_write = make_access("EXCEL_ACCESS_MODE")


# --------------------------------------------------------------------------- #
# Đường dẫn & workbook
# --------------------------------------------------------------------------- #
def resolve_path(path: str, must_exist: bool = True) -> str:
    """Chuẩn hoá đường dẫn tuyệt đối và kiểm tra tồn tại nếu cần."""
    abspath = os.path.abspath(os.path.expanduser(path))
    if must_exist and not os.path.isfile(abspath):
        raise ExcelError(f"Không tìm thấy file: {abspath}")
    if not abspath.lower().endswith((".xlsx", ".xlsm")):
        raise ExcelError("Chỉ hỗ trợ định dạng .xlsx / .xlsm")
    return abspath


def load_workbook(path: str, data_only: bool = False) -> openpyxl.Workbook:
    """Mở workbook. data_only=True để đọc giá trị đã tính thay vì công thức."""
    abspath = resolve_path(path, must_exist=True)
    try:
        return openpyxl.load_workbook(abspath, data_only=data_only)
    except Exception as exc:  # noqa: BLE001
        raise ExcelError(f"Không mở được workbook: {exc}") from exc


def save_workbook(wb: openpyxl.Workbook, path: str) -> str:
    """Lưu workbook, trả về đường dẫn tuyệt đối. Chặn nếu đang readonly."""
    require_write()
    abspath = os.path.abspath(os.path.expanduser(path))
    os.makedirs(os.path.dirname(abspath) or ".", exist_ok=True)
    try:
        wb.save(abspath)
    except PermissionError as exc:
        raise ExcelError(
            f"Không ghi được file (đang mở trong Excel?): {abspath}"
        ) from exc
    return abspath


def get_sheet(wb: openpyxl.Workbook, sheet: str | None) -> Worksheet:
    """Lấy worksheet theo tên; None = sheet đang active."""
    if sheet is None:
        return wb.active
    if sheet not in wb.sheetnames:
        raise ExcelError(
            f"Không có sheet '{sheet}'. Các sheet hiện có: {wb.sheetnames}"
        )
    return wb[sheet]


# --------------------------------------------------------------------------- #
# JSON hoá giá trị cell
# --------------------------------------------------------------------------- #
def jsonify_grid(rows: list[list[Any]]) -> list[list[Any]]:
    return [[jsonify(v) for v in row] for row in rows]


# --------------------------------------------------------------------------- #
# Range helpers
# --------------------------------------------------------------------------- #
def parse_start_cell(cell: str) -> tuple[int, int]:
    """'B3' -> (row=3, col=2)."""
    col_letter, row = coordinate_from_string(cell)
    return row, column_index_from_string(col_letter)


def cell_ref(row: int, col: int) -> str:
    return f"{get_column_letter(col)}{row}"


# --------------------------------------------------------------------------- #
# Ảnh nhúng trong workbook (đọc trực tiếp từ zip, không cần Pillow)
# --------------------------------------------------------------------------- #
def _ns(tag: str) -> str:
    """Bỏ namespace khỏi tag XML: '{...}col' -> 'col'."""
    return tag.split("}")[-1]


def _resolve_target(base_dir: str, target: str) -> str:
    """Chuẩn hoá Target trong file .rels về đường dẫn nội bộ zip."""
    if target.startswith("/"):
        return target.lstrip("/")
    return posixpath.normpath(posixpath.join(base_dir, target))


def _rels_of(z: zipfile.ZipFile, part: str) -> dict[str, str]:
    """Đọc quan hệ (_rels) của một part: {rId: target_path}."""
    d, b = posixpath.split(part)
    rp = posixpath.join(d, "_rels", b + ".rels")
    out: dict[str, str] = {}
    if rp in z.namelist():
        for r in ET.fromstring(z.read(rp)):
            out[r.get("Id")] = _resolve_target(d, r.get("Target", ""))
    return out


def _drawing_parts_of(z: zipfile.ZipFile, part: str) -> list[str]:
    """Tìm các file drawing của một worksheet qua quan hệ (theo Type).

    Đọc thẳng file .rels thay vì parse toàn bộ worksheet XML — an toàn với sheet
    dữ liệu khổng lồ (có thể tới hàng GB khi giải nén).
    """
    d, b = posixpath.split(part)
    rp = posixpath.join(d, "_rels", b + ".rels")
    out: list[str] = []
    if rp in z.namelist():
        for r in ET.fromstring(z.read(rp)):
            if r.get("Type", "").endswith("/drawing"):
                out.append(_resolve_target(d, r.get("Target", "")))
    return out


def iter_workbook_images(path: str) -> Iterator[dict[str, Any]]:
    """Duyệt mọi ảnh nhúng trong .xlsx/.xlsm, kèm sheet + ô neo.

    Mỗi phần tử: {sheet, cell, filename, mime, bytes, width, height, data}.
    Đọc thẳng từ cấu trúc zip nên không cần Pillow; ảnh không map được vào ô
    (ví dụ ảnh header/footer) vẫn được trả với sheet/cell = None.
    """
    abspath = resolve_path(path, must_exist=True)
    with zipfile.ZipFile(abspath) as z:
        names = set(z.namelist())
        seen: set[str] = set()

        wb = ET.fromstring(z.read("xl/workbook.xml"))
        wbrels = _rels_of(z, "xl/workbook.xml")
        sheets: list[tuple[str, str]] = []
        for s in wb.iter():
            if _ns(s.tag) == "sheet":
                rid = next(v for k, v in s.attrib.items() if k.endswith("}id"))
                if rid in wbrels:
                    sheets.append((s.get("name", "?"), wbrels[rid]))

        for sheet_name, wspart in sheets:
            if wspart not in names:
                continue
            # Lấy drawing từ quan hệ của sheet, KHÔNG đọc worksheet XML (có thể rất lớn).
            for dpart in _drawing_parts_of(z, wspart):
                if dpart not in names:
                    continue
                drels = _rels_of(z, dpart)
                drawing = ET.fromstring(z.read(dpart))
                for anc in drawing:
                    if _ns(anc.tag) not in ("twoCellAnchor", "oneCellAnchor"):
                        continue
                    col = row = None
                    for sub in anc:
                        if _ns(sub.tag) == "from":
                            for c in sub:
                                if _ns(c.tag) == "col":
                                    col = int(c.text)
                                elif _ns(c.tag) == "row":
                                    row = int(c.text)
                    embed = None
                    for e in anc.iter():
                        if _ns(e.tag) == "blip":
                            vals = [v for k, v in e.attrib.items() if k.endswith("}embed")]
                            embed = vals[0] if vals else None
                    media = drels.get(embed) if embed else None
                    if not media or media not in names:
                        continue
                    seen.add(media)
                    data = z.read(media)
                    w, h = _sniff_size(data)
                    cell = (
                        f"{get_column_letter(col + 1)}{row + 1}"
                        if col is not None and row is not None
                        else None
                    )
                    yield {
                        "sheet": sheet_name,
                        "cell": cell,
                        "filename": posixpath.basename(media),
                        "mime": IMAGE_MIME.get(
                            os.path.splitext(media)[1].lower(), "application/octet-stream"
                        ),
                        "bytes": len(data),
                        "width": w,
                        "height": h,
                        "data": data,
                    }

        # Ảnh còn sót trong xl/media/ nhưng không neo vào sheet nào.
        for media in sorted(n for n in names if n.startswith("xl/media/")):
            if media in seen:
                continue
            data = z.read(media)
            w, h = _sniff_size(data)
            yield {
                "sheet": None,
                "cell": None,
                "filename": posixpath.basename(media),
                "mime": IMAGE_MIME.get(
                    os.path.splitext(media)[1].lower(), "application/octet-stream"
                ),
                "bytes": len(data),
                "width": w,
                "height": h,
                "data": data,
            }
