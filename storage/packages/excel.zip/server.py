"""MCP server thao tác Excel bằng openpyxl + pandas.

Chạy: python -m excel_mcp   (transport stdio, dùng cho Claude Desktop / Claude Code)
"""

from __future__ import annotations

import copy as _pycopy
import os
import shutil
from typing import Any, Literal

import openpyxl
from common import LazyModule, image_blocks, templates
from common import ok as _ok
pd = LazyModule("pandas")
from mcp.server import MCPServer
from mcp.types import CallToolResult
from openpyxl.chart import BarChart, LineChart, PieChart, Reference
from openpyxl.utils import get_column_letter
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.worksheet.table import Table, TableStyleInfo

from .helpers import (
    VISION_OK_MIME,
    ExcelError,
    access_mode,
    cell_ref,
    get_sheet,
    iter_workbook_images,
    jsonify,
    jsonify_grid,
    load_workbook,
    parse_start_cell,
    require_write,
    resolve_path,
    save_workbook,
)

mcp = MCPServer(
    "excel",
    instructions=(
        "Công cụ đọc/ghi/định dạng file Excel (.xlsx). "
        "Đường dẫn có thể tương đối hoặc tuyệt đối. "
        "Mọi thao tác ghi đều lưu trực tiếp xuống file."
    ),
)


@mcp.tool()
def server_info() -> dict[str, Any]:
    """Xem chế độ truy cập hiện tại (readonly/readwrite)."""
    return _ok(access_mode=access_mode())


# ========================================================================== #
# 1. Sheet & cell cơ bản
# ========================================================================== #
@mcp.tool()
def create_workbook(
    path: str, sheet_name: str = "Sheet1", overwrite: bool = False
) -> dict[str, Any]:
    """Tạo workbook .xlsx mới. Đặt overwrite=True để ghi đè nếu file đã tồn tại."""
    abspath = os.path.abspath(os.path.expanduser(path))
    if os.path.exists(abspath) and not overwrite:
        raise ExcelError(f"File đã tồn tại: {abspath} (dùng overwrite=True để ghi đè)")
    wb = openpyxl.Workbook()
    wb.active.title = sheet_name
    saved = save_workbook(wb, abspath)
    return _ok(path=saved, sheets=[sheet_name])


@mcp.tool()
def get_workbook_info(path: str) -> dict[str, Any]:
    """Xem thông tin tổng quan: danh sách sheet, kích thước (số dòng/cột) mỗi sheet."""
    wb = load_workbook(path)
    sheets = []
    for name in wb.sheetnames:
        ws = wb[name]
        sheets.append(
            {
                "name": name,
                "rows": ws.max_row,
                "cols": ws.max_column,
                "dimensions": ws.dimensions,
            }
        )
    return _ok(path=resolve_path(path), active=wb.active.title, sheets=sheets)


@mcp.tool()
def list_sheets(path: str) -> dict[str, Any]:
    """Liệt kê tên các sheet trong workbook."""
    wb = load_workbook(path)
    return _ok(sheets=wb.sheetnames)


@mcp.tool()
def add_sheet(path: str, sheet_name: str, index: int | None = None) -> dict[str, Any]:
    """Thêm một sheet mới. index=None -> thêm vào cuối."""
    wb = load_workbook(path)
    if sheet_name in wb.sheetnames:
        raise ExcelError(f"Sheet '{sheet_name}' đã tồn tại")
    wb.create_sheet(title=sheet_name, index=index)
    save_workbook(wb, path)
    return _ok(sheets=wb.sheetnames)


@mcp.tool()
def delete_sheet(path: str, sheet_name: str) -> dict[str, Any]:
    """Xoá một sheet."""
    wb = load_workbook(path)
    ws = get_sheet(wb, sheet_name)
    if len(wb.sheetnames) == 1:
        raise ExcelError("Không thể xoá sheet cuối cùng của workbook")
    wb.remove(ws)
    save_workbook(wb, path)
    return _ok(sheets=wb.sheetnames)


@mcp.tool()
def rename_sheet(path: str, old_name: str, new_name: str) -> dict[str, Any]:
    """Đổi tên sheet."""
    wb = load_workbook(path)
    ws = get_sheet(wb, old_name)
    if new_name in wb.sheetnames:
        raise ExcelError(f"Sheet '{new_name}' đã tồn tại")
    ws.title = new_name
    save_workbook(wb, path)
    return _ok(sheets=wb.sheetnames)


def _normalize_range(region: Any) -> tuple[tuple[Any, ...], ...]:
    """Chuẩn hoá cấu trúc vùng ô về dạng 2 chiều (tuple của tuple) an toàn khi duyệt."""
    if not isinstance(region, tuple):  # 1 ô đơn
        return ((region,),)
    if region and not isinstance(region[0], tuple):  # 1 hàng hoặc 1 cột
        return (region,)
    return region


@mcp.tool()
def read_range(
    path: str,
    sheet: str | None = None,
    cell_range: str | None = None,
    evaluate_formulas: bool = True,
) -> dict[str, Any]:
    """Đọc dữ liệu dạng lưới 2 chiều.

    cell_range: ví dụ "A1:C10". None -> đọc toàn bộ vùng đã dùng.
    evaluate_formulas=True -> trả giá trị đã tính; False -> trả công thức thô.
    """
    wb = load_workbook(path, data_only=evaluate_formulas)
    ws = get_sheet(wb, sheet)
    region = ws[cell_range] if cell_range else ws.iter_rows()
    region = _normalize_range(region)
    rows = [[cell.value for cell in row] for row in region]
    return _ok(sheet=ws.title, range=cell_range or ws.dimensions, values=jsonify_grid(rows))


@mcp.tool()
def read_cell(
    path: str, cell: str, sheet: str | None = None, evaluate_formulas: bool = True
) -> dict[str, Any]:
    """Đọc giá trị của một ô, ví dụ cell="B2"."""
    wb = load_workbook(path, data_only=evaluate_formulas)
    ws = get_sheet(wb, sheet)
    return _ok(sheet=ws.title, cell=cell, value=jsonify(ws[cell].value))


# --------------------------------------------------------------------------- #
# Đọc ĐẦY ĐỦ định dạng ô
# --------------------------------------------------------------------------- #
def _color(color: Any) -> str | None:
    """Chuẩn hoá openpyxl Color -> chuỗi: 'AARRGGBB', 'theme:N', 'indexed:N' hoặc None."""
    if color is None:
        return None
    ctype = getattr(color, "type", None)
    if ctype == "rgb":
        return color.rgb if isinstance(color.rgb, str) else None
    if ctype == "theme":
        s = f"theme:{color.theme}"
        if getattr(color, "tint", 0):
            s += f",tint:{round(color.tint, 3)}"
        return s
    if ctype == "indexed":
        return f"indexed:{color.indexed}"
    rgb = getattr(color, "rgb", None)
    return rgb if isinstance(rgb, str) else None


def _side(side: Any) -> dict[str, Any] | None:
    if side is None or side.style is None:
        return None
    return {"style": side.style, "color": _color(side.color)}


def _cell_format(ws: Any, coord: str) -> dict[str, Any]:
    """Trích toàn bộ định dạng của một ô."""
    c = ws[coord]
    fill = c.fill
    solid = bool(fill and fill.patternType)
    font, al, b, prot = c.font, c.alignment, c.border, c.protection
    merged = None
    for mr in ws.merged_cells.ranges:
        if mr.min_row <= c.row <= mr.max_row and mr.min_col <= c.column <= mr.max_col:
            merged = str(mr)
            break
    return {
        "cell": coord,
        "data_type": c.data_type,
        "bg_color": _color(fill.fgColor) if solid else None,  # nền = fgColor khi solid
        "fill": (
            {"pattern": fill.patternType, "fg": _color(fill.fgColor), "bg": _color(fill.bgColor)}
            if solid else None
        ),
        "font": {
            "name": font.name, "size": font.size, "bold": font.bold, "italic": font.italic,
            "underline": font.underline, "strike": font.strike, "color": _color(font.color),
            "vert_align": font.vertAlign,
        },
        "border": {
            "left": _side(b.left), "right": _side(b.right), "top": _side(b.top),
            "bottom": _side(b.bottom), "diagonal": _side(b.diagonal),
        },
        "alignment": {
            "horizontal": al.horizontal, "vertical": al.vertical, "wrap_text": al.wrap_text,
            "shrink_to_fit": al.shrink_to_fit, "indent": al.indent, "text_rotation": al.text_rotation,
        },
        "number_format": c.number_format,
        "protection": {"locked": prot.locked, "hidden": prot.hidden},
        "hyperlink": c.hyperlink.target if c.hyperlink else None,
        "comment": c.comment.text if c.comment else None,
        "style_name": c.style,
        "merged": merged,
        "column_width": ws.column_dimensions[get_column_letter(c.column)].width,
        "row_height": ws.row_dimensions[c.row].height,
    }


@mcp.tool()
def read_cell_format(
    path: str,
    cell: str,
    sheet: str | None = None,
    include_value: bool = True,
    evaluate_formulas: bool = True,
) -> dict[str, Any]:
    """Đọc ĐẦY ĐỦ định dạng một ô: màu nền, fill, font (đậm/nghiêng/gạch/màu/size/tên),
    border 4+chéo, canh lề (wrap/xoay/indent), number_format, protection, hyperlink,
    comment, style name, vùng merge, độ rộng cột & cao dòng."""
    wb = load_workbook(path, data_only=evaluate_formulas)
    ws = get_sheet(wb, sheet)
    fmt = _cell_format(ws, cell)
    if include_value:
        fmt["value"] = jsonify(ws[cell].value)
    return _ok(sheet=ws.title, **fmt)


@mcp.tool()
def read_range_format(
    path: str,
    cell_range: str,
    sheet: str | None = None,
    include_value: bool = True,
    evaluate_formulas: bool = True,
) -> dict[str, Any]:
    """Đọc đầy đủ định dạng cho MỌI ô trong vùng (vd "A1:C5"). Xem read_cell_format."""
    wb = load_workbook(path, data_only=evaluate_formulas)
    ws = get_sheet(wb, sheet)
    region = _normalize_range(ws[cell_range])
    out = []
    for row in region:
        for c in row:
            fmt = _cell_format(ws, c.coordinate)
            if include_value:
                fmt["value"] = jsonify(c.value)
            out.append(fmt)
    return _ok(sheet=ws.title, range=cell_range, count=len(out), cells=out)


@mcp.tool()
def write_cell(
    path: str, cell: str, value: Any, sheet: str | None = None
) -> dict[str, Any]:
    """Ghi giá trị vào một ô. Chuỗi bắt đầu bằng '=' được coi là công thức."""
    wb = load_workbook(path)
    ws = get_sheet(wb, sheet)
    ws[cell] = value
    save_workbook(wb, path)
    return _ok(sheet=ws.title, cell=cell)


@mcp.tool()
def write_range(
    path: str,
    values: list[list[Any]],
    start_cell: str = "A1",
    sheet: str | None = None,
) -> dict[str, Any]:
    """Ghi một lưới 2 chiều bắt đầu từ start_cell (mặc định A1).

    values là danh sách các dòng, mỗi dòng là danh sách giá trị.
    """
    if not values:
        raise ExcelError("values rỗng")
    wb = load_workbook(path)
    ws = get_sheet(wb, sheet)
    r0, c0 = parse_start_cell(start_cell)
    for i, row in enumerate(values):
        for j, val in enumerate(row):
            ws.cell(row=r0 + i, column=c0 + j, value=val)
    end = cell_ref(r0 + len(values) - 1, c0 + max(len(r) for r in values) - 1)
    save_workbook(wb, path)
    return _ok(sheet=ws.title, range=f"{start_cell}:{end}", rows=len(values))


@mcp.tool()
def clear_range(
    path: str, cell_range: str, sheet: str | None = None
) -> dict[str, Any]:
    """Xoá nội dung các ô trong vùng (giữ nguyên định dạng)."""
    wb = load_workbook(path)
    ws = get_sheet(wb, sheet)
    for row in _normalize_range(ws[cell_range]):
        for cell in row:
            cell.value = None
    save_workbook(wb, path)
    return _ok(sheet=ws.title, range=cell_range)


# ========================================================================== #
# 2. Công thức & định dạng
# ========================================================================== #
@mcp.tool()
def set_formula(
    path: str, cell: str, formula: str, sheet: str | None = None
) -> dict[str, Any]:
    """Đặt công thức cho một ô. formula tự thêm '=' nếu thiếu, ví dụ "SUM(A1:A10)"."""
    wb = load_workbook(path)
    ws = get_sheet(wb, sheet)
    ws[cell] = formula if formula.startswith("=") else f"={formula}"
    save_workbook(wb, path)
    return _ok(sheet=ws.title, cell=cell, formula=ws[cell].value)


@mcp.tool()
def format_range(
    path: str,
    cell_range: str,
    sheet: str | None = None,
    bold: bool | None = None,
    italic: bool | None = None,
    font_size: float | None = None,
    font_color: str | None = None,
    bg_color: str | None = None,
    number_format: str | None = None,
    h_align: Literal["left", "center", "right"] | None = None,
    v_align: Literal["top", "center", "bottom"] | None = None,
    wrap_text: bool | None = None,
    border: bool | None = None,
) -> dict[str, Any]:
    """Định dạng một vùng ô.

    Màu dùng mã hex 6 ký tự, ví dụ "FF0000" (đỏ). number_format ví dụ "#,##0.00"
    hoặc "0.0%". border=True vẽ viền mảnh cho mọi ô trong vùng.
    """
    wb = load_workbook(path)
    ws = get_sheet(wb, sheet)

    thin = Side(style="thin")
    box = Border(left=thin, right=thin, top=thin, bottom=thin)

    for row in _normalize_range(ws[cell_range]):
        for cell in row:
            font_kw = {}
            if bold is not None:
                font_kw["bold"] = bold
            if italic is not None:
                font_kw["italic"] = italic
            if font_size is not None:
                font_kw["size"] = font_size
            if font_color is not None:
                font_kw["color"] = font_color.lstrip("#")
            if font_kw:
                f = cell.font
                cell.font = Font(
                    name=f.name,
                    size=font_kw.get("size", f.size),
                    bold=font_kw.get("bold", f.bold),
                    italic=font_kw.get("italic", f.italic),
                    color=font_kw.get("color", f.color),
                    underline=f.underline,
                    strike=f.strike,
                )

            if bg_color is not None:
                hexv = bg_color.lstrip("#")
                cell.fill = PatternFill("solid", fgColor=hexv)

            align_kw = {}
            if h_align is not None:
                align_kw["horizontal"] = h_align
            if v_align is not None:
                align_kw["vertical"] = v_align
            if wrap_text is not None:
                align_kw["wrap_text"] = wrap_text
            if align_kw:
                cell.alignment = Alignment(**align_kw)

            if number_format is not None:
                cell.number_format = number_format
            if border:
                cell.border = box

    save_workbook(wb, path)
    return _ok(sheet=ws.title, range=cell_range)


@mcp.tool()
def merge_cells(path: str, cell_range: str, sheet: str | None = None) -> dict[str, Any]:
    """Gộp các ô trong vùng, ví dụ "A1:D1"."""
    wb = load_workbook(path)
    ws = get_sheet(wb, sheet)
    ws.merge_cells(cell_range)
    save_workbook(wb, path)
    return _ok(sheet=ws.title, merged=cell_range)


@mcp.tool()
def unmerge_cells(
    path: str, cell_range: str, sheet: str | None = None
) -> dict[str, Any]:
    """Bỏ gộp ô cho vùng đã gộp."""
    wb = load_workbook(path)
    ws = get_sheet(wb, sheet)
    ws.unmerge_cells(cell_range)
    save_workbook(wb, path)
    return _ok(sheet=ws.title, unmerged=cell_range)


@mcp.tool()
def set_column_width(
    path: str, column: str, width: float, sheet: str | None = None
) -> dict[str, Any]:
    """Đặt độ rộng cột, ví dụ column="B", width=20."""
    wb = load_workbook(path)
    ws = get_sheet(wb, sheet)
    ws.column_dimensions[column.upper()].width = width
    save_workbook(wb, path)
    return _ok(sheet=ws.title, column=column.upper(), width=width)


@mcp.tool()
def set_row_height(
    path: str, row: int, height: float, sheet: str | None = None
) -> dict[str, Any]:
    """Đặt chiều cao dòng."""
    wb = load_workbook(path)
    ws = get_sheet(wb, sheet)
    ws.row_dimensions[row].height = height
    save_workbook(wb, path)
    return _ok(sheet=ws.title, row=row, height=height)


@mcp.tool()
def autofit_columns(
    path: str, sheet: str | None = None, max_width: float = 60
) -> dict[str, Any]:
    """Ước lượng và giãn độ rộng cột theo nội dung dài nhất (giới hạn max_width).

    Hỗ trợ chuẩn East Asian Width (CJK/Hangul): Các ký tự tiếng Hàn, chữ Hán, Nhật
    chiếm độ rộng gấp đôi (Wide ~2.0) ký tự Latin, đảm bảo không bị cắt cụt text.
    """
    import unicodedata

    wb = load_workbook(path)
    ws = get_sheet(wb, sheet)
    widths: dict[str, float] = {}

    def _calc_cell_width(val: Any) -> float:
        s = str(val)
        w = 0.0
        for ch in s:
            if unicodedata.east_asian_width(ch) in ("W", "F"):
                w += 2.0
            else:
                w += 1.0
        return w

    for row in ws.iter_rows():
        for cell in row:
            if cell.value is None:
                continue
            letter = cell.column_letter
            widths[letter] = max(widths.get(letter, 0.0), _calc_cell_width(cell.value))
    for letter, w in widths.items():
        ws.column_dimensions[letter].width = min(w + 2.5, float(max_width))
    save_workbook(wb, path)
    return _ok(sheet=ws.title, adjusted=len(widths))


# ========================================================================== #
# 3. Bảng & biểu đồ
# ========================================================================== #
@mcp.tool()
def create_table(
    path: str,
    cell_range: str,
    table_name: str,
    sheet: str | None = None,
    style: str = "TableStyleMedium9",
) -> dict[str, Any]:
    """Tạo bảng có định dạng (dòng đầu của vùng là tiêu đề cột).

    table_name không được chứa dấu cách và phải là duy nhất trong workbook.
    """
    wb = load_workbook(path)
    ws = get_sheet(wb, sheet)
    if " " in table_name:
        raise ExcelError("table_name không được chứa dấu cách")
    table = Table(displayName=table_name, ref=cell_range)
    table.tableStyleInfo = TableStyleInfo(
        name=style, showRowStripes=True, showColumnStripes=False
    )
    ws.add_table(table)
    save_workbook(wb, path)
    return _ok(sheet=ws.title, table=table_name, range=cell_range)


@mcp.tool()
def create_chart(
    path: str,
    chart_type: Literal["bar", "line", "pie"],
    data_range: str,
    target_cell: str,
    sheet: str | None = None,
    categories_range: str | None = None,
    title: str | None = None,
) -> dict[str, Any]:
    """Tạo biểu đồ và đặt tại target_cell.

    data_range: vùng dữ liệu số, gồm cả dòng tiêu đề, ví dụ "B1:B10".
    categories_range: vùng nhãn trục (tuỳ chọn), ví dụ "A2:A10".
    """
    wb = load_workbook(path)
    ws = get_sheet(wb, sheet)

    charts = {"bar": BarChart, "line": LineChart, "pie": PieChart}
    if chart_type not in charts:
        raise ExcelError("chart_type phải là 'bar', 'line' hoặc 'pie'")
    chart = charts[chart_type]()
    if title:
        chart.title = title

    data = Reference(ws, range_string=f"{ws.title}!{data_range}")
    chart.add_data(data, titles_from_data=True)
    if categories_range:
        cats = Reference(ws, range_string=f"{ws.title}!{categories_range}")
        chart.set_categories(cats)

    ws.add_chart(chart, target_cell)
    save_workbook(wb, path)
    return _ok(sheet=ws.title, chart=chart_type, anchor=target_cell)



@mcp.tool()
def create_pivot_summary(
    path: str,
    group_by: list[str],
    value_column: str,
    source_sheet: str | None = None,
    agg: Literal["sum", "mean", "count", "min", "max"] = "sum",
    target_sheet: str | None = None,
) -> dict[str, Any]:
    """Tổng hợp kiểu pivot bằng pandas: nhóm theo group_by, gộp value_column.

    Kết quả ghi ra target_sheet (mặc định "<sheet>_summary"). Dòng đầu nguồn là tiêu đề.
    """
    require_write()
    abspath = resolve_path(path)
    src = source_sheet if source_sheet is not None else 0
    df = pd.read_excel(abspath, sheet_name=src)

    missing = [c for c in [*group_by, value_column] if c not in df.columns]
    if missing:
        raise ExcelError(f"Không có cột: {missing}. Cột hiện có: {list(df.columns)}")

    summary = (
        df.groupby(group_by)[value_column].agg(agg).reset_index()
    )
    summary = summary.rename(columns={value_column: f"{agg}_{value_column}"})

    out_name = target_sheet or (
        f"{source_sheet}_summary" if isinstance(source_sheet, str) else "summary"
    )
    with pd.ExcelWriter(
        abspath, engine="openpyxl", mode="a", if_sheet_exists="replace"
    ) as writer:
        summary.to_excel(writer, sheet_name=out_name[:31], index=False)

    return _ok(
        sheet=out_name[:31],
        rows=len(summary),
        columns=list(summary.columns),
        preview=jsonify_grid(summary.head(20).values.tolist()),
    )


# ========================================================================== #
# 4. Dữ liệu & CSV (pandas)
# ========================================================================== #
@mcp.tool()
def read_sheet_as_records(
    path: str, sheet: str | None = None, limit: int | None = 100
) -> dict[str, Any]:
    """Đọc sheet thành danh sách bản ghi (dict), kèm thông tin cột/kiểu dữ liệu.

    limit giới hạn số dòng trả về (None = tất cả).
    """
    abspath = resolve_path(path)
    df = pd.read_excel(abspath, sheet_name=sheet if sheet is not None else 0)
    total = len(df)
    if limit is not None:
        df = df.head(limit)
    records = df.astype(object).where(pd.notna(df), None).to_dict(orient="records")
    records = [jsonify(r) for r in records]
    return _ok(
        total_rows=total,
        returned=len(records),
        columns=list(df.columns),
        dtypes={c: str(t) for c, t in df.dtypes.items()},
        records=records,
    )


@mcp.tool()
def import_csv(
    csv_path: str,
    xlsx_path: str,
    sheet_name: str = "Sheet1",
    overwrite: bool = False,
    delimiter: str = ",",
    encoding: str = "utf-8",
) -> dict[str, Any]:
    """Nạp CSV vào một sheet của workbook .xlsx.

    Nếu file .xlsx chưa tồn tại sẽ tạo mới. overwrite=True để thay sheet trùng tên.
    """
    require_write()
    csv_abs = os.path.abspath(os.path.expanduser(csv_path))
    if not os.path.isfile(csv_abs):
        raise ExcelError(f"Không tìm thấy CSV: {csv_abs}")
    xlsx_abs = os.path.abspath(os.path.expanduser(xlsx_path))
    df = None
    enc_candidates = [encoding, "utf-8-sig", "utf-8", "cp949", "euc-kr", "cp1252", "latin1"]
    seen = set()
    ordered_encs = []
    for e in enc_candidates:
        if e and e.lower() not in seen:
            seen.add(e.lower())
            ordered_encs.append(e)

    last_err = None
    for enc in ordered_encs:
        try:
            df = pd.read_csv(csv_abs, delimiter=delimiter, encoding=enc)
            break
        except (UnicodeDecodeError, LookupError) as exc:
            last_err = exc
            continue

    if df is None:
        raise ExcelError(f"Không thể giải mã CSV với các encoding {ordered_encs}: {last_err}")

    if os.path.exists(xlsx_abs):
        mode, kwargs = "a", {"if_sheet_exists": "replace" if overwrite else "error"}
    else:
        mode, kwargs = "w", {}
    try:
        with pd.ExcelWriter(xlsx_abs, engine="openpyxl", mode=mode, **kwargs) as writer:
            df.to_excel(writer, sheet_name=sheet_name[:31], index=False)
    except ValueError as exc:
        raise ExcelError(
            f"Sheet '{sheet_name}' đã tồn tại (dùng overwrite=True): {exc}"
        ) from exc
    return _ok(path=xlsx_abs, sheet=sheet_name[:31], rows=len(df), columns=list(df.columns))


@mcp.tool()
def export_csv(
    xlsx_path: str,
    csv_path: str,
    sheet: str | None = None,
    delimiter: str = ",",
    encoding: str = "utf-8-sig",
) -> dict[str, Any]:
    """Xuất một sheet ra file CSV. Cần readwrite (tạo file trên đĩa).
    
    encoding: Mặc định 'utf-8-sig' có BOM để Microsoft Excel trên Windows tự nhận diện đúng tiếng Việt.
    """
    require_write()
    xlsx_abs = resolve_path(xlsx_path)
    df = pd.read_excel(xlsx_abs, sheet_name=sheet if sheet is not None else 0)
    csv_abs = os.path.abspath(os.path.expanduser(csv_path))
    os.makedirs(os.path.dirname(csv_abs) or ".", exist_ok=True)
    df.to_csv(csv_abs, index=False, sep=delimiter, encoding=encoding)
    return _ok(path=csv_abs, rows=len(df), columns=list(df.columns))


# ========================================================================== #
# 5. Điền từ template (giữ nguyên định dạng) + kho template
# ========================================================================== #
_TPL_EXTS = {".xlsx", ".xlsm"}


def _copy_cell_style(src: Any, dst: Any) -> None:
    """Sao chép toàn bộ thuộc tính định dạng từ ô src sang ô dst."""
    if hasattr(src, "font") and src.font:
        dst.font = _pycopy.copy(src.font)
    if hasattr(src, "fill") and src.fill:
        dst.fill = _pycopy.copy(src.fill)
    if hasattr(src, "border") and src.border:
        dst.border = _pycopy.copy(src.border)
    if hasattr(src, "alignment") and src.alignment:
        dst.alignment = _pycopy.copy(src.alignment)
    if hasattr(src, "number_format") and src.number_format:
        dst.number_format = src.number_format
    if hasattr(src, "protection") and src.protection:
        dst.protection = _pycopy.copy(src.protection)


@mcp.tool()
def copy_range_style(
    path: str,
    source_range: str,
    target_range: str,
    sheet: str | None = None,
    copy_row_height: bool = True,
    replicate_merged_cells: bool = True,
) -> dict[str, Any]:
    """Sao chép toàn bộ định dạng (font, viền kẻ border, màu nền fill, căn lề alignment,
    định dạng số number_format, khoá protection, chiều cao dòng, ô gộp merged cells) từ vùng mẫu sang vùng đích.

    Hỗ trợ nhân bản dòng: Nếu source_range là 1 ô (vd "A1") hoặc 1 dòng (vd "A5:G5"),
    và target_range gồm nhiều dòng (vd "A6:G30"), từng cột tương ứng sẽ được sao chép
    định dạng cho toàn bộ các dòng đích. Cần readwrite.
    """
    require_write()
    wb = load_workbook(path)
    ws = get_sheet(wb, sheet)

    src_matrix = _normalize_range(ws[source_range])
    tgt_matrix = _normalize_range(ws[target_range])

    src_rows = len(src_matrix)
    src_cols = len(src_matrix[0]) if src_rows > 0 else 0

    if src_rows == 0 or src_cols == 0:
        raise ExcelError("source_range rỗng")

    src_min_r = min(row[0].row for row in src_matrix)
    src_max_r = max(row[-1].row for row in src_matrix)
    src_min_c = min(row[0].column for row in src_matrix)
    src_max_c = max(row[-1].column for row in src_matrix)

    # Tìm các vùng merge nằm hoàn toàn trong source_range
    internal_merges = []
    if replicate_merged_cells:
        for rng in list(ws.merged_cells.ranges):
            if (
                src_min_r <= rng.min_row <= rng.max_row <= src_max_r
                and src_min_c <= rng.min_col <= rng.max_col <= src_max_c
            ):
                internal_merges.append(rng)

    for r_idx, tgt_row in enumerate(tgt_matrix):
        src_row = src_matrix[r_idx % src_rows]
        for c_idx, tgt_cell in enumerate(tgt_row):
            src_cell = src_row[c_idx % len(src_row)]
            _copy_cell_style(src_cell, tgt_cell)

        tgt_r_num = tgt_row[0].row
        src_r_num = src_row[0].row
        if copy_row_height:
            if src_r_num in ws.row_dimensions and ws.row_dimensions[src_r_num].height is not None:
                ws.row_dimensions[tgt_r_num].height = ws.row_dimensions[src_r_num].height

        if replicate_merged_cells and internal_merges:
            existing_merges = {(r.min_row, r.min_col, r.max_row, r.max_col) for r in ws.merged_cells.ranges}
            for rng in internal_merges:
                if src_rows == 1:
                    new_min_r, new_max_r = tgt_r_num, tgt_r_num
                else:
                    dr = tgt_r_num - src_r_num
                    new_min_r, new_max_r = rng.min_row + dr, rng.max_row + dr
                if (new_min_r, rng.min_col, new_max_r, rng.max_col) not in existing_merges:
                    ws.merge_cells(
                        start_row=new_min_r,
                        start_column=rng.min_col,
                        end_row=new_max_r,
                        end_column=rng.max_col,
                    )
                    existing_merges.add((new_min_r, rng.min_col, new_max_r, rng.max_col))

    save_workbook(wb, path)
    return _ok(
        sheet=ws.title,
        source_range=source_range,
        target_range=target_range,
        cells_affected=sum(len(r) for r in tgt_matrix),
    )


def _fill_xlsx(
    src: str,
    output: str,
    cells: dict[str, Any] | None = None,
    table_data: list[list[Any]] | None = None,
    start_cell: str | None = None,
    sheet: str | None = None,
    overwrite: bool = False,
    copy_table_style: bool = True,
    replicate_merged_cells: bool = True,
) -> dict[str, Any]:
    dst = resolve_path(output, must_exist=False)
    if os.path.exists(dst) and not overwrite:
        raise ExcelError(f"File đích đã tồn tại (overwrite=False): {dst}")
    os.makedirs(os.path.dirname(dst) or ".", exist_ok=True)
    shutil.copyfile(src, dst)  # nhân bản y hệt template (mọi định dạng)
    wb = load_workbook(dst)
    filled_cells = 0
    filled_rows = 0

    # 1. Điền các ô cố định (nếu có)
    if cells:
        for ref, value in cells.items():
            if "!" in ref:
                sh_name, coord = ref.split("!", 1)
                ws = get_sheet(wb, sh_name)
            else:
                ws = get_sheet(wb, sheet)
                coord = ref
            ws[coord] = value
            filled_cells += 1

    # 2. Điền bảng dữ liệu co giãn (nếu có)
    if table_data:
        t_sheet = sheet
        s_cell = start_cell or "A2"
        if "!" in s_cell:
            t_sheet, s_cell = s_cell.split("!", 1)
        ws = get_sheet(wb, t_sheet)
        r0, c0 = parse_start_cell(s_cell)

        num_cols = max(len(r) for r in table_data) if table_data else 0
        sample_cells = [ws.cell(row=r0, column=c0 + j) for j in range(num_cols)]
        sample_height = ws.row_dimensions[r0].height if r0 in ws.row_dimensions else None

        # Tìm các ô merge nằm trong dòng mẫu r0
        sample_merges = []
        if replicate_merged_cells:
            for rng in list(ws.merged_cells.ranges):
                if rng.min_row == r0 and rng.max_row == r0:
                    if c0 <= rng.min_col and rng.max_col <= (c0 + num_cols - 1):
                        sample_merges.append((rng.min_col, rng.max_col))

        for i, row_vals in enumerate(table_data):
            curr_row = r0 + i
            if copy_table_style and sample_height is not None:
                ws.row_dimensions[curr_row].height = sample_height

            for j, val in enumerate(row_vals):
                target_cell = ws.cell(row=curr_row, column=c0 + j)
                if not isinstance(target_cell, openpyxl.cell.cell.MergedCell):
                    if val is not None:
                        target_cell.value = val

                # Dòng đầu tiên (i=0) giữ style sẵn có; các dòng tiếp theo (i>0) sao chép style từ dòng mẫu
                if i > 0 and copy_table_style and j < len(sample_cells):
                    _copy_cell_style(sample_cells[j], target_cell)

            # Tự động nhân bản các vùng merged cells cho dòng mới
            if i > 0 and replicate_merged_cells and sample_merges:
                existing_merges = {(r.min_row, r.min_col, r.max_row, r.max_col) for r in ws.merged_cells.ranges}
                for min_c, max_c in sample_merges:
                    if (curr_row, min_c, curr_row, max_c) not in existing_merges:
                        ws.merge_cells(
                            start_row=curr_row,
                            start_column=min_c,
                            end_row=curr_row,
                            end_column=max_c,
                        )
                        existing_merges.add((curr_row, min_c, curr_row, max_c))

            filled_rows += 1

    save_workbook(wb, dst)
    return _ok(
        template=src,
        output=dst,
        cells_filled=filled_cells,
        table_rows_filled=filled_rows,
    )


@mcp.tool()
def fill_template(
    template: str,
    output: str,
    cells: dict[str, Any] | None = None,
    table_data: list[list[Any]] | None = None,
    start_cell: str | None = None,
    sheet: str | None = None,
    overwrite: bool = False,
    copy_table_style: bool = True,
    replicate_merged_cells: bool = True,
) -> dict[str, Any]:
    """Tạo file mới từ template .xlsx (theo đường dẫn) rồi điền các ô — GIỮ NGUYÊN định dạng 100%.

    - cells: map ô cố định -> giá trị, ô có thể kèm sheet: {"B2": 10, "Sheet2!A1": "x"}.
    - table_data: danh sách 2 chiều các dòng cần điền vào bảng động.
    - start_cell: ô bắt đầu điền bảng (mặc định A2 hoặc dòng mẫu của template).
    - copy_table_style=True: tự động sao chép 100% font, màu nền, viền kẻ, căn lề, định dạng số,
      chiều cao dòng từ dòng mẫu start_cell cho toàn bộ các dòng mới trong table_data.
    - replicate_merged_cells=True: tự động nhân bản các khối ô gộp (merged cells) của dòng mẫu
      (vd: cột Tên Hàng Hóa merge B:C) cho toàn bộ các dòng mới.
    Cần readwrite. Lưu ý: chart/ảnh phức tạp trong template có thể không giữ được qua openpyxl.
    """
    require_write()
    src = resolve_path(template, must_exist=True)
    return _fill_xlsx(
        src,
        output,
        cells=cells,
        table_data=table_data,
        start_cell=start_cell,
        sheet=sheet,
        overwrite=overwrite,
        copy_table_style=copy_table_style,
        replicate_merged_cells=replicate_merged_cells,
    )


@mcp.tool()
def save_template(name: str, path: str, note: str = "", overwrite: bool = False) -> dict[str, Any]:
    """Lưu một file .xlsx làm template vào kho theo `name` (dùng lại sau bằng fill_from_template)."""
    require_write()
    src = resolve_path(path, must_exist=True)
    return _ok(**templates.save_template("excel", name, src, _TPL_EXTS, note, overwrite))


@mcp.tool()
def list_templates() -> dict[str, Any]:
    """Liệt kê các template Excel đã lưu trong kho."""
    items = templates.list_templates("excel")
    return _ok(count=len(items), templates=items)


@mcp.tool()
def fill_from_template(
    name: str,
    output: str,
    cells: dict[str, Any] | None = None,
    table_data: list[list[Any]] | None = None,
    start_cell: str | None = None,
    sheet: str | None = None,
    overwrite: bool = False,
    copy_table_style: bool = True,
    replicate_merged_cells: bool = True,
) -> dict[str, Any]:
    """Điền dữ liệu từ template đã lưu (gọi theo TÊN) — giữ nguyên định dạng 100%. Cần readwrite."""
    require_write()
    src = templates.template_path("excel", name)
    res = _fill_xlsx(
        src,
        output,
        cells=cells,
        table_data=table_data,
        start_cell=start_cell,
        sheet=sheet,
        overwrite=overwrite,
        copy_table_style=copy_table_style,
        replicate_merged_cells=replicate_merged_cells,
    )
    res["from_template"] = name
    return res


@mcp.tool()
def delete_template(name: str) -> dict[str, Any]:
    """Xoá một template Excel khỏi kho. Cần readwrite."""
    require_write()
    return _ok(**templates.delete_template("excel", name))


# ========================================================================== #
# 5. Ảnh nhúng (cho AI vision đọc/hiểu nội dung ảnh)
# ========================================================================== #
@mcp.tool()
def list_images(path: str, sheet: str | None = None) -> dict[str, Any]:
    """Liệt kê ảnh nhúng trong workbook (chỉ metadata, không kèm dữ liệu ảnh).

    Trả về vị trí (sheet, ô neo), tên file, định dạng, kích thước từng ảnh — để
    biết có ảnh nào trước khi gọi read_images. sheet=None -> mọi sheet.
    """
    items = [
        {
            "index": i,
            "sheet": im["sheet"],
            "cell": im["cell"],
            "filename": im["filename"],
            "mime": im["mime"],
            "bytes": im["bytes"],
            "width": im["width"],
            "height": im["height"],
            "vision_supported": im["mime"] in VISION_OK_MIME,
        }
        for i, im in enumerate(iter_workbook_images(path))
        if sheet is None or im["sheet"] == sheet
    ]
    return _ok(count=len(items), images=items)


@mcp.tool()
def read_images(
    path: str,
    sheet: str | None = None,
    index: int | None = None,
    max_images: int = 20,
) -> CallToolResult:
    """Trả về ảnh nhúng dưới dạng image content để AI/model vision xem nội dung.

    index=None -> mọi ảnh (lọc theo sheet nếu có), giới hạn max_images.
    index=N -> chỉ ảnh thứ N theo thứ tự của list_images.
    Mỗi ảnh kèm một dòng chú thích (sheet, ô neo, tên file, kích thước). Ảnh
    định dạng vector (emf/wmf) không hiển thị được sẽ chỉ báo metadata.
    """
    all_images = list(iter_workbook_images(path))
    selected = [
        (i, im)
        for i, im in enumerate(all_images)
        if (sheet is None or im["sheet"] == sheet) and (index is None or i == index)
    ]
    if not selected:
        raise ExcelError(
            "Không tìm thấy ảnh phù hợp. Dùng list_images để xem ảnh có sẵn."
        )

    items = []
    for i, im in selected:
        loc = f"sheet '{im['sheet']}'" if im["sheet"] else "không rõ sheet"
        if im["cell"]:
            loc += f", ô {im['cell']}"
        dims = (
            f"{im['width']}x{im['height']}px"
            if im["width"] and im["height"]
            else f"{im['bytes']} bytes"
        )
        items.append(
            {
                "caption": f"[#{i}] {im['filename']} — {loc} — {dims} ({im['mime']})",
                "mime": im["mime"],
                "data": im["data"],
            }
        )
    return image_blocks(items, max_images=max_images)


def main() -> None:
    """Điểm khởi động: chạy MCP server qua stdio."""
    mcp.run()


if __name__ == "__main__":
    main()
