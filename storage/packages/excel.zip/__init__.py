"""MCP server thao tác Excel bằng openpyxl + pandas."""

from .server import main, mcp

__all__ = ["main", "mcp"]
__version__ = "0.1.0"
