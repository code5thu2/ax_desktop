"""Guard chế độ truy cập readonly/readwrite dùng chung.

Mỗi MCP tạo bộ hàm guard riêng theo tên biến môi trường của nó:
    access_mode, is_readonly, require_write = make_access("EXCEL_ACCESS_MODE")
"""

from __future__ import annotations

import os
from typing import Callable

from .errors import McpError


def make_access(
    env_var: str, default: str = "readonly"
) -> tuple[Callable[[], str], Callable[[], bool], Callable[[], None]]:
    """Trả về (access_mode, is_readonly, require_write) cho một biến môi trường."""

    def access_mode() -> str:
        mode = os.environ.get(env_var, default).lower()
        if mode not in ("readonly", "readwrite"):
            raise McpError(f"{env_var} phải là 'readonly' hoặc 'readwrite'")
        return mode

    def is_readonly() -> bool:
        return access_mode() == "readonly"

    def require_write() -> None:
        if is_readonly():
            raise McpError(
                f"Server đang ở chế độ readonly. Đặt {env_var}=readwrite để cho phép thay đổi."
            )

    return access_mode, is_readonly, require_write
