"""Lỗi nghiệp vụ chung cho mọi MCP."""

from __future__ import annotations


class McpError(Exception):
    """Lỗi nghiệp vụ — được convert thành thông báo rõ ràng cho client.

    Mỗi MCP nên đặt alias riêng cho dễ đọc, ví dụ:
        from common import McpError
        ExcelError = McpError
    """
