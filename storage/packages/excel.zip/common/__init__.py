"""Tiện ích dùng chung cho mọi MCP trong dự án (giảm trùng lặp, sửa 1 nơi).

Import gọn:
    from common import McpError, make_access, ok, jsonify, resolve_path
    from common import IMAGE_MIME, VISION_OK_MIME, sniff_size, image_blocks
"""

from . import templates
from .access import make_access
from .errors import McpError
from .format import human_size
from .images import IMAGE_MIME, VISION_OK_MIME, image_blocks, sniff_size
from .jsonify import jsonify
from .lazy import LazyModule
from .paths import resolve_path
from .result import ok

__all__ = [
    "McpError",
    "make_access",
    "ok",
    "jsonify",
    "resolve_path",
    "human_size",
    "IMAGE_MIME",
    "VISION_OK_MIME",
    "sniff_size",
    "image_blocks",
    "templates",
    "LazyModule",
]
