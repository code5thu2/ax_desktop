"""Chuyển giá trị bất kỳ về kiểu JSON-serializable (dùng cho DB, cell...)."""

from __future__ import annotations

import datetime as _dt
import decimal
import ipaddress
import math
import uuid
from typing import Any


def jsonify(value: Any) -> Any:
    """Chuẩn hoá value về kiểu JSON được. Bao trùm kiểu của Postgres/Excel/Pandas/Numpy."""
    if value is None:
        return None
    # Xử lý NaN / NaT / Infinity
    if isinstance(value, float):
        if math.isnan(value):
            return None
        if math.isinf(value):
            return "Infinity" if value > 0 else "-Infinity"
        return value
    if isinstance(value, (bool, str)):
        return value
    if isinstance(value, int):
        # Ép np.int64 / np.int32 thành int nguyên bản
        return int(value)
    if isinstance(value, decimal.Decimal):
        return float(value)
    if hasattr(value, "isoformat") and callable(value.isoformat):
        # datetime, date, time, pd.Timestamp
        try:
            return value.isoformat()
        except Exception:
            return str(value)
    if isinstance(value, _dt.timedelta):
        return value.total_seconds()
    if isinstance(value, uuid.UUID):
        return str(value)
    if isinstance(value, (bytes, bytearray, memoryview)):
        return bytes(value).hex()
    if isinstance(value, (ipaddress.IPv4Address, ipaddress.IPv6Address)):
        return str(value)
    if hasattr(value, "item") and callable(value.item) and getattr(value, "ndim", 0) == 0:
        try:
            return jsonify(value.item())
        except Exception:
            pass
    if hasattr(value, "tolist") and callable(value.tolist):
        # np.ndarray, pd.Series
        try:
            res = value.tolist()
            if isinstance(res, list):
                return [jsonify(v) for v in res]
            return jsonify(res)
        except Exception:
            pass
    if isinstance(value, (list, tuple, set)):
        return [jsonify(v) for v in value]
    if isinstance(value, dict):
        return {str(k): jsonify(v) for k, v in value.items()}
    s = str(value)
    if s in ("<NA>", "NaT", "nan"):
        return None
    return s
