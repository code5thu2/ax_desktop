"""Tiện ích ảnh nhúng: MIME, đoán kích thước, dựng image content cho vision."""

from __future__ import annotations

import struct
from typing import Any

from mcp.server.mcpserver.utilities.types import Image
from mcp.types import CallToolResult, TextContent

IMAGE_MIME = {
    ".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg",
    ".gif": "image/gif", ".webp": "image/webp", ".bmp": "image/bmp",
    ".tif": "image/tiff", ".tiff": "image/tiff", ".emf": "image/emf", ".wmf": "image/wmf",
}
# Định dạng raster mà model vision "nhìn" được.
VISION_OK_MIME = {"image/png", "image/jpeg", "image/gif", "image/webp"}


def sniff_size(data: bytes) -> tuple[int | None, int | None]:
    """Đoán (width, height) cho PNG/GIF/JPEG mà không cần Pillow."""
    try:
        if data[:8] == b"\x89PNG\r\n\x1a\n":
            return struct.unpack(">II", data[16:24])
        if data[:6] in (b"GIF87a", b"GIF89a"):
            return struct.unpack("<HH", data[6:10])
        if data[:2] == b"\xff\xd8":  # JPEG: quét marker SOF
            i = 2
            while i + 9 < len(data):
                if data[i] != 0xFF:
                    i += 1
                    continue
                marker = data[i + 1]
                if 0xC0 <= marker <= 0xCF and marker not in (0xC4, 0xC8, 0xCC):
                    h, w = struct.unpack(">HH", data[i + 5 : i + 9])
                    return w, h
                i += 2 + struct.unpack(">H", data[i + 2 : i + 4])[0]
    except Exception:  # noqa: BLE001
        pass
    return None, None


def image_blocks(items: list[dict[str, Any]], max_images: int = 20) -> CallToolResult:
    """Dựng CallToolResult từ danh sách ảnh.

    Mỗi item: {"caption": str, "mime": str, "data": bytes}. Ảnh vision-OK được
    trả kèm image content (giới hạn max_images); còn lại chỉ trả chú thích text.
    """
    blocks: list[Any] = []
    shown = 0
    for it in items:
        cap = it["caption"]
        if it["mime"] in VISION_OK_MIME and shown < max_images:
            blocks.append(TextContent(type="text", text=cap))
            blocks.append(
                Image(data=it["data"], format=it["mime"].split("/")[-1]).to_image_content()
            )
            shown += 1
        else:
            note = (
                " — định dạng không hiển thị được"
                if it["mime"] not in VISION_OK_MIME
                else " — vượt max_images"
            )
            blocks.append(TextContent(type="text", text=cap + note))
    return CallToolResult(content=blocks)
