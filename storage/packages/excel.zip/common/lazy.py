"""Tiện ích LazyModule: Nạp thư viện lười (chỉ nạp khi hàm thực sự sử dụng)."""

from __future__ import annotations

import importlib
import types
from typing import Any


class LazyModule(types.ModuleType):
    """Proxy cho một module Python, chỉ import thực sự khi có truy cập thuộc tính."""

    def __init__(self, module_name: str) -> None:
        super().__init__(module_name)
        self._module_name = module_name
        self._actual_module: Any = None

    def _get_module(self) -> Any:
        if self._actual_module is None:
            self._actual_module = importlib.import_module(self._module_name)
        return self._actual_module

    def __getattr__(self, name: str) -> Any:
        return getattr(self._get_module(), name)

    def __repr__(self) -> str:
        if self._actual_module is None:
            return f"<LazyModule '{self._module_name}' (not loaded)>"
        return repr(self._actual_module)

    def __dir__(self) -> list[str]:
        return dir(self._get_module())
