"""Chuẩn hoá & kiểm tra đường dẫn file."""

from __future__ import annotations

import os
from collections.abc import Iterable

from .errors import McpError


def resolve_path(
    path: str, exts: Iterable[str] | None = None, must_exist: bool = True
) -> str:
    """Chuẩn hoá path tuyệt đối; kiểm tra tồn tại và (tuỳ chọn) đúng phần mở rộng.

    exts: tập phần mở rộng cho phép (đã kèm dấu chấm, chữ thường), vd {".docx"}.
    """
    if not path or not str(path).strip():
        raise McpError("Thiếu đường dẫn.")
    abspath = os.path.realpath(os.path.abspath(os.path.expanduser(path)))
    if must_exist and not os.path.isfile(abspath):
        raise McpError(f"Không tìm thấy file: {abspath}")
    if exts is not None:
        ext = os.path.splitext(abspath)[1].lower()
        if ext not in set(exts):
            raise McpError(
                f"Định dạng không hỗ trợ: '{ext}'. Chấp nhận: {sorted(exts)}"
            )
    return abspath
