"""Chuẩn hoá kết quả trả về của tool."""

from __future__ import annotations

from typing import Any


def ok(**extra: Any) -> dict[str, Any]:
    """Kết quả thành công: {"ok": True, ...}."""
    return {"ok": True, **extra}
