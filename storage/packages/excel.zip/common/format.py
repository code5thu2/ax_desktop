"""Định dạng hiển thị dùng chung."""

from __future__ import annotations


def human_size(num: int) -> str:
    """Đổi số byte sang chuỗi dễ đọc: 1536 -> '1.5 KB'."""
    size = float(num)
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if size < 1024 or unit == "TB":
            return f"{size:.0f} {unit}" if unit == "B" else f"{size:.1f} {unit}"
        size /= 1024
    return f"{size:.1f} TB"
