"""Kho template dùng chung: lưu file mẫu theo tên, gọi lại sau (bền qua restart).

Lưu trên đĩa tại  MCP_TEMPLATE_DIR/<category>/  (mặc định ~/.mcp-templates/<category>),
kèm index.json ánh xạ tên -> file. category ví dụ: "excel", "docs".
"""

from __future__ import annotations

import datetime as _dt
import json
import os
import re
import shutil

from .errors import McpError

_NAME_RE = re.compile(r"^[A-Za-z0-9_.\- ]{1,64}$")


def _base_dir() -> str:
    return os.environ.get("MCP_TEMPLATE_DIR") or os.path.join(
        os.path.expanduser("~"), ".mcp-templates"
    )


def _store_dir(category: str) -> str:
    d = os.path.join(_base_dir(), category)
    os.makedirs(d, exist_ok=True)
    return d


def _index_path(category: str) -> str:
    return os.path.join(_store_dir(category), "index.json")


def _load_index(category: str) -> dict:
    p = _index_path(category)
    if os.path.isfile(p):
        try:
            with open(p, encoding="utf-8") as fh:
                return json.load(fh)
        except Exception:  # noqa: BLE001
            return {}
    return {}


def _write_index(category: str, idx: dict) -> None:
    with open(_index_path(category), "w", encoding="utf-8") as fh:
        json.dump(idx, fh, indent=2, ensure_ascii=False)


def _check_name(name: str) -> str:
    name = (name or "").strip()
    if not _NAME_RE.match(name):
        raise McpError("Tên template chỉ gồm chữ/số/_-. và khoảng trắng, tối đa 64 ký tự.")
    return name


def save_template(
    category: str, name: str, src_path: str, exts: set[str],
    note: str = "", overwrite: bool = False,
) -> dict:
    """Copy file mẫu vào kho dưới tên `name`. exts: định dạng cho phép."""
    name = _check_name(name)
    if not os.path.isfile(src_path):
        raise McpError(f"Không tìm thấy file template: {src_path}")
    ext = os.path.splitext(src_path)[1].lower()
    if ext not in exts:
        raise McpError(f"Định dạng template phải thuộc {sorted(exts)} (nhận '{ext}').")
    idx = _load_index(category)
    if name in idx and not overwrite:
        raise McpError(f"Template '{name}' đã tồn tại (overwrite=False).")
    safe = re.sub(r"[^A-Za-z0-9_.-]", "_", name) + ext
    dst = os.path.join(_store_dir(category), safe)
    shutil.copyfile(src_path, dst)
    idx[name] = {
        "file": safe, "ext": ext, "note": note,
        "saved": _dt.datetime.now().isoformat(timespec="seconds"),
    }
    _write_index(category, idx)
    return {"name": name, "stored": dst, "note": note}


def template_path(category: str, name: str) -> str:
    """Trả đường dẫn file template đã lưu (raise nếu không có)."""
    name = _check_name(name)
    idx = _load_index(category)
    if name not in idx:
        raise McpError(f"Không có template '{name}'. Dùng list_templates để xem.")
    p = os.path.join(_store_dir(category), idx[name]["file"])
    if not os.path.isfile(p):
        raise McpError(f"File template của '{name}' bị thiếu trong kho: {p}")
    return p


def list_templates(category: str) -> list[dict]:
    idx = _load_index(category)
    return [
        {"name": n, "ext": m.get("ext"), "note": m.get("note", ""), "saved": m.get("saved")}
        for n, m in sorted(idx.items())
    ]


def delete_template(category: str, name: str) -> dict:
    name = _check_name(name)
    idx = _load_index(category)
    if name not in idx:
        raise McpError(f"Không có template '{name}'.")
    f = os.path.join(_store_dir(category), idx[name]["file"])
    idx.pop(name)
    _write_index(category, idx)
    try:
        if os.path.isfile(f):
            os.remove(f)
    except OSError:
        pass
    return {"name": name, "deleted": True}
