"""MCP server cho PostgreSQL.

Tham khảo thiết kế của các MCP nổi tiếng:
  - @modelcontextprotocol/server-postgres (read-only, điều hướng schema)
  - crystaldba/postgres-mcp "Postgres MCP Pro" (access-mode, explain, top queries, health)

Chạy: python -m postgres_mcp   (transport stdio)
Cấu hình: DATABASE_URL (bắt buộc), PG_ACCESS_MODE=readonly|readwrite
"""

from __future__ import annotations

from typing import Any, Literal

from mcp.server import MCPServer
from common import ok as _ok

from .db import (
    DBError,
    access_mode,
    run_query,
    run_statement,
)

mcp = MCPServer(
    "postgres",
    instructions=(
        "Truy vấn và khảo sát cơ sở dữ liệu PostgreSQL. Mặc định chạy ở chế độ "
        "read-only (mọi truy vấn nằm trong transaction READ ONLY). Dùng "
        "list_schemas / list_objects / describe_object để tìm hiểu cấu trúc "
        "trước khi viết SQL."
    ),
)


# ========================================================================== #
# Thông tin & điều hướng schema
# ========================================================================== #
@mcp.tool()
def server_info() -> dict[str, Any]:
    """Xem phiên bản Postgres, database/user hiện tại và chế độ truy cập."""
    res = run_query(
        "SELECT version() AS version, current_database() AS database, "
        "current_user AS user, current_setting('server_version') AS server_version"
    )
    info = res["rows"][0]
    info["access_mode"] = access_mode()
    return _ok(**info)


@mcp.tool()
def list_schemas() -> dict[str, Any]:
    """Liệt kê các schema do người dùng tạo (bỏ qua schema hệ thống)."""
    res = run_query(
        """
        SELECT schema_name,
               schema_owner
        FROM information_schema.schemata
        WHERE schema_name NOT IN ('pg_catalog', 'information_schema')
          AND schema_name NOT LIKE 'pg_temp%'
          AND schema_name NOT LIKE 'pg_toast%'
        ORDER BY schema_name
        """
    )
    return _ok(schemas=res["rows"])


@mcp.tool()
def list_objects(
    schema: str = "public",
    object_type: Literal["table", "view", "materialized_view", "sequence"] = "table",
) -> dict[str, Any]:
    """Liệt kê các đối tượng trong một schema theo loại (bảng/view/...)."""
    if object_type in ("table", "view"):
        kind = "BASE TABLE" if object_type == "table" else "VIEW"
        res = run_query(
            """
            SELECT table_name AS name, table_type AS type
            FROM information_schema.tables
            WHERE table_schema = %s AND table_type = %s
            ORDER BY table_name
            """,
            [schema, kind],
        )
    elif object_type == "materialized_view":
        res = run_query(
            "SELECT matviewname AS name, 'MATERIALIZED VIEW' AS type "
            "FROM pg_matviews WHERE schemaname = %s ORDER BY matviewname",
            [schema],
        )
    else:  # sequence
        res = run_query(
            """
            SELECT sequence_name AS name, 'SEQUENCE' AS type
            FROM information_schema.sequences
            WHERE sequence_schema = %s ORDER BY sequence_name
            """,
            [schema],
        )
    return _ok(schema=schema, object_type=object_type, objects=res["rows"])


@mcp.tool()
def describe_object(table: str, schema: str = "public") -> dict[str, Any]:
    """Mô tả chi tiết một bảng/view: cột, kiểu, khoá chính, khoá ngoại, index."""
    columns = run_query(
        """
        SELECT column_name, data_type, is_nullable,
               column_default, character_maximum_length
        FROM information_schema.columns
        WHERE table_schema = %s AND table_name = %s
        ORDER BY ordinal_position
        """,
        [schema, table],
    )["rows"]
    if not columns:
        raise DBError(f"Không tìm thấy bảng/view '{schema}.{table}'")

    primary_key = run_query(
        """
        SELECT a.attname AS column
        FROM pg_index i
        JOIN pg_attribute a ON a.attrelid = i.indrelid AND a.attnum = ANY(i.indkey)
        WHERE i.indrelid = %s::regclass AND i.indisprimary
        """,
        [f"{schema}.{table}"],
    )["rows"]

    foreign_keys = run_query(
        """
        SELECT
            kcu.column_name AS column,
            ccu.table_schema AS ref_schema,
            ccu.table_name AS ref_table,
            ccu.column_name AS ref_column
        FROM information_schema.table_constraints tc
        JOIN information_schema.key_column_usage kcu
          ON tc.constraint_name = kcu.constraint_name
         AND tc.table_schema = kcu.table_schema
        JOIN information_schema.constraint_column_usage ccu
          ON ccu.constraint_name = tc.constraint_name
        WHERE tc.constraint_type = 'FOREIGN KEY'
          AND tc.table_schema = %s AND tc.table_name = %s
        """,
        [schema, table],
    )["rows"]

    indexes = run_query(
        "SELECT indexname AS name, indexdef AS definition "
        "FROM pg_indexes WHERE schemaname = %s AND tablename = %s ORDER BY indexname",
        [schema, table],
    )["rows"]

    return _ok(
        schema=schema,
        table=table,
        columns=columns,
        primary_key=[r["column"] for r in primary_key],
        foreign_keys=foreign_keys,
        indexes=indexes,
    )


@mcp.tool()
def list_indexes(table: str, schema: str = "public") -> dict[str, Any]:
    """Liệt kê index của một bảng (tên + định nghĩa)."""
    res = run_query(
        "SELECT indexname AS name, indexdef AS definition "
        "FROM pg_indexes WHERE schemaname = %s AND tablename = %s ORDER BY indexname",
        [schema, table],
    )
    return _ok(schema=schema, table=table, indexes=res["rows"])


# ========================================================================== #
# Truy vấn & thực thi
# ========================================================================== #
@mcp.tool()
def execute_query(
    sql: str, params: list[Any] | None = None, max_rows: int = 100
) -> dict[str, Any]:
    """Chạy một câu SELECT (chỉ đọc) và trả về các dòng kết quả.

    Dùng placeholder %s cho tham số, truyền giá trị qua `params` để tránh SQL
    injection, ví dụ sql="SELECT * FROM users WHERE id = %s", params=[42].
    max_rows giới hạn số dòng trả về (mặc định 100).
    """
    res = run_query(sql, params, max_rows=max_rows)
    return _ok(**res)


@mcp.tool()
def execute_statement(sql: str, params: list[Any] | None = None) -> dict[str, Any]:
    """Chạy câu lệnh ghi (INSERT/UPDATE/DELETE/DDL).

    Chỉ hoạt động khi PG_ACCESS_MODE=readwrite; nếu readonly sẽ báo lỗi.
    """
    res = run_statement(sql, params)
    return _ok(**res)


@mcp.tool()
def explain_query(
    sql: str,
    analyze: bool = False,
    query_format: Literal["text", "json"] = "text",
) -> dict[str, Any]:
    """Chạy EXPLAIN để xem kế hoạch thực thi.

    analyze=True sẽ thực sự chạy truy vấn (EXPLAIN ANALYZE) để đo thời gian thật;
    ở chế độ readonly, truy vấn có thao tác ghi sẽ bị Postgres từ chối.
    """
    opts = []
    if analyze:
        opts.append("ANALYZE")
    if query_format == "json":
        opts.append("FORMAT JSON")
    prefix = f"EXPLAIN ({', '.join(opts)}) " if opts else "EXPLAIN "
    res = run_query(prefix + sql)
    plan = [list(r.values())[0] for r in res["rows"]]
    return _ok(analyze=analyze, plan=plan)


# ========================================================================== #
# Phân tích hiệu năng & sức khoẻ (Postgres MCP Pro style)
# ========================================================================== #
@mcp.tool()
def get_top_queries(
    limit: int = 10, sort_by: Literal["total_time", "mean_time", "calls"] = "total_time"
) -> dict[str, Any]:
    """Top truy vấn tốn tài nguyên nhất (cần extension pg_stat_statements).

    Nếu extension chưa bật, tool trả về hướng dẫn cách kích hoạt.
    """
    check = run_query(
        "SELECT 1 FROM pg_extension WHERE extname = 'pg_stat_statements'"
    )
    if not check["rows"]:
        return _ok(
            available=False,
            hint=(
                "Chưa bật pg_stat_statements. Thêm 'pg_stat_statements' vào "
                "shared_preload_libraries trong postgresql.conf, khởi động lại "
                "Postgres, rồi chạy: CREATE EXTENSION pg_stat_statements;"
            ),
        )
    order = {
        "total_time": "total_exec_time",
        "mean_time": "mean_exec_time",
        "calls": "calls",
    }[sort_by]
    res = run_query(
        f"""
        SELECT queryid, calls,
               round(total_exec_time::numeric, 2) AS total_exec_time_ms,
               round(mean_exec_time::numeric, 2) AS mean_exec_time_ms,
               rows,
               query
        FROM pg_stat_statements
        ORDER BY {order} DESC
        LIMIT %s
        """,
        [limit],
    )
    return _ok(available=True, sort_by=sort_by, queries=res["rows"])


@mcp.tool()
def analyze_db_health() -> dict[str, Any]:
    """Kiểm tra sức khoẻ nhanh: kích thước DB, tỉ lệ cache hit, số kết nối,
    các bảng lớn nhất và index chưa được dùng."""
    size = run_query(
        "SELECT pg_size_pretty(pg_database_size(current_database())) AS db_size"
    )["rows"][0]

    cache = run_query(
        """
        SELECT round(
            sum(heap_blks_hit) / nullif(sum(heap_blks_hit) + sum(heap_blks_read), 0)
            * 100, 2) AS cache_hit_ratio_pct
        FROM pg_statio_user_tables
        """
    )["rows"][0]

    conns = run_query(
        """
        SELECT count(*) AS total,
               count(*) FILTER (WHERE state = 'active') AS active,
               count(*) FILTER (WHERE state = 'idle') AS idle
        FROM pg_stat_activity
        WHERE datname = current_database()
        """
    )["rows"][0]

    largest = run_query(
        """
        SELECT schemaname AS schema, relname AS table,
               pg_size_pretty(pg_total_relation_size(relid)) AS total_size
        FROM pg_catalog.pg_statio_user_tables
        ORDER BY pg_total_relation_size(relid) DESC
        LIMIT 5
        """
    )["rows"]

    unused_idx = run_query(
        """
        SELECT schemaname AS schema, relname AS table, indexrelname AS index
        FROM pg_stat_user_indexes
        WHERE idx_scan = 0
        ORDER BY schemaname, relname
        LIMIT 20
        """
    )["rows"]

    return _ok(
        db_size=size["db_size"],
        cache_hit_ratio_pct=cache["cache_hit_ratio_pct"],
        connections=conns,
        largest_tables=largest,
        unused_indexes=unused_idx,
    )


def main() -> None:
    """Điểm khởi động: chạy MCP server qua stdio."""
    mcp.run()


if __name__ == "__main__":
    main()
