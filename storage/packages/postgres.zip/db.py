"""Quản lý kết nối PostgreSQL, cấu hình và cơ chế bảo vệ read-only.

Cấu hình qua biến môi trường:
    DATABASE_URL     chuỗi kết nối, ví dụ postgresql://user:pass@host:5432/db  (bắt buộc)
    PG_ACCESS_MODE   "readonly" (mặc định) hoặc "readwrite"
"""

from __future__ import annotations

import os
from typing import Any

from psycopg.rows import dict_row
from psycopg_pool import ConnectionPool

from common import McpError, jsonify, make_access

DBError = McpError  # alias cho dễ đọc

_pool: ConnectionPool | None = None

access_mode, is_readonly, _ = make_access("PG_ACCESS_MODE")


def get_pool() -> ConnectionPool:
    """Khởi tạo (lazy) và trả về connection pool dùng chung."""
    global _pool
    if _pool is None:
        url = os.environ.get("DATABASE_URL")
        if not url:
            raise DBError(
                "Chưa đặt DATABASE_URL. Ví dụ: "
                "postgresql://user:pass@localhost:5432/dbname"
            )
        try:
            _pool = ConnectionPool(
                conninfo=url,
                min_size=1,
                max_size=int(os.environ.get("PG_POOL_MAX", "5")),
                open=True,
                timeout=10,
                kwargs={"application_name": "postgres-mcp"},
            )
        except Exception as exc:  # noqa: BLE001
            raise DBError(f"Không tạo được connection pool: {exc}") from exc
    return _pool


def close_pool() -> None:
    global _pool
    if _pool is not None:
        _pool.close()
        _pool = None


# --------------------------------------------------------------------------- #
# JSON hoá giá trị trả về
# --------------------------------------------------------------------------- #
def jsonify_rows(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    return [{k: jsonify(v) for k, v in row.items()} for row in rows]


# --------------------------------------------------------------------------- #
# Thực thi SQL
# --------------------------------------------------------------------------- #
def run_query(
    sql: str, params: list[Any] | None = None, max_rows: int | None = None
) -> dict[str, Any]:
    """Chạy SELECT (hoặc câu lệnh trả rows).

    Ở chế độ readonly, câu lệnh chạy trong transaction READ ONLY nên Postgres
    tự chặn mọi thao tác ghi ở mức database — bảo vệ chắc chắn nhất.
    """
    pool = get_pool()
    readonly = is_readonly()
    with pool.connection() as conn:
        with conn.transaction():
            if readonly:
                conn.execute("SET TRANSACTION READ ONLY")
            with conn.cursor(row_factory=dict_row) as cur:
                try:
                    cur.execute(sql, params)
                except Exception as exc:  # noqa: BLE001
                    raise DBError(f"Lỗi SQL: {exc}") from exc
                if cur.description is None:
                    return {"rows": [], "row_count": cur.rowcount, "columns": []}
                columns = [d.name for d in cur.description]
                rows = cur.fetchmany(max_rows) if max_rows else cur.fetchall()
                truncated = bool(max_rows and cur.rowcount > max_rows)
                return {
                    "columns": columns,
                    "rows": jsonify_rows(rows),
                    "row_count": len(rows),
                    "truncated": truncated,
                }


def run_statement(sql: str, params: list[Any] | None = None) -> dict[str, Any]:
    """Chạy câu lệnh ghi (INSERT/UPDATE/DELETE/DDL). Chỉ dùng ở chế độ readwrite."""
    if is_readonly():
        raise DBError(
            "Server đang ở chế độ readonly. Đặt PG_ACCESS_MODE=readwrite để cho phép ghi."
        )
    pool = get_pool()
    with pool.connection() as conn:
        with conn.transaction():
            with conn.cursor() as cur:
                try:
                    cur.execute(sql, params)
                except Exception as exc:  # noqa: BLE001
                    raise DBError(f"Lỗi SQL: {exc}") from exc
                return {"row_count": cur.rowcount, "status": cur.statusmessage}
