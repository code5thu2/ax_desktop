"""Tiện ích cho archive_mcp: guard truy cập, nhận diện & giải nén an toàn.

Cấu hình qua biến môi trường:
    ARCHIVE_ACCESS_MODE     "readonly" (mặc định) hoặc "readwrite"
    ARCHIVE_MAX_READ_BYTES  giới hạn byte khi đọc 1 file trong archive (mặc định 1_000_000)
"""

from __future__ import annotations

import os
import tarfile
import zipfile

from common import McpError, human_size, make_access

DEFAULT_MAX_READ_BYTES = 1_000_000

ArchiveError = McpError  # alias cho dễ đọc
access_mode, is_readonly, require_write = make_access("ARCHIVE_ACCESS_MODE")

__all__ = [
    "ArchiveError", "access_mode", "is_readonly", "require_write",
    "max_read_bytes", "resolve_path", "kind", "safe_join", "human_size",
]


def max_read_bytes() -> int:
    try:
        return int(os.environ.get("ARCHIVE_MAX_READ_BYTES", DEFAULT_MAX_READ_BYTES))
    except ValueError:
        return DEFAULT_MAX_READ_BYTES


def resolve_path(path: str) -> str:
    """Chuẩn hoá path tuyệt đối (không bắt buộc tồn tại — dùng cả cho đích)."""
    if not path or not str(path).strip():
        raise ArchiveError("Thiếu đường dẫn.")
    return os.path.realpath(os.path.abspath(os.path.expanduser(path)))


def kind(path: str) -> str:
    """Nhận diện loại archive: 'zip' | 'tar' (gồm .tar/.tar.gz/.tgz...)."""
    if zipfile.is_zipfile(path):
        return "zip"
    if tarfile.is_tarfile(path):
        return "tar"
    raise ArchiveError(f"Không phải file zip/tar hợp lệ: {path}")


def safe_join(dest: str, member: str) -> str:
    """Ghép dest + member và đảm bảo KHÔNG thoát ra ngoài dest (chống zip-slip)."""
    dest_abs = os.path.realpath(dest)
    target = os.path.realpath(os.path.join(dest_abs, member))
    dest_norm = os.path.normcase(dest_abs)
    target_norm = os.path.normcase(target)
    if target_norm != dest_norm and not target_norm.startswith(dest_norm + os.sep):
        raise ArchiveError(f"Mục trong archive thoát ra ngoài thư mục đích: {member}")
    return target
