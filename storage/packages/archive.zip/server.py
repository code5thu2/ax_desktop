"""MCP server nén/giải nén zip & tar (chỉ thư viện chuẩn, chạy offline).

Chạy: python -m archive_mcp   (transport stdio)
Cấu hình: ARCHIVE_ACCESS_MODE=readonly|readwrite, ARCHIVE_MAX_READ_BYTES.

Tool đọc (list/read member) luôn khả dụng; tool thay đổi (extract/create) chỉ
chạy khi ARCHIVE_ACCESS_MODE=readwrite. Giải nén có chống zip-slip.
"""

from __future__ import annotations

import os
import tarfile
import zipfile
from typing import Any

from mcp.server import MCPServer
from common import ok as _ok

from .helpers import (
    ArchiveError,
    access_mode,
    human_size,
    kind,
    max_read_bytes,
    require_write,
    resolve_path,
    safe_join,
)

mcp = MCPServer(
    "archive",
    instructions=(
        "Nén và giải nén file zip/tar: liệt kê nội dung, đọc 1 file bên trong, "
        "giải nén (có chống zip-slip), tạo archive mới. Mặc định read-only; "
        "extract/create chỉ khi ARCHIVE_ACCESS_MODE=readwrite."
    ),
)


# ========================================================================== #
# Tool đọc
# ========================================================================== #
@mcp.tool()
def list_archive(path: str) -> dict[str, Any]:
    """Liệt kê các mục trong file zip/tar (tên, kích thước, nén, thư mục?)."""
    target = resolve_path(path)
    if not os.path.isfile(target):
        raise ArchiveError(f"Không tìm thấy tệp: {target}")
    k = kind(target)
    entries: list[dict[str, Any]] = []
    if k == "zip":
        with zipfile.ZipFile(target) as zf:
            for info in zf.infolist():
                entries.append(
                    {
                        "name": info.filename,
                        "is_dir": info.is_dir(),
                        "size": info.file_size,
                        "size_human": human_size(info.file_size),
                        "compressed": info.compress_size,
                    }
                )
    else:  # tar
        with tarfile.open(target) as tf:
            for m in tf.getmembers():
                entries.append(
                    {
                        "name": m.name,
                        "is_dir": m.isdir(),
                        "size": m.size,
                        "size_human": human_size(m.size),
                    }
                )
    return _ok(path=target, format=k, count=len(entries), entries=entries)


@mcp.tool()
def read_archive_member(
    path: str, member: str, max_bytes: int | None = None, encoding: str = "utf-8"
) -> dict[str, Any]:
    """Đọc nội dung văn bản của MỘT file bên trong archive (không cần giải nén)."""
    target = resolve_path(path)
    if not os.path.isfile(target):
        raise ArchiveError(f"Không tìm thấy tệp: {target}")
    cap = max_read_bytes()
    limit = min(max_bytes, cap) if max_bytes else cap
    k = kind(target)
    if k == "zip":
        with zipfile.ZipFile(target) as zf:
            try:
                with zf.open(member) as fh:
                    raw = fh.read(limit + 1)
            except KeyError as exc:
                raise ArchiveError(f"Không có mục '{member}' trong archive") from exc
    else:  # tar
        with tarfile.open(target) as tf:
            try:
                ex = tf.extractfile(member)
            except KeyError as exc:
                raise ArchiveError(f"Không có mục '{member}' trong archive") from exc
            if ex is None:
                raise ArchiveError(f"'{member}' không phải file thường")
            raw = ex.read(limit + 1)
    truncated = len(raw) > limit
    raw = raw[:limit]
    return _ok(
        path=target,
        member=member,
        bytes_read=len(raw),
        truncated=truncated,
        content=raw.decode(encoding, errors="replace"),
    )


@mcp.tool()
def server_info() -> dict[str, Any]:
    """Xem chế độ truy cập và giới hạn đọc hiện tại."""
    return _ok(access_mode=access_mode(), max_read_bytes=max_read_bytes())


# ========================================================================== #
# Tool thay đổi (chỉ khi ARCHIVE_ACCESS_MODE=readwrite)
# ========================================================================== #
@mcp.tool()
def extract_archive(
    path: str, dest: str, members: list[str] | None = None, overwrite: bool = False
) -> dict[str, Any]:
    """Giải nén archive vào thư mục dest (chống zip-slip). Cần readwrite.

    members: chỉ giải nén các mục nêu tên; bỏ trống = giải nén tất cả.
    """
    require_write()
    target = resolve_path(path)
    if not os.path.isfile(target):
        raise ArchiveError(f"Không tìm thấy tệp: {target}")
    dest_abs = resolve_path(dest)
    os.makedirs(dest_abs, exist_ok=True)
    k = kind(target)
    extracted: list[str] = []

    if k == "zip":
        with zipfile.ZipFile(target) as zf:
            names = members if members else zf.namelist()
            for name in names:
                out = safe_join(dest_abs, name)
                if name.endswith("/"):
                    os.makedirs(out, exist_ok=True)
                    continue
                if os.path.exists(out) and not overwrite:
                    raise ArchiveError(f"Đã tồn tại (overwrite=False): {out}")
                os.makedirs(os.path.dirname(out), exist_ok=True)
                with zf.open(name) as src, open(out, "wb") as dst:
                    dst.write(src.read())
                extracted.append(out)
    else:  # tar
        with tarfile.open(target) as tf:
            names = members if members else tf.getnames()
            for name in names:
                m = tf.getmember(name)
                out = safe_join(dest_abs, name)
                if m.isdir():
                    os.makedirs(out, exist_ok=True)
                    continue
                if os.path.exists(out) and not overwrite:
                    raise ArchiveError(f"Đã tồn tại (overwrite=False): {out}")
                os.makedirs(os.path.dirname(out), exist_ok=True)
                ex = tf.extractfile(m)
                if ex is None:
                    continue
                with open(out, "wb") as dst:
                    dst.write(ex.read())
                extracted.append(out)

    return _ok(path=target, dest=dest_abs, count=len(extracted), extracted=extracted)


@mcp.tool()
def create_archive(
    archive_path: str, sources: list[str], archive_format: str = "zip"
) -> dict[str, Any]:
    """Tạo archive mới từ danh sách tệp/thư mục nguồn. Cần readwrite.

    archive_format: "zip" | "tar" | "tar.gz". Tên trong archive lấy theo tên gốc.
    """
    require_write()
    out = resolve_path(archive_path)
    if os.path.exists(out):
        raise ArchiveError(f"Đích đã tồn tại: {out}")
    os.makedirs(os.path.dirname(out) or ".", exist_ok=True)
    srcs = [resolve_path(s) for s in sources]
    for s in srcs:
        if not os.path.exists(s):
            raise ArchiveError(f"Nguồn không tồn tại: {s}")
    added = 0

    def _walk(src: str):
        nonlocal added
        base = os.path.dirname(src)
        if os.path.isdir(src):
            for root, _dirs, files in os.walk(src):
                for f in files:
                    full = os.path.join(root, f)
                    yield full, os.path.relpath(full, base)
                    added += 1
        else:
            yield src, os.path.relpath(src, base)
            added += 1

    if archive_format == "zip":
        with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as zf:
            for src in srcs:
                for full, arc in _walk(src):
                    zf.write(full, arc)
    elif archive_format in ("tar", "tar.gz"):
        mode = "w:gz" if archive_format == "tar.gz" else "w"
        with tarfile.open(out, mode) as tf:
            for src in srcs:
                tf.add(src, arcname=os.path.basename(src))
                added += 1
    else:
        raise ArchiveError("archive_format phải là 'zip', 'tar' hoặc 'tar.gz'")

    return _ok(archive=out, format=archive_format, entries_added=added)


def main() -> None:
    """Điểm khởi động: chạy MCP server qua stdio."""
    mcp.run()


if __name__ == "__main__":
    main()
