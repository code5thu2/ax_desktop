"""MCP server nén/giải nén (zip/tar) — chỉ dùng thư viện chuẩn."""

from .server import main, mcp

__all__ = ["main", "mcp"]
__version__ = "0.1.0"
