
import os
from mcp.server import MCPServer

mcp = MCPServer("my_custom_tool")

@mcp.tool()
def calculate_tax(amount: float) -> float:
    """Calculates tax for target amount."""
    tax_rate = float(os.getenv("TAX_RATE", "0.1"))
    return amount * tax_rate
